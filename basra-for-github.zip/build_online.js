const fs=require('fs');
const path=require('path');
const dir=__dirname;
const baloot=fs.readFileSync(path.join(dir,'baloot_v24_1.html'),'utf8');

const back=(baloot.match(/data:image\/jpeg;base64,[A-Za-z0-9+/=]+/)||[])[0];
if(!back)throw new Error('card back not found');
const font=(baloot.match(/data:font\/woff2;base64,[A-Za-z0-9+/=]+/)||[])[0];
if(!font)throw new Error('font not found');
const s=baloot.indexOf('const CARD_IMG=');
const e=baloot.indexOf('function cardEl');
if(s<0||e<0)throw new Error('CARD_IMG not found');
const cardImgDef=baloot.slice(s,e).trim();

function build(name,title,scriptFile,extraCSS='',extraHTML=''){
  const script=fs.readFileSync(path.join(dir,scriptFile),'utf8').replace('__CARD_IMG_DEF__',()=>cardImgDef);
  let css=extraCSS;
  let body=extraHTML;
  const out=`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>${title}</title>
<style>
:root{--bg:#1e2417;--bg2:#141a0f;--sadu-gold:#d9a441;--paper:#F5EBB8;--paper-edge:#D8CD96;--paper-ink:#2a2415;--gold:#C9A45C;--gold-soft:#E4CE9E;--ivory:#FDFAF0;--card-edge:#DCD3BC;--red:#B3271E;--blk:#22262B;--good:#5FA773;--bad:#C25B4E;--text:#EFE6D2;--muted:#c9b48d;}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{height:100%}
body{background:radial-gradient(ellipse 70% 30% at 18% 0%,rgba(255,214,120,.14),transparent 60%),radial-gradient(ellipse 70% 30% at 82% 0%,rgba(255,214,120,.10),transparent 60%),var(--bg);color:var(--text);font-family:"Geeza Pro","Noto Naskh Arabic","Segoe UI",Tahoma,sans-serif;overflow:hidden;position:fixed;inset:0;display:flex;flex-direction:column;}
#glow{position:fixed;top:-40px;left:50%;transform:translateX(-50%);width:220px;height:160px;pointer-events:none;z-index:1;background:radial-gradient(ellipse at 50% 0%,rgba(255,200,110,.30),transparent 70%)}
#stage{flex:1;position:relative;z-index:2;margin:2px auto;width:min(calc(100% - 20px),74vh);max-width:calc(100% - 20px)}
#table{position:absolute;inset:0 0 8px 0;border-radius:24px;background:radial-gradient(ellipse at 45% 0%,rgba(255,225,170,.14),transparent 50%),repeating-linear-gradient(93deg,rgba(0,0,0,.10) 0 2px,transparent 2px 9px,rgba(255,255,255,.03) 9px 11px,transparent 11px 26px),linear-gradient(180deg,#7a5432,#5f3e20 60%,#503318);box-shadow:inset 0 2px 0 rgba(255,230,180,.28),0 6px 0 #17110c,0 10px 0 #3d2713,0 22px 34px rgba(0,0,0,.6);}
#table .cloth{position:absolute;inset:24px;border-radius:14px;background:repeating-linear-gradient(41deg,rgba(255,255,255,.022) 0 2px,transparent 2px 5px),repeating-linear-gradient(-49deg,rgba(0,0,0,.03) 0 2px,transparent 2px 6px),radial-gradient(ellipse at 38% 22%,#2e7d4f 0%,#1e5c39 45%,#14452b 82%,#0e3520 100%);box-shadow:inset 0 2px 8px rgba(255,255,255,.12),inset 0 -4px 18px rgba(0,0,0,.35),0 1px 4px rgba(0,0,0,.4);}
.seat{position:absolute;z-index:6;display:flex;flex-direction:column;align-items:center;gap:3px}
#seat0{bottom:10px;left:50%;transform:translateX(-50%)}
.seatname{font-size:clamp(13px,3.4vw,17px);font-weight:800;color:#4a3a1c;background:linear-gradient(180deg,#EBDCB2,#CDB684);padding:3px 14px;border-radius:14px;box-shadow:0 2px 5px rgba(0,0,0,.4),inset 0 1px 0 rgba(255,255,255,.5);font-family:'DARK','Geeza Pro',Tahoma,sans-serif;white-space:nowrap;}
.seatname.turn{color:#3a2c10;box-shadow:0 0 0 2px var(--sadu-gold),0 0 14px rgba(217,164,65,.5)}
.seatname.out{opacity:.45;filter:grayscale(1);text-decoration:line-through}
.card{width:64px;height:92px;border-radius:8px;background:var(--ivory);border:1px solid var(--card-edge);position:relative;flex:none;box-shadow:0 2px 5px rgba(0,0,0,.35);user-select:none;font-weight:800;transition:transform .18s ease,box-shadow .18s ease,opacity .18s;}
.card .tl{position:absolute;top:5px;right:7px;font-size:16px;line-height:1.05;text-align:center}
.card .mid{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:30px}
.card.red{color:var(--red)} .card.blk{color:var(--blk)}
.card.court{background-color:#fff;background-size:contain;background-repeat:no-repeat;background-position:center}
.card.back{background:url(${back}) center/cover;border-color:#173d27}
.card.back .tl,.card.back .mid{display:none}
#hand{position:relative;z-index:10;flex:none;height:122px;display:flex;justify-content:center;align-items:flex-end;padding:0 6px 10px;}
#hand .fw{margin:0 -8px;flex:none}
#hand .card{cursor:default}
#actions{position:relative;z-index:15;flex:none;min-height:54px;display:flex;flex-wrap:wrap;gap:8px;justify-content:center;align-items:center;padding:4px 10px 12px;max-height:52vh;overflow:auto;}
button{font-family:'DARK','Geeza Pro',Tahoma,sans-serif;font-weight:800;font-size:16px;cursor:pointer;border:none;border-radius:12px;padding:10px 20px;background:var(--paper);color:var(--paper-ink);box-shadow:0 3px 0 var(--paper-edge),0 5px 10px rgba(0,0,0,.4);transition:transform .1s;}
button:active{transform:translateY(2px);box-shadow:0 1px 0 var(--paper-edge)}
button.gold{background:linear-gradient(180deg,var(--gold-soft),var(--gold));color:#3a2c10;box-shadow:0 3px 0 #8f7238,0 5px 10px rgba(0,0,0,.4)}
button.danger{background:var(--bad);color:#fff;box-shadow:0 3px 0 #8d3f35}
.hint{width:100%;text-align:center;font-size:13px;color:var(--muted)}
.panel{position:fixed;inset:0;z-index:50;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.55);padding:20px;}
.panel.show{display:flex}
.panel .box{background:var(--paper);color:var(--paper-ink);border-radius:6px 6px 18px 6px;box-shadow:0 4px 0 var(--paper-edge),0 14px 30px rgba(0,0,0,.6);padding:20px 22px;max-width:340px;width:100%;text-align:center;max-height:82vh;overflow:auto;}
.resTbl{width:100%;border-collapse:collapse;margin:4px 0;font-size:15px}
.resTbl th{font-weight:800;color:var(--muted);font-size:13px;padding:4px 6px;border-bottom:1px solid var(--paper-edge)}
.resTbl td{padding:6px 6px;text-align:center;font-weight:700}
.resWin{font-size:22px;font-weight:800;text-align:center;margin-top:12px;font-family:'DARK','Geeza Pro',Tahoma}
#toast{position:fixed;z-index:60;top:16px;left:50%;transform:translateX(-50%) translateY(-70px);background:var(--paper);color:var(--paper-ink);font-weight:800;font-size:15px;padding:9px 18px;border-radius:14px;box-shadow:0 4px 12px rgba(0,0,0,.5);transition:transform .25s ease;max-width:92vw;text-align:center;}
#toast.show{transform:translateX(-50%) translateY(0)}
.bubble{position:absolute;z-index:20;background:var(--paper);color:var(--paper-ink);font-weight:800;font-size:19px;padding:9px 18px;border-radius:16px;box-shadow:0 3px 8px rgba(0,0,0,.4);opacity:0;transform:scale(.5);transition:all .28s cubic-bezier(.34,1.6,.64,1);white-space:nowrap;}
.bubble.show{opacity:1;transform:scale(1)}
#bub0{bottom:150px;left:50%;margin-left:-30px}
#muteBtn{position:fixed;z-index:6;top:12px;left:12px}
@media(max-height:640px){.card{width:52px;height:74px}.card .mid{font-size:24px}#hand{height:100px}}
@font-face{font-family:'DARK';src:url(${font});font-display:swap;}
${css}
</style>
</head>
<body>
<div id="glow"></div>
<div id="stage">
  <div id="table"><div class="cloth"></div></div>
  <div class="seat" id="seat0">
    <div class="seatname turn" id="name0">أنت</div>
    <div class="seatbal" id="bal0"></div>
  </div>
  ${body}
</div>
<div id="hand"></div>
<div id="actions"></div>
<div class="panel" id="resultPanel"><div class="box">
  <h2 id="resTitle">النتيجة</h2>
  <div id="resBody"></div>
  <div class="sep"></div>
  <button class="gold" id="nextBtn">تمام</button>
</div></div>
<div id="toast"></div>
<button id="muteBtn" class="ghost">🔊</button>
<script src="online/online.js"></script>
<script>
'use strict';
${script}
</script>
</body>
</html>`;
  fs.writeFileSync(path.join(dir,name+'_online.html'),out);
  console.log(name,'OK size=',out.length);
}

/* سبعة الديمن */
build('sevens','سبعة الديمن','sevens_online_script.js',`
.run-box{position:absolute;top:8px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.35);padding:6px 18px;border-radius:12px;font-weight:800;font-size:15px;color:var(--gold-soft);z-index:10}
.run{display:flex;gap:4px;justify-content:center;margin-top:6px}
.run .card{width:42px;height:58px;font-size:11px}
.run .card .mid{font-size:18px}
#seat1{top:8px;left:50%;transform:translateX(-50%)}
#seat2{top:50%;left:8px;transform:translateY(-50%)}
#seat3{top:50%;right:8px;transform:translateY(-50%)}
`,`
<div class="run-box">الجولة <span id="roundNo">١</span></div>
<div class="run" id="runD"></div>
<div class="run" id="runH"></div>
<div class="run" id="runC"></div>
<div class="run" id="runS"></div>
<div class="seat" id="seat1"><div class="seatname" id="name1">حمد</div><div class="seatbal" id="cnt1">٨ ورقة</div></div>
<div class="seat" id="seat2"><div class="seatname" id="name2">مشاري</div><div class="seatbal" id="cnt2">٨ ورقة</div></div>
<div class="seat" id="seat3"><div class="seatname" id="name3">سعيد</div><div class="seatbal" id="cnt3">٨ ورقة</div></div>
<div class="bubble" id="bub1"></div>
<div class="bubble" id="bub2"></div>
<div class="bubble" id="bub3"></div>
`);

/* بلوت */
build('baloot','بلوت','baloot_online_script.js',`
#padMode{position:absolute;top:6px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.35);padding:4px 14px;border-radius:10px;font-weight:800;font-size:14px;color:var(--gold-soft);z-index:10}
#floorCard{position:absolute;top:38%;left:50%;transform:translate(-50%,-50%);z-index:8;transition:all .4s ease}
#floorCard .card{width:52px;height:74px}
.slot{position:absolute;width:52px;height:74px;z-index:9}
#slot0{bottom:22%;left:50%;transform:translateX(-50%)}
#slot1{top:50%;right:22%;transform:translateY(-50%)}
#slot2{top:22%;left:50%;transform:translateX(-50%)}
#slot3{top:50%;left:22%;transform:translateY(-50%)}
.pile{position:absolute;width:44px;height:60px;z-index:7;display:none}
#pile0{bottom:18%;left:18%}
#pile1{bottom:18%;right:18%}
.pile .pc{position:absolute;width:44px;height:60px;border-radius:6px;background:var(--ivory);border:1px solid var(--card-edge)}
.pile-tag{position:absolute;bottom:-18px;left:50%;transform:translateX(-50%);font-weight:800;font-size:12px;color:var(--gold-soft);background:rgba(0,0,0,.4);padding:1px 8px;border-radius:8px}
#seat1{top:10px;left:50%;transform:translateX(-50%)}
#seat2{top:50%;left:10px;transform:translateY(-50%)}
#seat3{top:50%;right:10px;transform:translateY(-50%)}
`,`
<div id="padMode">—</div>
<div id="floorCard"></div>
<div class="slot" id="slot0"></div>
<div class="slot" id="slot1"></div>
<div class="slot" id="slot2"></div>
<div class="slot" id="slot3"></div>
<div class="pile" id="pile0"><div class="pile-tag" id="pc0">٠</div></div>
<div class="pile" id="pile1"><div class="pile-tag" id="pc1">٠</div></div>
<div class="seat" id="seat1"><div class="seatname" id="name1">حمد</div></div>
<div class="seat" id="seat2"><div class="seatname" id="name2">مشاري</div></div>
<div class="seat" id="seat3"><div class="seatname" id="name3">سعيد</div></div>
<div class="bubble" id="bub1"></div>
<div class="bubble" id="bub2"></div>
<div class="bubble" id="bub3"></div>
`);

/* بلوت */
build('baloot','بلوت','baloot_online_script.js',`
#padMode{position:absolute;top:6px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.35);padding:4px 14px;border-radius:10px;font-weight:800;font-size:14px;color:var(--gold-soft);z-index:10}
#floorCard{position:absolute;top:38%;left:50%;transform:translate(-50%,-50%);z-index:8;transition:all .4s ease}
#floorCard .card{width:52px;height:74px}
.slot{position:absolute;width:52px;height:74px;z-index:9}
#slot0{bottom:22%;left:50%;transform:translateX(-50%)}
#slot1{top:50%;right:22%;transform:translateY(-50%)}
#slot2{top:22%;left:50%;transform:translateX(-50%)}
#slot3{top:50%;left:22%;transform:translateY(-50%)}
.pile{position:absolute;width:44px;height:60px;z-index:7;display:none}
#pile0{bottom:18%;left:18%}
#pile1{bottom:18%;right:18%}
.pile .pc{position:absolute;width:44px;height:60px;border-radius:6px;background:var(--ivory);border:1px solid var(--card-edge)}
.pile-tag{position:absolute;bottom:-18px;left:50%;transform:translateX(-50%);font-weight:800;font-size:12px;color:var(--gold-soft);background:rgba(0,0,0,.4);padding:1px 8px;border-radius:8px}
#seat1{top:10px;left:50%;transform:translateX(-50%)}
#seat2{top:50%;left:10px;transform:translateY(-50%)}
#seat3{top:50%;right:10px;transform:translateY(-50%)}
`,`
<div id="padMode">—</div>
<div id="floorCard"></div>
<div class="slot" id="slot0"></div>
<div class="slot" id="slot1"></div>
<div class="slot" id="slot2"></div>
<div class="slot" id="slot3"></div>
<div class="pile" id="pile0"><div class="pile-tag" id="pc0">٠</div></div>
<div class="pile" id="pile1"><div class="pile-tag" id="pc1">٠</div></div>
<div class="seat" id="seat1"><div class="seatname" id="name1">حمد</div></div>
<div class="seat" id="seat2"><div class="seatname" id="name2">مشاري</div></div>
<div class="seat" id="seat3"><div class="seatname" id="name3">سعيد</div></div>
<div class="bubble" id="bub1"></div>
<div class="bubble" id="bub2"></div>
<div class="bubble" id="bub3"></div>
`);

/* الهاند */
build('hand','الهاند','hand_online_script.js',`
#center{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;gap:16px;align-items:center;z-index:8}
#deckPile,#firePile{width:64px;height:92px;position:relative}
#deckPile .card,#firePile .card{position:absolute;left:0;top:0}
.melds-box{position:absolute;display:flex;flex-direction:column;gap:4px;z-index:7}
#melds0{bottom:18%;left:50%;transform:translateX(-50%)}
#melds1{top:12%;left:50%;transform:translateX(-50%)}
#melds2{top:50%;left:12%;transform:translateY(-50%)}
#melds3{top:50%;right:12%;transform:translateY(-50%)}
.meld-row{display:flex;gap:2px}
.meld-row .card{width:36px;height:50px;font-size:10px}
.meld-row .card .mid{font-size:14px}
.seatname.melded{box-shadow:0 0 0 2px var(--good),0 0 14px rgba(95,167,115,.5)}
#seat1{top:10px;left:50%;transform:translateX(-50%)}
#seat2{top:50%;left:10px;transform:translateY(-50%)}
#seat3{top:50%;right:10px;transform:translateY(-50%)}
`,`
<div id="center">
  <div id="deckPile"></div>
  <div id="firePile"></div>
</div>
<div class="melds-box" id="melds0"></div>
<div class="melds-box" id="melds1"></div>
<div class="melds-box" id="melds2"></div>
<div class="melds-box" id="melds3"></div>
<div class="seat" id="seat1"><div class="seatname" id="name1">حمد</div></div>
<div class="seat" id="seat2"><div class="seatname" id="name2">مشاري</div></div>
<div class="seat" id="seat3"><div class="seatname" id="name3">سعيد</div></div>
<div class="bubble" id="bub1"></div>
<div class="bubble" id="bub2"></div>
<div class="bubble" id="bub3"></div>
`);

console.log('Done');
