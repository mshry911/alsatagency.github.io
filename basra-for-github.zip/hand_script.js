/* ================== منطق صافي (بدون واجهة) ================== */
const L=(function(){
/* ================== منطق الهاند السعودي (نقي وقابل للاختبار) ================== */
const SUITS=['S','H','C','D'];
const RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
const RIDX={};RANKS.forEach((r,i)=>RIDX[r]=i);   // A=0 ... K=12

/* ١٠٦ ورقة: كتشينتين + جوكرين */
function mkDeck(){
  const d=[];
  for(let k=0;k<2;k++){
    for(const s of SUITS)for(const r of RANKS)d.push({s,r,id:s+r+'_'+k,joker:false});
    d.push({s:null,r:'JK',id:'JK_'+k,joker:true});
  }
  return d;
}
function shuffle(a,rnd){
  const R=rnd||Math.random;
  for(let i=a.length-1;i>0;i--){const j=Math.floor(R()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  return a;
}
/* قيمة الورقة: الأرقام بقيمتها، الصور ١٠، الإكة ١١ دائماً */
function cardValue(c){
  if(c.joker)return 0;                 // قيمة الجوكر = قيمة ما ينوب عنه (تُحسب بالمجموعة)
  if(c.r==='A')return 11;
  if(c.r==='J'||c.r==='Q'||c.r==='K')return 10;
  return parseInt(c.r,10);
}
/* قيمة الجوكر في يد خاسر نزل */
const JOKER_IN_HAND=15;

/* ================== التحقق من المجموعات ================== */
/* متشابهة: ٣ أو ٤ أوراق بنفس الرتبة وألوان مختلفة (جوكر واحد كحد أقصى) */
function isSet(cards){
  if(cards.length<3||cards.length>4)return false;
  const jokers=cards.filter(c=>c.joker);
  if(jokers.length>1)return false;
  const real=cards.filter(c=>!c.joker);
  if(!real.length)return false;
  const r=real[0].r;
  if(r==='JK')return false;
  if(!real.every(c=>c.r===r))return false;
  const suits=real.map(c=>c.s);
  if(new Set(suits).size!==suits.length)return false;   // ألوان مختلفة
  return true;
}
/* متسلسلة: ٣+ متتابعة نفس اللون، الإكة أعلى أو أدنى، بدون التفاف */
function isRun(cards){
  if(cards.length<3)return false;
  const jokers=cards.filter(c=>c.joker);
  if(jokers.length>1)return false;
  const real=cards.filter(c=>!c.joker);
  if(!real.length)return false;
  const s=real[0].s;
  if(!real.every(c=>c.s===s))return false;
  if(real.some(c=>c.r==='JK'))return false;
  // ترتيبان محتملان: الإكة صغيرة (A=1) أو كبيرة (A=14)
  for(const aceHigh of [false,true]){
    const val=c=>{
      const i=RIDX[c.r];
      if(c.r==='A')return aceHigh?14:1;
      return i+1;                                  // 2→2 ... K→13
    };
    const nums=real.map(val).sort((a,b)=>a-b);
    if(new Set(nums).size!==nums.length)continue;   // ما فيه تكرار
    const span=nums[nums.length-1]-nums[0]+1;
    if(span>cards.length)continue;                  // الفجوات أكبر من الجوكرات
    const gaps=span-real.length;
    if(gaps!==jokers.length)continue;
    if(span!==cards.length)continue;
    if(nums[0]<1||nums[nums.length-1]>14)continue;
    return true;
  }
  return false;
}
function isValidMeld(cards){return isSet(cards)||isRun(cards);}

/* قيمة المجموعة (الجوكر ياخذ قيمة ما ينوب عنه) */
function meldValue(cards){
  if(!isValidMeld(cards))return 0;
  const jokers=cards.filter(c=>c.joker);
  const real=cards.filter(c=>!c.joker);
  let v=real.reduce((n,c)=>n+cardValue(c),0);
  if(!jokers.length)return v;
  if(isSet(cards))return v+cardValue(real[0])*jokers.length;
  // متسلسلة: نحدد الرتب الناقصة
  for(const aceHigh of [false,true]){
    const val=c=>c.r==='A'?(aceHigh?14:1):RIDX[c.r]+1;
    const nums=real.map(val).sort((a,b)=>a-b);
    if(new Set(nums).size!==nums.length)continue;
    const span=nums[nums.length-1]-nums[0]+1;
    if(span-real.length!==jokers.length)continue;
    const present=new Set(nums);
    let add=0;
    for(let n=nums[0];n<=nums[nums.length-1];n++){
      if(present.has(n))continue;
      add += n===1?11 : n===14?11 : n>=11?10 : n;   // ١ أو ١٤ = إكة = ١١
    }
    return v+add;
  }
  return v;
}
/* مجموع نقاط عدة مجموعات (نصاب النزول) */
function meldsValue(melds){return melds.reduce((n,m)=>n+meldValue(m),0);}

/* ================== التسقيط على مجموعة موجودة ================== */
/* هل يمكن إضافة الورقة لهذه المجموعة؟ */
function canLayOff(card,meld){
  if(card.joker){
    // الجوكر يُضاف فقط إذا ما فيه جوكر بالمجموعة والنتيجة صالحة
    if(meld.some(c=>c.joker))return false;
    return isValidMeld(meld.concat([card]));
  }
  return isValidMeld(meld.concat([card]));
}
/* الورقة الأصلية التي ينوب عنها الجوكر في مجموعة (لتبديله) */
function jokerReplacement(meld){
  const j=meld.find(c=>c.joker);
  if(!j)return null;
  const real=meld.filter(c=>!c.joker);
  if(!real.length)return null;
  if(isSet(meld)){
    // أي لون غير الموجود بنفس الرتبة
    const used=new Set(real.map(c=>c.s));
    return {r:real[0].r,suits:SUITS.filter(s=>!used.has(s))};
  }
  // متسلسلة: الرتبة الناقصة
  for(const aceHigh of [false,true]){
    const val=c=>c.r==='A'?(aceHigh?14:1):RIDX[c.r]+1;
    const nums=real.map(val).sort((a,b)=>a-b);
    if(new Set(nums).size!==nums.length)continue;
    const span=nums[nums.length-1]-nums[0]+1;
    if(span-real.length!==1)continue;
    const present=new Set(nums);
    for(let n=nums[0];n<=nums[nums.length-1];n++){
      if(present.has(n))continue;
      const rank = n===1||n===14?'A':RANKS[n-1];
      return {r:rank,suits:[real[0].s]};
    }
  }
  return null;
}
/* شرط خاص: جوكر داخل مجموعة من ورقتين + جوكر ← ما يُبدّل بورقة واحدة */
function canTakeJoker(meld,card){
  if(!meld.some(c=>c.joker))return false;
  const rep=jokerReplacement(meld);
  if(!rep)return false;
  if(!(card.r===rep.r&&rep.suits.includes(card.s)))return false;
  // إذا المجموعة ٣ أوراق منها جوكر وهي "متشابهة" ← تبقى ٣ بعد التبديل، مسموح
  return meld.length>=3;
}

/* ================== الحساب ================== */
/* نقاط اللاعب في نهاية الجولة */
function playerScore(opt){
  const {isWinner,hasMelded,hand,isHand}=opt;
  const mult=isHand?2:1;
  if(isWinner)return isHand?-60:-30;
  if(!hasMelded)return 100*mult;                    // سك المية (الجوكر ما يُحسب فوقها)
  let v=0;
  for(const c of hand)v += c.joker?JOKER_IN_HAND:cardValue(c);
  return v*mult;
}
/* نتيجة الجولة كاملة */
function scoreRound(players,winnerIdx,isHand){
  return players.map((p,i)=>playerScore({
    isWinner:i===winnerIdx, hasMelded:p.melded, hand:p.hand, isHand
  }));
}

/* ================== إيجاد المجموعات في اليد (للذكاء والتلميح) ================== */
/* كل المجموعات الممكنة (بحث محدود لأداء جيد) */
function findMelds(hand){
  const out=[];
  const jokers=hand.filter(c=>c.joker);
  const real=hand.filter(c=>!c.joker);
  // متشابهات
  const byRank={};
  real.forEach(c=>{(byRank[c.r]=byRank[c.r]||[]).push(c);});
  for(const r in byRank){
    const uniq=[];
    const seen=new Set();
    for(const c of byRank[r]){if(!seen.has(c.s)){seen.add(c.s);uniq.push(c);}}
    if(uniq.length>=3){
      out.push(uniq.slice(0,3));
      if(uniq.length>=4)out.push(uniq.slice(0,4));
    }else if(uniq.length===2&&jokers.length){
      out.push(uniq.concat([jokers[0]]));
    }
  }
  // متسلسلات
  const bySuit={};
  real.forEach(c=>{(bySuit[c.s]=bySuit[c.s]||[]).push(c);});
  for(const s in bySuit){
    const uniq=[];
    const seen=new Set();
    for(const c of bySuit[s]){if(!seen.has(c.r)){seen.add(c.r);uniq.push(c);}}
    uniq.sort((a,b)=>RIDX[a.r]-RIDX[b.r]);
    for(let i=0;i<uniq.length;i++){
      for(let len=3;len<=Math.min(6,uniq.length-i);len++){
        const seq=uniq.slice(i,i+len);
        if(isRun(seq))out.push(seq);
        if(jokers.length){
          const withJ=seq.concat([jokers[0]]);
          if(isRun(withJ))out.push(withJ);
        }
      }
    }
    // متسلسلة بجوكر في الوسط
    if(jokers.length)for(let i=0;i<uniq.length-1;i++){
      for(let j=i+1;j<uniq.length;j++){
        const seq=[uniq[i],uniq[j],jokers[0]];
        if(isRun(seq))out.push(seq);
      }
    }
  }
  return out;
}
/* أفضل تشكيلة نزول تحقق النصاب المطلوب (بدون تكرار الأوراق) */
function bestMeldSet(hand,minPts){
  const all=findMelds(hand).sort((a,b)=>meldValue(b)-meldValue(a));
  let best=null;
  const tryCombo=(idx,used,chosen,pts)=>{
    if(pts>=minPts){
      if(!best||pts<best.pts||(pts===best.pts&&chosen.length<best.melds.length))
        best={melds:chosen.slice(),pts};
      return;
    }
    if(idx>=all.length||chosen.length>=4)return;
    for(let i=idx;i<all.length;i++){
      const m=all[i];
      if(m.some(c=>used.has(c.id)))continue;
      m.forEach(c=>used.add(c.id));
      chosen.push(m);
      tryCombo(i+1,used,chosen,pts+meldValue(m));
      chosen.pop();
      m.forEach(c=>used.delete(c.id));
      if(best&&best.pts>=minPts&&chosen.length===0&&i>12)break;   // حد للأداء
    }
  };
  tryCombo(0,new Set(),[],0);
  return best;
}
/* هل يمكن عمل "هاند" (كل اليد مجموعات دفعة واحدة + ورقة رمي)؟ */
function canMakeHand(hand){
  if(hand.length<4)return null;
  // نحتاج تغطية كل الأوراق عدا ورقة واحدة للرمي
  for(let skip=0;skip<hand.length;skip++){
    const rest=hand.filter((_,i)=>i!==skip);
    const covered=coverAll(rest);
    if(covered)return {melds:covered,discard:hand[skip]};
  }
  return null;
}
function coverAll(cards){
  if(!cards.length)return [];
  const all=findMelds(cards);
  const solve=(remaining,acc,depth)=>{
    if(!remaining.length)return acc;
    if(depth>6)return null;
    for(const m of all){
      if(!m.every(c=>remaining.some(x=>x.id===c.id)))continue;
      const next=remaining.filter(c=>!m.some(x=>x.id===c.id));
      const r=solve(next,acc.concat([m]),depth+1);
      if(r)return r;
    }
    return null;
  };
  return solve(cards,[],0);
}

/* ================== ذكاء اللاعب الآلي (مبسّط) ================== */
/* هل ينزل الآن؟ نعم إذا حقق النصاب */
function aiShouldMeld(hand,tableMelds,minPts){
  const best=bestMeldSet(hand,minPts);
  return !!best;
}
/* اختيار ورقة الرمي: أعلى قيمة غير ضرورية */
function aiPickDiscard(hand,melds){
  const used=new Set();
  if(melds)for(const m of melds)for(const c of m)used.add(c.id);
  const candidates=hand.filter(c=>!used.has(c.id));
  if(!candidates.length)return hand[hand.length-1];
  // أعلى قيمة، تفضيل غير الجوكر
  const scored=candidates.map(c=>({c,v:c.joker?99:cardValue(c)}));
  scored.sort((a,b)=>b.v-a.v);
  return scored[0].c;
}
/* اختيار حركة: 0=سحب من الكومة، 1=سحب من المكشوف، melds+discard=نزول+رمي */
function aiTurn(hand,topCard,tableMelds,minPts,deckSize){
  const canMeld=aiShouldMeld(hand,tableMelds,minPts);
  // لو يقدر ينزل ← يسحب من الكومة (أو المكشوف إذا ساعدته)
  if(canMeld){
    return {draw:'deck',meld:true};
  }
  // سحب من الكومة افتراضياً
  return {draw:'deck',meld:false};
}

return {SUITS,RANKS,RIDX,mkDeck,shuffle,cardValue,JOKER_IN_HAND,isSet,isRun,isValidMeld,meldValue,meldsValue,canLayOff,jokerReplacement,canTakeJoker,playerScore,scoreRound,findMelds,bestMeldSet,canMakeHand,coverAll,aiShouldMeld,aiPickDiscard,aiTurn};
})();

/* ================== تصدير مزدوج ================== */
if(typeof module!=='undefined'){
  module.exports=L;
}
