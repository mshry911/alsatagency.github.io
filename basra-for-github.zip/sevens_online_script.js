/* ================== سبعة الديمن — سكربت الأونلاين ================== */
const SUIT_CH={D:'♦',H:'♥',C:'♣',S:'♠'};
const RANK_AR={'7':'٧','8':'٨','9':'٩','10':'١٠',J:'J',Q:'Q',K:'K',A:'A'};
const NAMES=['أنت','حمد','مشاري','سعيد'];

const el=id=>document.getElementById(id);
let net=null, G=null, myHand=[], muted=true;

function arNum(n){return String(n).replace(/\d/g,d=>'٠١٢٣٤٥٦٧٨٩'[d]);}

function cardEl(c){
  const d=document.createElement('div');
  const red=c.s==='H'||c.s==='D';
  d.className='card '+(red?'red':'blk');
  const img=(typeof CARD_IMG!=='undefined')?CARD_IMG[c.s+c.r]:null;
  if(img){d.classList.add('court'); d.style.backgroundImage='url('+img+')';}
  else d.innerHTML='<div class="tl">'+RANK_AR[c.r]+'<br>'+SUIT_CH[c.s]+'</div><div class="mid">'+SUIT_CH[c.s]+'</div>';
  return d;
}
function renderBoard(board){
  for(const s of ['D','H','C','S']){
    const run=el('run'+s), t=board[s];
    run.innerHTML='';
    if(!t)continue;
    for(let i=t.lo;i<=t.hi;i++){
      const c={s,r:['7','8','9','10','J','Q','K','A'][i],id:s+['7','8','9','10','J','Q','K','A'][i]};
      const e=cardEl(c);
      if(i===5)e.style.boxShadow='0 0 0 2px #d9a441, 0 1px 3px rgba(0,0,0,.4)';
      run.appendChild(e);
    }
  }
}
function renderHand(){
  const h=el('hand'); h.innerHTML='';
  const sorted=myHand.slice().sort((a,b)=>['D','H','C','S'].indexOf(a.s)-['D','H','C','S'].indexOf(b.s)||['7','8','9','10','J','Q','K','A'].indexOf(a.r)-['7','8','9','10','J','Q','K','A'].indexOf(b.r));
  const n=sorted.length, mid=(n-1)/2;
  sorted.forEach((c,i)=>{
    const w=document.createElement('div'); w.className='fw';
    w.style.transform='rotate('+((i-mid)*1.6)+'deg) translateY('+Math.abs(i-mid)*1.6+'px)';
    const d=cardEl(c); w.appendChild(d); h.appendChild(w);
  });
}
function markTurn(p){
  for(let i=0;i<4;i++)el('name'+i).classList.toggle('turn',i===p);
}
function toast(txt){
  const t=el('toast'); t.textContent=txt; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),2200);
}
function actions(html){el('actions').innerHTML=html||'';}

/* ========== ربط السيرفر ========== */
function connect(){
  const code=new URLSearchParams(location.search).get('code');
  const session=localStorage.getItem('bs_session')||'';
  net=new BasraNet({
    url:'ws://'+location.host,
    code, session, seat:Number(localStorage.getItem('bs_seat')||0),
    onState:s=>{
      G=s;
      el('roundNo').textContent='جولة '+arNum(s.roundNo);
      renderBoard(s.board);
      for(let i=0;i<4;i++){el('cnt'+i).textContent=arNum(s.players[i].cards)+' ورقة'; el('name'+i).classList.toggle('out',s.players[i].finished);}
      markTurn(s.turn);
      if(s.phase==='done')actions('');
    },
    onHand:h=>{myHand=h.hand; renderHand();},
    onTurn:t=>{
      if(t.kind==='play'){
        const legal=t.legal||[];
        renderHand();
        const handEls=el('hand').querySelectorAll('.card');
        handEls.forEach((d,i)=>{
          const c=myHand[i];
          const can=legal.includes(c.id);
          if(can){d.classList.add('ok'); d.onclick=()=>net.send({t:'game',a:'play',card:c.id});}
          else d.classList.add('dim');
        });
        if(!legal.length)actions('<button class="danger" id="bPass">جلا</button>');
        else actions('');
        if(el('bPass'))el('bPass').onclick=()=>net.send({t:'game',a:'pass'});
      }
    },
    onEvent:e=>{
      if(e.k==='deal')toast('توزيع جديد!');
      if(e.k==='play'){/* طيران ورقة */}
      if(e.k==='trick')toast(NAMES[e.winner]+' أخذ الأكلة +'+(e.pts||''));
      if(e.k==='bubble'){const b=el('bub'+e.idx); if(b){b.textContent=e.txt; b.classList.add('show'); setTimeout(()=>b.classList.remove('show'),1500);}}
      if(e.k==='round_end'){
        let html='<div class="resWin">نتيجة الجولة</div>';
        html+='<table class="resTbl"><thead><tr><th>اللاعب</th><th>المركز</th><th>النقاط</th></tr></thead><tbody>';
        e.order.forEach((p,i)=>{html+='<tr><td>'+NAMES[p]+'</td><td>'+['الأول','الثاني','الثالث','الأخير'][i]+'</td><td>+'+e.award[i]+'</td></tr>';});
        html+='</tbody></table>';
        el('resBody').innerHTML=html;
        el('resultPanel').classList.add('show');
      }
      if(e.k==='game_over'){
        const w=e.winners[0]===0?'🏆 كسبت الصكة!':'الصكة راحت لفريقهم';
        el('resBody').innerHTML='<div class="resWin">'+w+'</div>';
        el('resultPanel').classList.add('show');
      }
    },
    onError:msg=>toast('خطأ: '+msg),
    onClose:()=>toast('انقطع الاتصال — جارٍ إعادة المحاولة...'),
  });
  net.connect();
}
el('nextBtn').onclick=()=>{el('resultPanel').classList.remove('show');};
connect();
