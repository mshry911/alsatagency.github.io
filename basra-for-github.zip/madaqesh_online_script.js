/* ============================================================
   مداقش أونلاين — عميل اللعب
   السيرفر هو الحكم الوحيد: هنا عرض وأزرار فقط
   ============================================================ */
const el=id=>document.getElementById(id);
const SUIT_CH={H:'♥',D:'♦',C:'♣',S:'♠'};
const SUITS=['H','D','C','S'];
const RV={A:8,K:7,Q:6,J:5,'10':4,'9':3,'8':2,'7':1};
const RANK_AR={A:'A',K:'K',Q:'Q',J:'J','10':'10','9':'9','8':'8','7':'7'};
const AR_D=['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
const arNum=n=>String(n).split('').map(ch=>/\d/.test(ch)?AR_D[+ch]:ch).join('');
const fmt=n=>arNum(Number(n).toLocaleString('en-US')).replace(/,/g,'٬');
const REDUCED=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;

/* --- صوت --- */
let SETTINGS={sound:true};
try{Object.assign(SETTINGS,JSON.parse(localStorage.getItem('madaqesh_settings')||'{}'));}catch(e){}
function saveSettings(){try{localStorage.setItem('madaqesh_settings',JSON.stringify(SETTINGS));}catch(e){}}
let muted=!SETTINGS.sound, actx=null;
function tone(f,d,type,vol){
  if(muted)return;
  try{
    actx=actx||new (window.AudioContext||window.webkitAudioContext)();
    if(actx.state==='suspended')actx.resume().catch(()=>{});
    const o=actx.createOscillator(),g=actx.createGain();
    o.type=type||'triangle'; o.frequency.value=f;
    g.gain.setValueAtTime(vol||.12,actx.currentTime);
    g.gain.exponentialRampToValueAtTime(.001,actx.currentTime+(d||.12));
    o.connect(g).connect(actx.destination);
    o.start(); o.stop(actx.currentTime+(d||.12));
  }catch(e){}
}
const sndDeal=()=>tone(320,.06,'square',.05);
const sndChip=()=>{tone(880,.05,'square',.06);setTimeout(()=>tone(660,.07,'square',.05),60);};
const sndTake=()=>{tone(520,.1);setTimeout(()=>tone(660,.12),90);};
const sndBad =()=>tone(180,.25,'sawtooth',.08);
const sndWin =()=>{[523,659,784,1047].forEach((f,i)=>setTimeout(()=>tone(f,.18),i*130));};
const sndLose=()=>{[392,330,262].forEach((f,i)=>setTimeout(()=>tone(f,.2,'sawtooth',.07),i*160));};
const SOUNDS={chip:sndChip,take:sndTake,bad:sndBad,win:sndWin,deal:sndDeal,lose:sndLose};
function playSound(n){if(SOUNDS[n])SOUNDS[n]();}
function shake(){
  const s=el('stage');
  if(REDUCED||!s.animate)return;
  s.animate([
    {transform:'translate(0,0)'},{transform:'translate(-7px,4px)'},
    {transform:'translate(6px,-5px)'},{transform:'translate(-5px,3px)'},
    {transform:'translate(3px,-2px)'},{transform:'translate(0,0)'}
  ],{duration:380,easing:'ease-out'});
}

/* --- الأصول (صور الأوراق والخط مأخوذة من ملف بلوت كما هي) --- */
__CARD_IMG_DEF__
function cardEl(c){
  const d=document.createElement('div');
  const red=c.s==='H'||c.s==='D';
  d.className='card '+(red?'red':'blk');
  const img=(typeof CARD_IMG!=='undefined')?CARD_IMG[c.s+c.r]:null;
  if(img){
    d.classList.add('court');
    d.style.backgroundImage='url('+img+')';
  }else{
    d.innerHTML='<div class="tl">'+RANK_AR[c.r]+'<br>'+SUIT_CH[c.s]+'</div><div class="mid">'+SUIT_CH[c.s]+'</div>';
  }
  return d;
}
function cardHtmlSmall(c){
  return '<div class="card '+(c.s==='H'||c.s==='D'?'red':'blk')+'"><div class="tl">'+RANK_AR[c.r]+'<br>'+SUIT_CH[c.s]+'</div><div class="mid">'+SUIT_CH[c.s]+'</div></div>';
}
function bubble(v,txt,ms){
  const b=el('bub'+v); if(!b)return;
  b.textContent=txt;
  b.classList.add('show');
  clearTimeout(b._t);
  b._t=setTimeout(()=>b.classList.remove('show'),ms||1500);
}
function toast(txt,ms){
  const t=el('toast');
  t.textContent=txt;
  t.classList.add('show');
  clearTimeout(t._t);
  t._t=setTimeout(()=>t.classList.remove('show'),ms||2600);
}
function floatPts(x,y,txt){
  const f=document.createElement('div');
  f.className='float'; f.textContent=txt;
  f.style.left=x+'px'; f.style.top=y+'px';
  document.body.appendChild(f);
  setTimeout(()=>f.remove(),1200);
}

/* --- مؤقت الدور (أونلاين: شغال دائماً لأن السيرفر يحسب) --- */
let _timer=null;
function stopTimer(){
  if(_timer){clearInterval(_timer);_timer=null;}
  const ht=el('humanTimer'); if(ht)ht.style.display='none';
}
function startTimer(secs,onTimeout){
  stopTimer();
  secs=Math.max(3,secs||30);
  const total=secs*1000;
  let left=total;
  const ht=el('humanTimer');
  ht.style.display='flex';
  const draw=()=>{
    const pct=left/total*360;
    ht.style.background='conic-gradient(var(--sadu-gold) '+pct+'deg, rgba(255,255,255,.14) 0)';
    el('htNum').textContent=arNum(Math.ceil(left/1000));
  };
  draw();
  _timer=setInterval(()=>{
    left-=100;
    if(left<=0){stopTimer();onTimeout&&onTimeout();return;}
    if(left<=3000&&left%1000<100)tone(760,.06,'square',.05);
    draw();
  },100);
}

/* --- حالة العرض (مرآة لحالة السيرفر) --- */
let G={phase:'idle',roundNo:1,pot:0,high:0,top:-1,turn:-1};
let P=[];          // اللاعبون كما يرسلهم السيرفر (بمؤشرات السيرفر)
let myIdx=-1;      // مكاني في مصفوفة السيرفر
let myHand=[];     // أوراقي (خاصة بي فقط)
let myEval='';
let seatsBuilt=0;
let barUp=false;

/* ترجمة مقعد السيرفر إلى مقعد بصري (أنا دايماً مقعد ٠ تحت) */
const vIdx=s=>(s-myIdx+P.length)%P.length;
const sIdx=v=>(myIdx+v)%P.length;

const SEAT_POS={
  1:[[50,4]],
  2:[[88,28],[12,28]],
  3:[[92,45],[50,4],[8,45]],
  4:[[92,40],[68,2],[32,2],[8,40]],
  5:[[93,50],[76,4],[24,4],[7,50],[50,0]],
  6:[[93,55],[82,8],[58,0],[42,0],[18,8],[7,55]],
  7:[[93,58],[85,12],[68,0],[50,0],[32,0],[15,12],[7,58]],
};
function buildSeats(n){
  document.querySelectorAll('.seat.dyn').forEach(s=>s.remove());
  const stage=el('stage');
  stage.classList.toggle('crowded',n>5);
  const pos=SEAT_POS[n-1]||SEAT_POS[3];
  for(let v=1;v<n;v++){
    const s=sIdx(v);
    const [x,y]=pos[v-1];
    const seat=document.createElement('div');
    seat.className='seat dyn'+(y<40?' flip':'');
    seat.id='seat'+v;
    seat.style.left=x+'%'; seat.style.top=y+'%';
    seat.style.transform='translate(-50%,-50%)';
    seat.innerHTML='<div class="fan" id="fan'+v+'"></div>'
      +'<div class="reveal" id="rev'+v+'"></div>'
      +'<div class="seatname" id="name'+v+'">'+P[s].name+'</div>'
      +'<div class="seatbal" id="bal'+v+'"></div>'
      +'<div class="bubble" id="bub'+v+'"></div>';
    stage.appendChild(seat);
  }
  el('name0').textContent=P[myIdx].name;
}

/* --- رسم --- */
function renderBalances(){
  for(let v=0;v<P.length;v++){
    const s=sIdx(v);
    const b=el('bal'+v); if(!b)continue;
    b.textContent=P[s].out?'طالع':fmt(P[s].bal)+(P[s].rebuy?'':' ⚠️');
    b.classList.toggle('broke',!P[s].out&&P[s].bal<=1000);
    el('name'+v).classList.toggle('out',P[s].out);
  }
  if(myIdx>=0&&P[myIdx])el('myBal').textContent=fmt(P[myIdx].bal);
  el('roundLbl').textContent='جولة '+arNum(G.roundNo);
}
function renderFans(){
  for(let v=1;v<P.length;v++){
    const s=sIdx(v);
    const f=el('fan'+v); if(!f)continue;
    f.innerHTML='';
    if(P[s].out)continue;
    const n=P[s].cards||0;
    const mid=(n-1)/2;
    for(let i=0;i<n;i++){
      const c=document.createElement('div');
      c.className='card back fc';
      c.style.transform='rotate('+((i-mid)*12)+'deg)';
      if(P[s].folded)c.style.opacity='.35';
      f.appendChild(c);
    }
  }
}
function renderHand(animate){
  const h=el('hand'); h.innerHTML='';
  if(myIdx<0||!myHand.length)return;
  const me=P[myIdx]||{};
  const sorted=myHand.slice().sort((a,b)=>RV[b.r]-RV[a.r]||SUITS.indexOf(a.s)-SUITS.indexOf(b.s));
  sorted.forEach((c,i)=>{
    const w=document.createElement('div');
    w.className='fw';
    const d=cardEl(c);
    if(animate){d.classList.add('dealt'); d.style.animationDelay=(i*90)+'ms'; if(!muted)setTimeout(sndDeal,i*90);}
    if(me.folded)d.style.opacity='.4';
    w.appendChild(d);
    h.appendChild(w);
  });
  if(!me.folded&&myEval){
    const t=document.createElement('div');
    t.className='hint';
    t.style.position='absolute'; t.style.bottom='-4px'; t.style.width='100%';
    t.textContent='يدك: '+myEval;
    h.appendChild(t);
  }
}
function markTurn(turnS){
  const tv=turnS<0?-1:vIdx(turnS);
  for(let v=0;v<P.length;v++){const e=el('name'+v); if(e)e.classList.toggle('turn',v===tv);}
  if(tv!==0)stopTimer();
}
function setPot(sub){
  el('potAmt').textContent=fmt(G.pot);
  el('potSub').textContent=sub||'';
}
function potSub(){
  if(G.phase==='market'&&G.high>0&&G.top>=0&&P[G.top])
    return 'أعلى مزايدة: '+fmt(G.high)+' — '+P[G.top].name;
  if((G.phase==='settle'||G.phase==='offers'||G.phase==='showdown')&&G.pot>0){
    const sv=P.map((p,i)=>i).filter(i=>!P[i].out&&!P[i].folded);
    if(sv.length>1)return 'بين '+sv.map(i=>P[i].name).join(' و');
  }
  return '';
}
function actions(html){el('actions').innerHTML=html; barUp=!!html;}
function clearRoundVisuals(){
  for(let v=0;v<P.length;v++){
    const rv=el('rev'+v); if(rv)rv.innerHTML='';
    const t=el('htag'+v); if(t)t.remove();
  }
}

/* --- شريط الأكشنات (يرسل للسيرفر بدل ما يلعب محلياً) --- */
const send=o=>net.send(Object.assign({t:'game'},o));

function showBid(m){
  const mustOpen=m.mustOpen;
  const stepMin=mustOpen?m.minOpen:m.high+500;
  const maxBid=m.maxBid;
  const canStep=maxBid>=stepMin&&m.bal>=stepMin;
  let val=Math.min(stepMin,m.bal);
  const done=()=>{stopTimer();actions('');};
  const draw=()=>{
    let html='<div class="hint">'+(mustOpen
      ?'أنت فاتح السوق — أقل مزايدة <b>'+fmt(m.minOpen)+'</b> (بمضاعفات ٥٠٠)'
      :'أعلى مزايدة <b>'+fmt(m.high)+'</b> — مزايدتك الحالية '+fmt(m.stake)+' (بمضاعفات ٥٠٠)')+'</div>';
    if(canStep){
      html+='<div class="offerRow"><button id="oMin">−</button><div class="val">'+fmt(val)+'</div><button id="oPlus">+</button></div>';
      html+='<button class="gold" id="bBid">'+(mustOpen?'افتح بـ':'زايد ')+fmt(val)+'</button>';
    }
    if(m.canCall)html+='<button id="bCall">ماشي — '+fmt(m.high)+'</button>';
    html+='<button class="danger" id="bAll">الكل — '+fmt(m.bal)+'</button>';
    if(!mustOpen)html+='<button class="ghost" id="bFold">انسحاب</button>';
    actions(html);
    if(canStep){
      el('oMin').onclick=()=>{val=Math.max(stepMin,val-500);draw();};
      el('oPlus').onclick=()=>{val=Math.min(maxBid,val+500);draw();};
      el('bBid').onclick=()=>{send({a:mustOpen?'open':'raise',amount:val});done();};
    }
    if(m.canCall&&el('bCall'))el('bCall').onclick=()=>{send({a:'call'});done();};
    el('bAll').onclick=()=>{send({a:'allin'});done();};
    if(el('bFold'))el('bFold').onclick=()=>{send({a:'fold'});done();};
  };
  draw();
  startTimer(m.secs,()=>actions(''));
}

function showSettle(m){
  let offer=Math.min(Math.max(500,Math.round(m.high*0.5/500)*500),m.maxOffer);
  offer=Math.max(0,offer);
  const draw=()=>{
    const keep=m.pot-offer*m.opps;
    actions(
      '<div class="hint">الساحة <b>'+fmt(m.pot)+'</b> — تعطي كل واحد مبلغاً وياخذون هم قرارهم، وإلا داقشهم والأقوى ياخذ الكل</div>'
      +'<div class="offerRow"><button id="oMin">−</button><div class="val">'+fmt(offer)+'</div><button id="oPlus">+</button></div>'
      +'<div class="hint">لو كلهم وافقوا: لكل واحد '+fmt(offer)+' وأنت تاخذ الباقي <b>'+fmt(keep)+'</b></div>'
      +'<button class="gold" id="bDeal">اعرض الإرضاء 🤝</button>'
      +'<button class="danger" id="bFight">داقشهم ⚔️</button>'
    );
    el('oMin').onclick=()=>{offer=Math.max(0,offer-500);draw();};
    el('oPlus').onclick=()=>{offer=Math.min(m.maxOffer,offer+500);draw();};
    el('bDeal').onclick=()=>{stopTimer();actions('');send({a:'settle_deal',offer});};
    el('bFight').onclick=()=>{stopTimer();actions('');send({a:'settle_fight'});};
  };
  draw();
  startTimer(m.secs,()=>actions(''));
}

function showOffer(m){
  actions('<div class="hint">'+m.fromName+' يعرض عليك <b>'+fmt(m.offer)+'</b> إرضاء وتنسحب بسلام — وإلا داقشه (مزايدتك بالساحة: '+fmt(m.stake)+')</div>'
    +'<button class="gold" id="bYes">وافق — خذ '+fmt(m.offer)+'</button>'
    +'<button class="danger" id="bNo">داقشه ⚔️</button>');
  el('bYes').onclick=()=>{stopTimer();actions('');send({a:'offer_answer',accept:true});};
  el('bNo').onclick=()=>{stopTimer();actions('');send({a:'offer_answer',accept:false});};
  startTimer(m.secs,()=>actions(''));
}

/* --- أحداث السيرفر --- */
function onReveal(fighters){
  shake();
  for(const f of fighters){
    const v=vIdx(f.idx);
    const rv=el('rev'+v); if(!rv)continue;
    rv.innerHTML='';
    f.hand.forEach(c=>rv.appendChild(cardEl(c)));
    const old=el('htag'+v); if(old)old.remove();
    const tag=document.createElement('div');
    tag.className='handtag'; tag.id='htag'+v;
    tag.textContent=f.eval;
    el('seat'+v).insertBefore(tag,el('name'+v));
  }
  sndBad();
}

function onRoundEnd(m){
  stopTimer(); actions('');
  let html='<div class="resNote">'+m.note+'</div>';
  if(m.fighters){
    for(const f of m.fighters){
      const nm=P[f.idx]?P[f.idx].name:'؟';
      html+='<div class="line" style="display:flex;justify-content:space-between;align-items:center;gap:8px">'
        +'<b>'+nm+'</b><span style="font-size:13px">'+f.eval+'</span></div>';
      html+='<div class="resCards">'+f.hand.map(cardHtmlSmall).join('')+'</div>';
    }
  }
  html+='<div class="sep"></div><table class="resTbl"><thead><tr><th>اللاعب</th><th>الرصيد</th></tr></thead><tbody>';
  for(let i=0;i<P.length;i++)
    html+='<tr><td>'+P[i].name+(P[i].out?' 💀':'')+'</td><td class="'+(P[i].bal>=5000?'gain':'loss')+'">'+(P[i].out?'طالع':fmt(P[i].bal))+'</td></tr>';
  html+='</tbody></table>';
  if(m.events&&m.events.length)html+='<div class="line" style="font-size:14px;color:#7a4a10">'+m.events.join('<br>')+'</div>';
  el('rrBody').innerHTML=html;
  el('rrNext').textContent='الجولة التالية';
  el('roundPanel').classList.add('show');
}

function onGameOver(m){
  stopTimer(); actions('');
  el('roundPanel').classList.remove('show');
  const humanWon=m.winner===myIdx;
  const w=P[m.winner]||{name:'—',bal:0};
  let html='<div class="big">'+(humanWon?'🏆':'😔')+'</div>'
    +'<div class="resWin">'+(humanWon?'أنت آخر واحد واقف — كسبت المداقشة!':'الفائز: '+w.name+' بـ '+fmt(w.bal))+'</div>'
    +'<div class="sep"></div><table class="resTbl"><thead><tr><th>اللاعب</th><th>الرصيد النهائي</th></tr></thead><tbody>';
  for(const s of m.standings)html+='<tr><td>'+s.name+'</td><td>'+(s.out?'طالع 💀':fmt(s.bal))+'</td></tr>';
  html+='</tbody></table>';
  el('ovBody').innerHTML=html;
  el('ovNew').textContent='الرجوع للمجلس';
  el('overPanel').classList.add('show');
  (humanWon?sndWin:sndLose)();
}

/* ===== الاتصال ===== */
const net=new BasraNet();
if(!net.restoreSession()){
  location.replace('lobby.html');
}else{

net.on('open',()=>toast('متصل بالمجلس ✓',1200));
net.on('reconnecting',()=>toast('انقطع الاتصال — نرجعك للمجلس…',3000));
net.on('kicked',()=>{net.clearSession(); location.href='lobby.html';});
net.on('error',m=>{
  toast(m.msg||'صار خطأ');
  if(/انتهت|من جديد/.test(m.msg||''))setTimeout(()=>{net.clearSession(); location.href='lobby.html';},1500);
});

net.on('gstate',m=>{
  if(m.game&&m.game!=='madaqesh')return;
  P=m.players||[];
  G={phase:m.phase,roundNo:m.roundNo,pot:m.pot,high:m.high,top:m.top,turn:m.turn};
  myIdx=P.findIndex(p=>p.seat===net.seat);
  if(myIdx<0)return;
  if(seatsBuilt!==P.length){buildSeats(P.length); seatsBuilt=P.length;}
  if(barUp&&m.turn!==myIdx)actions(''); /* دوري فات (مهلة/تلقائي) — نزّل الشريط */
  renderBalances(); renderFans();
  if(myHand.length&&m.phase!=='dealing')renderHand(false);
  markTurn(m.turn);
  setPot(potSub());
  if(m.phase==='dealing'){
    el('roundPanel').classList.remove('show');
    clearRoundVisuals();
  }
});

net.on('ghand',m=>{
  myHand=m.hand||[];
  myEval=m.eval||'';
  if(G.phase!=='dealing')renderHand(false);
});

net.on('gturn',m=>{
  if(m.kind==='bid')showBid(m);
  else if(m.kind==='settle')showSettle(m);
  else if(m.kind==='offer')showOffer(m);
});

net.on('gevent',m=>{
  switch(m.k){
    case 'bubble': bubble(vIdx(m.idx),m.txt); break;
    case 'toast': toast(m.txt); break;
    case 'sound': playSound(m.name); break;
    case 'shake': shake(); break;
    case 'float':{
      const st=el('seat'+vIdx(m.idx));
      if(st){const r=st.getBoundingClientRect(); floatPts(r.left+r.width/2,r.top,arNum(m.txt));}
      break;
    }
    case 'deal': renderFans(); renderHand(true); break;
    case 'reveal': onReveal(m.fighters||[]); break;
    case 'round_end': onRoundEnd(m); break;
    case 'game_over': onGameOver(m); break;
  }
});

/* ===== القائمة والإعدادات ===== */
function syncUI(){
  el('muteBtn').textContent=muted?'🔇':'🔊';
  el('setSound').textContent=muted?'مطفي 🔇':'شغال 🔊';
}
el('muteBtn').onclick=()=>{muted=!muted;SETTINGS.sound=!muted;saveSettings();syncUI();};
el('setSound').onclick=()=>{muted=!muted;SETTINGS.sound=!muted;saveSettings();syncUI();};
el('setClose').onclick=()=>el('setPanel').classList.remove('show');
el('menuSettings').onclick=()=>{syncUI();el('setPanel').classList.add('show');};
el('menuBtn').onclick=()=>el('menu').classList.add('show');
el('menuResume').style.display='';
el('menuResume').textContent='كمّل اللعب';
el('menuResume').onclick=()=>el('menu').classList.remove('show');
el('menuNew').textContent='خروج من المجلس';
el('menuNew').onclick=()=>{net.send({t:'leave'}); net.clearSession(); location.href='lobby.html';};
el('rrNext').onclick=()=>{el('roundPanel').classList.remove('show'); send({a:'next'});};
el('ovNew').onclick=()=>{net.clearSession(); location.href='lobby.html';};
/* تخبية أشياء الأوفلاين اللي ما لها معنى أونلاين */
el('pMin').closest('.mrow').style.display='none';
el('setTimer').closest('.line').style.display='none';

/* إقلاع */
syncUI();
toast('جاري الاتصال بالمجلس…',4000);
net.connect();
}
