/* ================== بلوت أونلاين — عميل اللعب ================== */
const el=id=>document.getElementById(id);
const SUIT_CH={H:'♥',D:'♦',C:'♣',S:'♠'};
const RANK_AR={'7':'7','8':'8','9':'9','10':'10',J:'J',Q:'Q',K:'K',A:'A'};
const AR_D=['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
const arNum=n=>String(n).split('').map(ch=>/\d/.test(ch)?AR_D[+ch]:ch).join('');
let muted=true;

function cardEl(c){
  const d=document.createElement('div');
  const red=c.s==='H'||c.s==='D';
  d.className='card '+(red?'red':'blk');
  const img=(typeof CARD_IMG!=='undefined')?CARD_IMG[c.s+c.r]:null;
  if(img){d.classList.add('court'); d.style.backgroundImage='url('+img+')';}
  else d.innerHTML='<div class="tl">'+RANK_AR[c.r]+'<br>'+SUIT_CH[c.s]+'</div><div class="mid">'+SUIT_CH[c.s]+'</div>';
  return d;
}
function bubble(idx,txt,ms){
  const b=el('bub'+idx); if(!b)return;
  b.textContent=txt; b.classList.add('show');
  setTimeout(()=>b.classList.remove('show'),ms||1500);
}
function toast(txt,ms){
  const t=el('toast'); t.textContent=txt; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),ms||2600);
}
function actions(html){el('actions').innerHTML=html||'';}

let G=null, myHand=[], myIdx=-1, P=[], plays=[];
const NAMES=['أنت','حمد','مشاري','سعيد'];

function renderFloor(floor){
  const fc=el('floorCard'); if(!fc||!floor)return;
  fc.innerHTML=''; fc.appendChild(cardEl(floor));
}
function renderPlays(){
  for(let i=0;i<4;i++){const s=el('slot'+i); if(s)s.innerHTML='';}
  for(const pl of plays){
    const s=el('slot'+pl.p); if(!s)continue;
    s.innerHTML=''; s.appendChild(cardEl(pl.card));
  }
}
function renderPiles(tricks){
  for(let t=0;t<2;t++){const pc=el('pc'+t); if(pc)pc.textContent=arNum(tricks[t]||0);}
}
function renderHand(){
  const h=el('hand'); h.innerHTML='';
  myHand.forEach((c,i)=>{
    const w=document.createElement('div'); w.className='fw';
    const d=cardEl(c); w.appendChild(d); h.appendChild(w);
  });
}
function markTurn(p){
  for(let i=0;i<4;i++){const n=el('name'+i); if(n)n.classList.toggle('turn',i===p);}
}
function updateMode(mode,trump,buyer){
  const label=mode==='hokom'?('حكم '+SUIT_CH[trump]):(mode==='sun'?'صن':'أشكل');
  const pm=el('padMode'); if(pm)pm.textContent=label+' — المشتري: '+(P[buyer]?P[buyer].name:'');
}

/* ========== ربط السيرفر ========== */
const net=new BasraNet();
if(!net.restoreSession()){location.replace('lobby.html');}
else{
net.on('open',()=>toast('متصل ✓',1200));
net.on('kicked',()=>{net.clearSession(); location.href='lobby.html';});
net.on('error',m=>toast(m.msg||'خطأ'));

net.on('gstate',s=>{
  if(s.game&&s.game!=='baloot')return;
  P=s.players||[];
  myIdx=P.findIndex(p=>p.seat===net.seat);
  G=s;
  plays=s.plays||[];
  markTurn(s.turn);
  renderPlays();
  renderPiles(s.tricks);
  updateMode(s.mode,s.trump,s.buyer);
  if(s.floor)renderFloor(s.floor);
  for(let i=0;i<4;i++){const n=el('name'+i); if(n&&P[i])n.textContent=P[i].name;}
});

net.on('ghand',m=>{myHand=m.hand||[]; renderHand();});

net.on('gturn',m=>{
  if(m.kind==='bid'){
    let html='<div class="hint">'+(m.lap===1?'اللفة الأولى':'اللفة الثانية')+'</div>';
    if(m.lap===1)html+='<button class="gold" id="bHokom">حكم '+SUIT_CH[m.floor.s]+'</button>';
    else html+='<button class="gold" id="bHokom2">حكم ثاني</button>';
    html+='<button class="gold" id="bSun">صن</button>';
    if(m.ashkalOk)html+='<button class="gold" id="bAshkal">أشكل</button>';
    html+='<button id="bPass">'+(m.lap===1?'بس':(myIdx===G.dealer?'ورق':'ولا'))+'</button>';
    if(m.canKasho)html+='<button class="danger" id="bKasho">كاشو</button>';
    actions(html);
    if(el('bHokom'))el('bHokom').onclick=()=>{actions(''); net.send({t:'game',a:'buy',mode:'hokom',trump:m.floor.s});};
    if(el('bHokom2'))el('bHokom2').onclick=()=>{
      let h='<div class="hint">اختر لون الحكم</div>';
      for(const s of ['H','D','C','S']){if(s===m.floor.s)continue; h+='<button class="gold" data-s="'+s+'">'+SUIT_CH[s]+'</button>';}
      actions(h);
      document.querySelectorAll('#actions [data-s]').forEach(b=>b.onclick=()=>{actions(''); net.send({t:'game',a:'buy',mode:'hokom',trump:b.dataset.s});});
    };
    if(el('bSun'))el('bSun').onclick=()=>{actions(''); net.send({t:'game',a:'buy',mode:'sun'});};
    if(el('bAshkal'))el('bAshkal').onclick=()=>{actions(''); net.send({t:'game',a:'buy',mode:'ashkal'});};
    if(el('bPass'))el('bPass').onclick=()=>{actions(''); net.send({t:'game',a:'pass'});};
    if(el('bKasho'))el('bKasho').onclick=()=>{actions(''); net.send({t:'game',a:'kasho'});};
  }
  if(m.kind==='play'){
    const legal=m.legal||[];
    renderHand();
    const handEls=el('hand').querySelectorAll('.card');
    handEls.forEach((d,i)=>{
      const c=myHand[i];
      const can=legal.includes(c.id);
      if(can){d.classList.add('ok'); d.onclick=()=>net.send({t:'game',a:'play',card:c.id});}
      else d.classList.add('dim');
    });
    actions('');
  }
});

net.on('gevent',e=>{
  if(e.k==='deal'){plays=[]; for(let i=0;i<4;i++){const s=el('slot'+i); if(s)s.innerHTML='';} toast('توزيع جديد!');}
  if(e.k==='play'){plays.push({p:e.idx,card:e.card}); renderPlays();}
  if(e.k==='trick'){toast(NAMES[e.winner]+' أخذ الأكلة'); plays=[]; setTimeout(renderPlays,500); renderPiles(G.tricks);}
  if(e.k==='bubble')bubble(e.idx,e.txt);
  if(e.k==='proj_reveal')toast('مشاريع '+NAMES[e.idx]);
  if(e.k==='round_end'){
    let html='<div class="resWin">'+e.note+'</div>';
    html+='<table class="resTbl"><thead><tr><th>الفريق</th><th>النقاط</th></tr></thead><tbody>';
    html+='<tr><td>لنا</td><td>'+arNum(e.score[0])+'</td></tr>';
    html+='<tr><td>لهم</td><td>'+arNum(e.score[1])+'</td></tr>';
    html+='</tbody></table>';
    el('resBody').innerHTML=html;
    el('resultPanel').classList.add('show');
  }
  if(e.k==='game_over'){
    const w=e.winners[0]===0?'🏆 فزنا بالصكة!':'الصكة راحت لهم';
    el('resBody').innerHTML='<div class="resWin">'+w+'</div>';
    el('resultPanel').classList.add('show');
  }
});

el('nextBtn').onclick=()=>{el('resultPanel').classList.remove('show');};
el('muteBtn').onclick=()=>{muted=!muted; el('muteBtn').textContent=muted?'🔇':'🔊';};
net.connect();
}
