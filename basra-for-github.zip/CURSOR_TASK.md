# مهمة: إكمال منصة باصرة كاردز — محركات الأونلاين للألعاب المتبقية

## سياق المشروع (اقرأ أولاً)
منصة ألعاب ورق عربية (HTML خالص بدون فريمورك + Node.js/WebSocket).
السيرفر في `server/server.js` ويشتغل بـ `npm run dev` على المنفذ 3100.

**البنية المعتمدة لأي لعبة أونلاين (مثال حي = مداقش):**
1. `server/games/madaqesh.js` — محرك السيرفر: كلاس `MadaqeshGame(room, api)` هو الحكم الوحيد
   على الأوراق والرصيد. الـ api = `{ toSeat(seat,obj), broadcastAll(obj), onGameOver() }`.
2. `madaqesh_script.js` — منطق اللعبة الصافي (قابل للـ require من السيرفر وقابل للتضمين
   بوسم <script> في المتصفح)، مستخرج من نسخة الأوفلاين حتى تتطابق القوانين 100%.
3. `madaqesh_online.html` + يستخدم `online/online.js` (كلاس BasraNet) — واجهة اللعب الأونلاين.
4. في `server/server.js`: سجل اللعبة في `GAME_FILE` وأنشئ المحرك في case 'start'.

**بروتوكول الرسائل القائم (لا تكسره):**
- عميل→سيرفر: create / join / resume / ready / add_bot / remove_bot / kick / start / leave / game
- سيرفر→عميل: created / joined / room / started{file} / kicked / error
- محرك→عميل: gstate (حالة عامة), ghand (يد خاصة لكل مقعد), gevent (أحداث: bubble/toast/deal)
- عميل→محرك: {t:'game', ...action} يوصل لـ engine.onAction(seat, m)
- المحرك لازم يوفّر: start() و destroy() و resync(seat) و onAction(seat, msg)
- الخلط بـ crypto.randomInt (عدالة تشفيرية)، والبوتات تلعب من داخل المحرك بتأخير ~1.1ث

## المطلوب بالترتيب

### 1) استخراج المنطق الصافي لكل لعبة
من ملفات الأوفلاين `baloot.html` و`sevens.html` و`hand.html` استخرج:
`baloot_script.js` و`sevens_script.js` و`hand_script.js` بنفس نمط `madaqesh_script.js`:
- كلاس/دوال خالصة بدون DOM: mkDeck، توزيع، تقييم، قوانين اللعب كاملة، ذكاء بوت
- تصدير مزدوج: `module.exports` للسيرفر + تعليق على window للمتصفح
- لا تغيّر أي قانون — نقل حرفي للمنطق

### 2) محركات سيرفر لكل لعبة
أنشئ `server/games/baloot.js` و`server/games/sevens.js` و`server/games/hand.js`
بنفس معمارية `MadaqeshGame` حرفياً:
- مؤقتات الأدوار، حارس الجولة gid، مهلة انقطاع، بوتات مدمجة
- gstate يبث الحالة العامة فقط، الأوراق ترسل بـ ghand لكل مقعد لحاله (ممنوع تسريب أوراق)
- onGameOver يرجع الغرفة للوبي

### 3) صفحات اللعب الأونلاين
أنشئ `baloot_online.html` و`sevens_online.html` و`hand_online.html` بإعادة استخدام
واجهات الأوفلاين + ربط BasraNet بنفس نمط `madaqesh_online.html`
(عندك `inject_madaqesh_online.js` كمرجع لطريقة الحقن).

### 4) تحديث السيرفر
- `GAME_FILE`: أضف baloot/sevens/hand لملفاتهم الجديدة
- في case 'start': factory موحد يختار الكلاس حسب room.game بدل if واحدة
- تحقق من min/max: بلوت 4، سبعة الديمن 4، الهاند 4

### 5) اختبارات
- وسّع `server/test_rooms.js` ليغطي إنشاء غرفة لكل لعبة، بدء اللعبة، جولة كاملة مع بوتات
- لكل لعبة: سكربت محاكاة بوتات يلعبون 10 جولات بدون أخطاء وبدون تعليق مؤقتات
- `node server/test_game_madaqesh.js` مرجع للنمط

### 6) تنظيف
احذف ملفات الفحص المؤقتة من الجذر: `_check.js` `_chk_*.js` `_icheck.js` `_mcheck.js`
`_sim.js` وملفات النسخ القديمة `baloot_v24_1.html` `index_12.html` `index_13.html`
و`*_view.html` — بعد التأكد أن ما فيها شي مستخدم.

## قيود صارمة
- لا تكسر مداقش — هو المرجع الشغّال، أي تعديل مشترك لازم يبقيه يشتغل
- لا مكتبات جديدة غير ws الموجودة
- كل النصوص عربية RTL، التعليقات بالعربي بنفس أسلوب الكود الحالي
- لا تلمس buy.html و terms.html و index.html إلا إذا احتجت رابط للعبة جديدة
