/* ================== منطق صافي (بدون واجهة) ================== */
const SUIT_CH = {H:'♥', D:'♦', C:'♣', S:'♠'};
const SUITS = ['H','D','C','S'];
const RANKS = ['7','8','9','10','J','Q','K','A'];
const RANK_AR = {'7':'7','8':'8','9':'9','10':'10','J':'J','Q':'Q','K':'K','A':'A'};
const SUN_PTS   = {A:11,'10':10,K:4,Q:3,J:2,'9':0,'8':0,'7':0};
const TRUMP_PTS = {J:20,'9':14,A:11,'10':10,K:4,Q:3,'8':0,'7':0};
const SUN_STR   = {A:7,'10':6,K:5,Q:4,J:3,'9':2,'8':1,'7':0};
const TRUMP_STR = {J:7,'9':6,A:5,'10':4,K:3,Q:2,'8':1,'7':0};

function mkDeck(){
  const d=[];
  for(const s of SUITS)for(const r of RANKS)d.push({s,r,id:s+r});
  return d;
}
function shuffle(d,rnd){
  rnd = rnd || Math.random;
  for(let i=d.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[d[i],d[j]]=[d[j],d[i]];}
  return d;
}
function isSunMode(mode){return mode==='sun'||mode==='ashkal';}
function cardPts(c,mode,trump){
  if(mode==='hokom'&&c.s===trump)return TRUMP_PTS[c.r];
  return SUN_PTS[c.r];
}
function cardStr(c,mode,trump){
  if(mode==='hokom'&&c.s===trump)return TRUMP_STR[c.r];
  return SUN_STR[c.r];
}
function beats(a,b,led,mode,trump){
  const at=mode==='hokom'&&a.s===trump, bt=mode==='hokom'&&b.s===trump;
  if(at&&!bt)return true;
  if(!at&&bt)return false;
  if(at&&bt)return cardStr(a,mode,trump)>cardStr(b,mode,trump);
  if(a.s!==led)return false;
  if(b.s!==led)return true;
  return cardStr(a,mode,trump)>cardStr(b,mode,trump);
}
function trickWinner(plays,mode,trump){
  const led=plays[0].card.s;
  let best=0;
  for(let i=1;i<plays.length;i++)
    if(beats(plays[i].card,plays[best].card,led,mode,trump))best=i;
  return best;
}
function legalMoves(hand,plays,player,partner,mode,trump,closed){
  const allTrump = mode==='hokom' && trump && hand.every(c=>c.s===trump);
  if(!plays.length){
    if(closed && !allTrump){
      const nonTrump=hand.filter(c=>c.s!==trump);
      if(nonTrump.length)return nonTrump;
    }
    return hand.slice();
  }
  const led=plays[0].card.s;
  const same=hand.filter(c=>c.s===led);
  if(isSunMode(mode))return same.length?same:hand.slice();
  const wi=trickWinner(plays,mode,trump);
  const winning=plays[wi];
  const partnerWinning=winning.p===partner;
  if(same.length){
    if(led===trump){
      const higher=same.filter(c=>beats(c,winning.card,led,mode,trump));
      return higher.length?higher:same;
    }
    return same;
  }
  const trumps=hand.filter(c=>c.s===trump);
  if(partnerWinning){
    if(closed && !allTrump){
      const nonTrump=hand.filter(c=>c.s!==trump);
      if(nonTrump.length)return nonTrump;
    }
    return hand.slice();
  }
  if(!trumps.length)return hand.slice();
  const trickTrumped=winning.card.s===trump;
  if(trickTrumped){
    const over=trumps.filter(c=>cardStr(c,mode,trump)>cardStr(winning.card,mode,trump));
    if(over.length)return over;
    if(closed && !allTrump){
      const nonTrump=hand.filter(c=>c.s!==trump);
      if(nonTrump.length)return nonTrump;
    }
    return hand.slice();
  }
  return trumps;
}
function canDouble(team,mode,score){
  if(mode==='hokom')return true;
  return score[0]>=100 || score[1]>=100;
}
function qablakEligible(order,buyer){
  const bi=order.indexOf(buyer);
  return bi<=0?[]:order.slice(0,bi);
}
function isAkeh(card,unseen,mode,trump){
  if(mode!=='hokom'||card.s===trump)return false;
  return !unseen.some(u=>u.s===card.s&&cardStr(u,mode,trump)>cardStr(card,mode,trump));
}
function kashoEligible(hand5){
  return hand5.length===5 && hand5.every(c=>c.r==='7'||c.r==='8'||c.r==='9');
}
function detectProjects(hand,mode){
  const sun=isSunMode(mode);
  const key=c=>c.s+c.r;
  const used=new Set(), out=[];
  const mkSeq=(idxRun,s)=>{
    const cards=idxRun.map(i=>({s,r:RANKS[i]}));
    if(idxRun.length>=5)return{type:'mia',name:'مية',rank:3,abnat:sun?20:10,cards:cards.slice(-5)};
    if(idxRun.length===4)return{type:'fifty',name:'خمسين',rank:2,abnat:sun?10:5,cards};
    if(idxRun.length===3)return{type:'sira',name:'سرا',rank:1,abnat:sun?4:2,cards};
    return null;
  };
  const fours=[];
  for(const r of ['A','K','Q','J','10']){
    if(hand.filter(c=>c.r===r).length===4){
      const cards=SUITS.map(s=>({s,r}));
      if(r==='A'&&sun)fours.push({type:'arb400',name:'أربع مية',rank:4,abnat:40,cards});
      else fours.push({type:'mia4',name:'مية',rank:3,abnat:sun?20:10,cards});
    }
  }
  fours.sort((a,b)=>b.rank-a.rank);
  for(const pr of fours){
    if(pr.cards.some(c=>used.has(key(c))))continue;
    pr.cards.forEach(c=>used.add(key(c)));
    out.push(pr);
  }
  for(const s of SUITS){
    const idx=hand.filter(c=>c.s===s&&!used.has(key(c)))
                  .map(c=>RANKS.indexOf(c.r)).sort((a,b)=>a-b);
    let run=[];
    const flush=()=>{const pr=mkSeq(run,s); if(pr){pr.cards.forEach(c=>used.add(key(c)));out.push(pr);} run=[];};
    for(let i=0;i<idx.length;i++){
      if(run.length&&idx[i]===run[run.length-1]+1)run.push(idx[i]);
      else{flush();run=[idx[i]];}
    }
    flush();
  }
  return out;
}
function resolveProjects(projByPlayer,teamOf,playOrder){
  const best=[0,0];
  for(let p=0;p<4;p++)for(const pr of projByPlayer[p])
    best[teamOf(p)]=Math.max(best[teamOf(p)],pr.rank);
  let winTeam=-1;
  if(best[0]>best[1])winTeam=0;
  else if(best[1]>best[0])winTeam=1;
  else if(best[0]>0){
    for(const p of playOrder){
      if(projByPlayer[p].some(pr=>pr.rank===best[0])){winTeam=teamOf(p);break;}
    }
  }
  return winTeam;
}
function sureWinner(c,unseen,mode,trump){
  if(mode==='hokom'){
    if(c.s===trump)
      return !unseen.some(u=>u.s===trump&&cardStr(u,mode,trump)>cardStr(c,mode,trump));
    if(unseen.some(u=>u.s===trump))return false;
    return !unseen.some(u=>u.s===c.s&&cardStr(u,mode,trump)>cardStr(c,mode,trump));
  }
  return !unseen.some(u=>u.s===c.s&&cardStr(u,mode,trump)>cardStr(c,mode,trump));
}
function scoreRound(o){
  const sun=isSunMode(o.mode);
  const kaboot0=o.tricks[0]===8, kaboot1=o.tricks[1]===8;
  const baseTotal=sun?(kaboot0||kaboot1?44:26):(kaboot0||kaboot1?25:16);
  const a=[0,0];
  const lines=[];
  if(kaboot0||kaboot1){
    const w=kaboot0?0:1;
    a[w]=baseTotal;
    lines.push('كبوت!');
  }else{
    const div=sun?5:10;
    const other=o.teamPts[1-o.buyerTeam];
    let os=Math.floor(other/div)+((other%div)*2>=div?1:0);
    os=Math.min(os,baseTotal);
    a[o.buyerTeam]=baseTotal-os;
    a[1-o.buyerTeam]=os;
  }
  a[0]+=o.projAbnat[0]+o.balootAbnat[0];
  a[1]+=o.projAbnat[1]+o.balootAbnat[1];
  let khosara=false;
  if(a[o.buyerTeam]<=a[1-o.buyerTeam]){
    khosara=true;
    const all=a[0]+a[1];
    a[1-o.buyerTeam]=all; a[o.buyerTeam]=0;
    lines.push('المشتري انكبت — خسرانة!');
  }
  let winner=a[0]>=a[1]?0:1;
  if(a[0]===a[1])winner=1-o.buyerTeam;
  if(o.mult>1&&!o.coffee){
    const all=(a[0]+a[1])*o.mult;
    a[0]=0;a[1]=0;a[winner]=all;
    lines.push('مضاعفة ×'+o.mult+' — الكاسب ياخذ الكل');
  }
  return{abnat:a,winner,khosara,kaboot:kaboot0||kaboot1,lines};
}

/* ================== ذكاء اللاعب الآلي ================== */
const teamOf=p=>p%2;

/* قرار المزايدة:
   hand=8 أوراق، floor=الورقة المكشوفة، lap=1|2، p=0..3، dealer=0..3
   out: {act:'buy',mode,trump} | {act:'pass'} | {act:'kasho'} */
function aiBid(hand, floor, lap, p, dealer){
  // كاشو تلقائي
  if(kashoEligible(hand.slice(0,5)))return {act:'kasho'};
  const hkScore=s=>{
    let v=0;
    for(const c of hand){
      if(c.s===s){v+=1; if(c.r==='J')v+=3; if(c.r==='9')v+=2; if(c.r==='A')v+=1;}
      else if(c.r==='A')v+=.6;
    }
    if(s===floor.s){
      if(floor.r==='J')v+=2.5; else if(floor.r==='9')v+=1.5; else v+=.5;
    }
    return v;
  };
  const aces=hand.filter(c=>c.r==='A').length;
  const tens=hand.filter(c=>c.r==='10').length;
  const sunV=aces*2+tens*1.2+hand.filter(c=>c.r==='K').length*.5;
  const ashkalOk = p===dealer || p===(dealer+3)%4;
  if(lap===1){
    if(sunV>=5.5)return {act:'buy', mode: ashkalOk&&Math.random()<.5?'ashkal':'sun', trump:null};
    if(hkScore(floor.s)>=6)return {act:'buy', mode:'hokom', trump:floor.s};
  }else{
    if(sunV>=5)return {act:'buy', mode: ashkalOk&&Math.random()<.5?'ashkal':'sun', trump:null};
    let bestS=null,bestV=0;
    for(const s of SUITS){if(s===floor.s)continue;const v=hkScore(s);if(v>bestV){bestV=v;bestS=s;}}
    if(bestV>=6.5)return {act:'buy', mode:'hokom', trump:bestS};
  }
  return {act:'pass'};
}

/* قرار اللعب:
   hand=أوراقي، plays=ما لُعب، mode، trump، closed، playedIds=Set، partner=0..3
   out: الورقة المختارة (null إذا ما فيه حركات) */
function aiPlay(hand, plays, mode, trump, closed, playedIds, partner, akehSuit){
  const legal=legalMoves(hand,plays,0,partner,mode,trump,closed);
  if(!legal.length)return null;
  const byPts=(a,b)=>cardPts(a,mode,trump)-cardPts(b,mode,trump);
  const byStr=(a,b)=>cardStr(a,mode,trump)-cardStr(b,mode,trump);
  if(!plays.length){
    const un=mkDeck().filter(c=>!(playedIds&&playedIds.has(c.id))&&!hand.some(h=>h.id===c.id));
    const sure=legal.filter(c=>sureWinner(c,un,mode,trump));
    return sure.length?sure.sort(byPts).pop():legal.slice().sort(byPts)[0];
  }else{
    const wi=trickWinner(plays,mode,trump);
    const partnerWinning=plays[wi].p===partner;
    const winners=legal.filter(c=>{
      const test=plays.concat([{p:0,card:c}]);
      return trickWinner(test,mode,trump)===test.length-1;
    });
    const last=plays.length===3;
    const akehGuard = partnerWinning && mode==='hokom' && akehSuit===plays[0].card.s;
    if(akehGuard){
      const noTrump=legal.filter(c=>c.s!==trump);
      if(noTrump.length)return noTrump.slice().sort(byPts).pop();
    }
    if(partnerWinning&&(last||cardStr(plays[wi].card,mode,trump)>=6)){
      let pick=legal.slice().sort(byPts).pop();
      if(cardPts(pick,mode,trump)===0)pick=legal.slice().sort(byStr)[0];
      return pick;
    }else if(winners.length){
      return winners.slice().sort(byStr)[0];
    }else{
      return legal.slice().sort(byPts)[0];
    }
  }
}

/* ================== تصدير مزدوج ================== */
if(typeof module!=='undefined'){
  module.exports={SUIT_CH,SUITS,RANKS,RANK_AR,SUN_PTS,TRUMP_PTS,SUN_STR,TRUMP_STR,
    mkDeck,shuffle,isSunMode,cardPts,cardStr,beats,trickWinner,legalMoves,
    canDouble,qablakEligible,isAkeh,kashoEligible,detectProjects,resolveProjects,
    sureWinner,scoreRound,teamOf,aiBid,aiPlay};
}
