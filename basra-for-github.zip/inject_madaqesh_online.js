const fs=require('fs');
const path=require('path');
const dir=__dirname;
const baloot=fs.readFileSync(path.join(dir,'baloot_v24_1.html'),'utf8');
const tpl=fs.readFileSync(path.join(dir,'madaqesh_template.html'),'utf8');
const script=fs.readFileSync(path.join(dir,'madaqesh_online_script.js'),'utf8');

// 1) ظهر الورقة: أول data:image/jpeg داخل CSS
const back=(baloot.match(/data:image\/jpeg;base64,[A-Za-z0-9+/=]+/)||[])[0];
if(!back)throw new Error('card back not found');

// 2) الخط woff2
const font=(baloot.match(/data:font\/woff2;base64,[A-Za-z0-9+/=]+/)||[])[0];
if(!font)throw new Error('font not found');

// 3) CARD_IMG كاملة
const s=baloot.indexOf('const CARD_IMG=');
const e=baloot.indexOf('function cardEl');
if(s<0||e<0)throw new Error('CARD_IMG not found');
const cardImgDef=baloot.slice(s,e).trim();

let out=tpl
  .replace('__CARD_BACK__',back)
  .replace('__FONT_B64__',font)
  .replace('__SCRIPT__',()=>script.replace('__CARD_IMG_DEF__',()=>cardImgDef));

// 4) صفحة الأونلاين تحتاج مكتبة الاتصال قبل سكربت اللعبة
out=out.replace('<script>\n\'use strict\';',
  '<script src="online/online.js"></script>\n<script>\n\'use strict\';');

fs.writeFileSync(path.join(dir,'madaqesh_online.html'),out);
console.log('OK size=',out.length);
