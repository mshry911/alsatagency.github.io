/* ================== منطق صافي (بدون واجهة) ================== */
const L=(function(){
/* ================== منطق سبعة الديمن (نقي وقابل للاختبار) ================== */
const SUITS=['D','H','C','S'];               // ديمن، كبة، سباتي، سبيت
const RANKS=['7','8','9','10','J','Q','K','A'];   // شدة البلوت: ٣٢ ورقة
const RIDX={};RANKS.forEach((r,i)=>RIDX[r]=i);
const SEVEN=RIDX['7'];                        // موضع السبعة = 5

function mkDeck(){
  const d=[];
  for(const s of SUITS)for(const r of RANKS)d.push({s,r,id:s+r});
  return d;
}
function shuffle(a,rnd){
  const R=rnd||Math.random;
  for(let i=a.length-1;i>0;i--){const j=Math.floor(R()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  return a;
}
/* الطاولة: لكل لون {lo,hi} أو null إذا المسار مقفل.
   lo = أقل رتبة نازلة، hi = أعلى رتبة صاعدة (كلاهما = 5 عند فتح السبعة) */
function newBoard(){return {D:null,H:null,C:null,S:null};}

/* هل الطاولة فاضية تماماً؟ (بداية الجولة) */
function isEmpty(board){return !board.D&&!board.H&&!board.C&&!board.S;}
/* هل يمكن إنزال هذه الورقة؟ */
function canPlay(card,board){
  // بداية الجولة: ٧ الديمن حصراً
  if(isEmpty(board))return card.id==='D7';
  const t=board[card.s], i=RIDX[card.r];
  if(!t)return i===SEVEN;             // مسار مقفل: السبعة فقط تفتحه
  return i===t.hi+1;                  // صاعد فقط، وممنوع القفز
}
/* كل الحركات القانونية في اليد */
function legalMoves(hand,board){return hand.filter(c=>canPlay(c,board));}

/* إنزال ورقة (يُفترض أنها قانونية) — يعيد نسخة محدثة من الطاولة */
function place(card,board){
  const b={D:board.D,H:board.H,C:board.C,S:board.S};
  const i=RIDX[card.r], t=b[card.s];
  if(!t)b[card.s]={lo:SEVEN,hi:SEVEN};
  else if(i===t.hi+1)b[card.s]={lo:t.lo,hi:i};
  return b;
}
/* من يبدأ: صاحب ٧ الديمن */
function starterOf(hands){
  for(let p=0;p<hands.length;p++)
    if(hands[p].some(c=>c.id==='D7'))return p;
  return 0;
}
/* النقاط الجزائية: النظام البسيط = ورقة واحدة بنقطة */
function penalty(hand){return hand.length;}

/* ================== ذكاء اللاعب الآلي ================== */
/* عدد الأوراق التي ما زالت محجوزة خلف هذه الورقة في يدي (تكتيك الحصار) */
function blockValue(card,hand,board){
  const i=RIDX[card.r], t=board[card.s];
  const mine=hand.filter(c=>c.s===card.s).map(c=>RIDX[c.r]);
  if(!t)return mine.filter(x=>x!==SEVEN).length;  // فتح السبعة: كم ورقة تستفيد
  return mine.filter(x=>x>i).length;              // كم ورقة أعلى منها عندي تنفتح
}
/* هل بعد إنزال هذه الورقة تنفتح ورقة عندي مباشرة؟ */
function unlocksMine(card,hand,board){
  const b=place(card,board);
  const rest=hand.filter(c=>c.id!==card.id);
  return legalMoves(rest,b).length - legalMoves(rest,board).length;
}
/* اختيار حركة الذكاء:
   يفضّل ما يفتح له أوراقه، ويؤجل ما يخدم الخصوم (خاصة السبعات التي لا تفيده) */
function aiChoose(hand,board,rnd){
  const legal=legalMoves(hand,board);
  if(!legal.length)return null;
  const R=rnd||Math.random;
  let best=null,bestScore=-1e9;
  for(const c of legal){
    const i=RIDX[c.r], t=board[c.s];
    let sc=0;
    sc += blockValue(c,hand,board)*3;      // تفتح لي أوراقي
    sc += unlocksMine(c,hand,board)*6;     // تفتح لي حركة فورية
    if(!t){                                 // إنزال سبعة
      const mineSame=hand.filter(x=>x.s===c.s).length-1;
      sc -= 7;                              // تجميد السبعات مبدئياً
      sc += mineSame*4;                     // إلا إذا عندي أوراق كثيرة بنفس اللون
    }else{
      // كلما اقتربت من الإكة قلّ نفعها للخصوم
      const dist = RANKS.length-1-i;
      sc += (4-Math.min(dist,4));
    }
    sc += R()*0.5;                          // كسر التعادل
    if(sc>bestScore){bestScore=sc;best=c;}
  }
  return best;
}

return {SUITS,RANKS,RIDX,SEVEN,mkDeck,shuffle,newBoard,canPlay,legalMoves,isEmpty,place,starterOf,penalty,aiChoose};
})();

/* ================== تصدير مزدوج ================== */
if(typeof module!=='undefined'){
  module.exports=L;
}
