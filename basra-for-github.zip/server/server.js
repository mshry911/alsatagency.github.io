/* ============================================================
   سيرفر باصرة — الغرف واللوبي + محركات الأونلاين
   يشتغل بأمر: node server.js
   على Render: npm start
   ============================================================ */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const { MadaqeshGame } = require('./games/madaqesh');
const { BalootGame } = require('./games/baloot');
const { SevensGame } = require('./games/sevens');
const { HandGame } = require('./games/hand');

const ROOT = path.join(__dirname, '..');
/* المنفذ: --port من سطر الأوامر، أو متغير البيئة PORT، أو 3100 */
const argPort = (() => {
  const i = process.argv.indexOf('--port');
  return i > -1 ? Number(process.argv[i + 1]) : null;
})();
const PORT = argPort || Number(process.env.PORT) || 3100;

/* ===== إعدادات الألعاب ===== */
const GAMES = {
  madaqesh: { min: 2, max: 8, title: 'مداقش' },
  baloot:   { min: 4, max: 4, title: 'بلوت' },
  sevens:   { min: 4, max: 4, title: 'سبعة الديمن' },
  hand:     { min: 4, max: 4, title: 'الهاند' },
};
/* صفحة اللعب الأونلاين لكل لعبة (اللي لها محرك جاهز) */
const GAME_FILE = {
  madaqesh: 'madaqesh_online.html',
  baloot: 'baloot_online.html',
  sevens: 'sevens_online.html',
  hand: 'hand_online.html',
};

const ENGINES = {
  madaqesh: MadaqeshGame,
  baloot: BalootGame,
  sevens: SevensGame,
  hand: HandGame,
};
const BOT_NAMES = ['أبو سعود','أبو فهد','أبو نايف','أبو خالد','أبو سلطان','أبو مشعل','أبو بدر','أبو طلال'];
const GRACE_MS = 60 * 1000;      /* مهلة الرجوع بعد الانقطاع */
const MAX_ROOMS = 500;
const MAX_MSG = 8 * 1024;        /* أقصى حجم رسالة */

/* ===== حالة السيرفر ===== */
const rooms = new Map();         /* code -> room */

function makeCode() {
  let code;
  do { code = String(1000 + crypto.randomInt(9000)); } while (rooms.has(code));
  return code;
}
function makeSession() { return crypto.randomBytes(12).toString('hex'); }

function emptyRoom(game) {
  const g = GAMES[game];
  return {
    code: makeCode(),
    game,
    state: 'lobby',              /* lobby | playing */
    hostSeat: 0,
    players: new Array(g.max).fill(null),
    createdAt: Date.now(),
  };
}

function usedBotNames(room) {
  return new Set(room.players.filter(p => p && p.isBot).map(p => p.name));
}
function addBot(room) {
  const seat = room.players.findIndex(p => p === null);
  if (seat === -1) return null;
  const used = usedBotNames(room);
  const name = BOT_NAMES.find(n => !used.has(n)) || ('بوت ' + (seat + 1));
  const bot = { seat, name, isBot: true, session: null, ws: null, connected: true, ready: true };
  room.players[seat] = bot;
  return bot;
}

function roomState(room) {
  return {
    t: 'room',
    code: room.code,
    game: room.game,
    gameTitle: GAMES[room.game].title,
    state: room.state,
    hostSeat: room.hostSeat,
    min: GAMES[room.game].min,
    max: GAMES[room.game].max,
    players: room.players.map(p => p && {
      seat: p.seat, name: p.name, isBot: p.isBot,
      connected: p.connected, ready: p.ready,
    }),
  };
}
function broadcast(room) {
  const msg = JSON.stringify(roomState(room));
  for (const p of room.players)
    if (p && !p.isBot && p.ws && p.ws.readyState === 1) p.ws.send(msg);
}
function send(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}
function sendErr(ws, msg) { send(ws, { t: 'error', msg }); }

/* إخراج لاعب من غرفة نهائياً */
function removePlayer(room, seat) {
  const p = room.players[seat];
  if (!p) return;
  room.players[seat] = null;

  /* الغرفة فاضية من البشر؟ أغلقها وأوقف محركها */
  const humans = room.players.filter(x => x && !x.isBot);
  if (humans.length === 0) {
    if (room.engine) { room.engine.destroy(); room.engine = null; }
    rooms.delete(room.code);
    return;
  }

  /* نقل الهوست لأقرب بشري متصل */
  if (room.hostSeat === seat) {
    const next = humans.find(x => x.connected) || humans[0];
    room.hostSeat = next.seat;
  }
}

/* نهاية اللعبة — يرجع الغرفة للوبي */
function endGame(room) {
  if (room.engine) { room.engine.destroy(); room.engine = null; }
  room.state = 'lobby';
  for (const pl of room.players) if (pl) pl.ready = !!pl.isBot;
  broadcast(room);
}

/* جدولة حذف لاعب منقطع بعد المهلة */
function scheduleDrop(room, seat) {
  const p = room.players[seat];
  if (!p) return;
  p.dropTimer = setTimeout(() => {
    /* لو رجع قبل المهلة ما نسوي شي */
    if (p.connected) return;
    removePlayer(room, seat);
    if (rooms.has(room.code)) broadcast(room);
  }, GRACE_MS);
}

/* ===== معالجة الرسائل ===== */
function handleMessage(ws, data) {
  let m;
  try { m = JSON.parse(data); } catch { return; }
  if (!m || typeof m.t !== 'string') return;

  switch (m.t) {

    case 'create': {
      if (rooms.size >= MAX_ROOMS) return sendErr(ws, 'السيرفر ممتلئ حالياً، جرب بعد شوي');
      const game = GAMES[m.game] ? m.game : null;
      const name = cleanName(m.name);
      if (!game) return sendErr(ws, 'اللعبة غير معروفة');
      if (!name) return sendErr(ws, 'اكتب اسمك أول');

      const room = emptyRoom(game);
      const session = makeSession();
      room.players[0] = { seat: 0, name, isBot: false, session, ws, connected: true, ready: true };
      room.hostSeat = 0;
      rooms.set(room.code, room);
      ws._room = room.code; ws._seat = 0;
      send(ws, { t: 'created', code: room.code, session, seat: 0 });
      broadcast(room);
      break;
    }

    case 'join': {
      const room = rooms.get(String(m.code || ''));
      const name = cleanName(m.name);
      if (!room) return sendErr(ws, 'ما فيه غرفة بهذا الرقم');
      if (!name) return sendErr(ws, 'اكتب اسمك أول');
      if (room.state !== 'lobby') return sendErr(ws, 'اللعبة بدأت خلاص');
      const seat = room.players.findIndex(p => p === null);
      if (seat === -1) return sendErr(ws, 'الغرفة ممتلئة');

      const session = makeSession();
      room.players[seat] = { seat, name, isBot: false, session, ws, connected: true, ready: false };
      ws._room = room.code; ws._seat = seat;
      send(ws, { t: 'joined', code: room.code, session, seat });
      broadcast(room);
      break;
    }

    case 'resume': {
      const room = rooms.get(String(m.code || ''));
      if (!room) return sendErr(ws, 'الغرفة انتهت');
      const p = room.players.find(x => x && !x.isBot && x.session === m.session);
      if (!p) return sendErr(ws, 'انتهت جلستك، ادخل من جديد');
      clearTimeout(p.dropTimer);
      p.ws = ws; p.connected = true;
      ws._room = room.code; ws._seat = p.seat;
      send(ws, { t: 'joined', code: room.code, session: p.session, seat: p.seat });
      broadcast(room);
      /* لو رجع وهو نص لعبة — زامنه معها فوراً */
      if (room.engine) room.engine.resync(p.seat);
      break;
    }

    case 'ready': {
      const { room, p } = ctx(ws);
      if (!p || room.state !== 'lobby') return;
      p.ready = !!m.ready;
      broadcast(room);
      break;
    }

    case 'add_bot': {
      const { room, p } = ctx(ws);
      if (!p || !isHost(room, p) || room.state !== 'lobby') return;
      if (!addBot(room)) return sendErr(ws, 'ما فيه مقعد فاضي');
      broadcast(room);
      break;
    }

    case 'remove_bot': {
      const { room, p } = ctx(ws);
      if (!p || !isHost(room, p) || room.state !== 'lobby') return;
      const target = room.players[m.seat];
      if (target && target.isBot) { room.players[m.seat] = null; broadcast(room); }
      break;
    }

    case 'kick': {
      const { room, p } = ctx(ws);
      if (!p || !isHost(room, p) || room.state !== 'lobby') return;
      const target = room.players[m.seat];
      if (!target || target.seat === p.seat) return;
      if (!target.isBot && target.ws) {
        send(target.ws, { t: 'kicked' });
        target.ws._room = null; target.ws._seat = null;
      }
      clearTimeout(target.dropTimer);
      room.players[m.seat] = null;
      broadcast(room);
      break;
    }

    case 'start': {
      const { room, p } = ctx(ws);
      if (!p || !isHost(room, p) || room.state !== 'lobby') return;
      const g = GAMES[room.game];
      const count = room.players.filter(x => x).length;
      if (count < g.min) return sendErr(ws, 'تحتاجون ' + g.min + ' لاعبين على الأقل — أضف بوت أو استنى');
      const notReady = room.players.filter(x => x && !x.isBot && x.connected && !x.ready);
      if (notReady.length) return sendErr(ws, 'فيه لاعبين ما ضغطوا جاهز');
      room.state = 'playing';
      broadcast(room);
      const file = GAME_FILE[room.game] || null;
      for (const pl of room.players)
        if (pl && !pl.isBot && pl.ws) send(pl.ws, { t: 'started', file });
      /* أشغّل محرك اللعبة لو لها محرك جاهز */
      const Engine = ENGINES[room.game];
      if (Engine) {
        room.engine = new Engine(room, {
          toSeat: (seat, obj) => { const rp = room.players[seat]; if (rp && rp.ws && rp.ws.readyState === 1) send(rp.ws, obj); },
          broadcastAll: (obj) => { for (const pl of room.players) if (pl && !pl.isBot && pl.ws && pl.ws.readyState === 1) send(pl.ws, obj); },
          onGameOver: () => { if (rooms.has(room.code)) endGame(room); },
        });
        room.engine.start();
      }
      break;
    }

    case 'game': {
      const { room, p } = ctx(ws);
      if (!p || !room || !room.engine) return;
      room.engine.onAction(p.seat, m);
      break;
    }

    case 'leave': {
      const { room, p } = ctx(ws);
      if (!p) return;
      clearTimeout(p.dropTimer);
      removePlayer(room, p.seat);
      ws._room = null; ws._seat = null;
      if (rooms.has(room.code)) broadcast(room);
      break;
    }
  }
}

/* سياق الاتصال الحالي */
function ctx(ws) {
  const room = rooms.get(ws._room) || null;
  const p = room && ws._seat != null ? room.players[ws._seat] : null;
  return { room, p };
}
function isHost(room, p) { return room && p && room.hostSeat === p.seat; }
function cleanName(n) {
  if (typeof n !== 'string') return '';
  n = n.trim().replace(/\s+/g, ' ').slice(0, 16);
  return n;
}

/* ===== خادم الملفات الثابتة ===== */
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2',
};
const server = http.createServer((req, res) => {
  if (req.url === '/health') { res.writeHead(200); return res.end('ok'); }
  let urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
  if (urlPath === '/') urlPath = '/index.html';
  const file = path.normalize(path.join(ROOT, urlPath));
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end('ممنوع'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('غير موجود'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
    res.end(data);
  });
});

/* ===== WebSocket ===== */
const wss = new WebSocketServer({ server, maxPayload: MAX_MSG });
wss.on('connection', ws => {
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', data => {
    if (data.length > MAX_MSG) return;
    try { handleMessage(ws, data.toString()); } catch (e) { console.error('msg', e); }
  });
  ws.on('close', () => {
    const room = rooms.get(ws._room);
    if (!room) return;
    const p = room.players[ws._seat];
    if (!p || p.ws !== ws) return;
    p.connected = false; p.ws = null;
    broadcast(room);
    scheduleDrop(room, p.seat);
  });
});

/* نبض كل ٣٠ ثانية + تنظيف الغرف القديمة الفاضية */
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false; ws.ping();
  }
}, 30000);
setInterval(() => {
  const cutoff = Date.now() - 6 * 3600 * 1000;
  for (const [code, room] of rooms)
    if (room.createdAt < cutoff && room.players.every(p => !p || !p.connected)) {
      if (room.engine) room.engine.destroy();
      rooms.delete(code);
    }
}, 3600 * 1000);

server.listen(PORT, () => console.log('سيرفر باصرة شغال على المنفذ ' + PORT));
