/* ============================================================
   محرك بلوت — نسخة السيرفر (الحكم الوحيد على الأوراق)
   يستخدم المنطق الصافي من baloot_script.js (نفس قوانين الأوفلاين)
   مبسّط: لا دبل/قهوة (mult=1, closed=false دائماً)
   ============================================================ */
const crypto = require('crypto');
const B = require('../../baloot_script.js');

const TURN_MS = 20000;       /* مهلة المزايدة/اللعب */
const BOT_DELAY = 900;       /* تأخير لعب البوت */

function cryptoShuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

class BalootGame {
  constructor(room, api) {
    this.room = room;
    this.api = api;
    this.destroyed = false;
    this.timers = new Set();

    this.P = room.players.filter(p => p).map(p => ({
      seat: p.seat, name: p.name, isBot: p.isBot,
      hand: [],
    }));
    this.dealer = crypto.randomInt(4);
    this.score = [0, 0];
    this.gid = 0;
    this.phase = 'idle';
    this.awaiting = null;

    /* حالة الجولة */
    this.mode = null;      /* hokom | sun | ashkal */
    this.trump = null;
    this.buyer = -1;
    this.teamPts = [0, 0];
    this.tricks = [0, 0];
    this.trickNo = 0;
    this.plays = [];       /* [{p,card}] */
    this.playedIds = new Set();
    this.leader = 0;
    this.turn = 0;
    this.projByPlayer = [[], [], [], []];
    this.projWinTeam = -1;
    this.projRevealed = false;
    this.balootHolder = -1;
    this.balootPlayed = 0;
    this.balootAbnat = [0, 0];
    this.akehSuit = null;
  }

  later(fn, ms) { const t = setTimeout(() => { this.timers.delete(t); if (!this.destroyed) fn(); }, ms); this.timers.add(t); return t; }
  bySeat(seat) { return this.P.findIndex(p => p.seat === seat); }
  teamOf(p) { return p % 2; }
  destroy() { this.destroyed = true; for (const t of this.timers) clearTimeout(t); this.timers.clear(); }

  gstate() {
    return {
      t: 'gstate',
      game: 'baloot',
      phase: this.phase,
      score: this.score,
      turn: this.awaiting ? this.awaiting.idx : -1,
      mode: this.mode,
      trump: this.trump,
      buyer: this.buyer,
      teamPts: this.teamPts,
      tricks: this.tricks,
      trickNo: this.trickNo,
      plays: this.plays.map(pl => ({ p: pl.p, card: { s: pl.card.s, r: pl.card.r } })),
      players: this.P.map(p => ({ seat: p.seat, name: p.name, isBot: p.isBot, cards: p.hand.length })),
    };
  }
  pushState() { this.api.broadcastAll(this.gstate()); }
  pushEvent(ev) { ev.t = 'gevent'; this.api.broadcastAll(ev); }
  sendHand(idx) {
    const p = this.P[idx];
    if (p.isBot) return;
    this.api.toSeat(p.seat, { t: 'ghand', hand: p.hand });
  }
  bubble(idx, txt) { this.pushEvent({ k: 'bubble', idx, txt }); }
  toast(txt) { this.pushEvent({ k: 'toast', txt }); }

  start() { this.pushState(); this.startRound(); }

  startRound() {
    const gid = ++this.gid;
    this.phase = 'dealing';
    this.mode = null; this.trump = null; this.buyer = -1;
    this.teamPts = [0, 0]; this.tricks = [0, 0]; this.trickNo = 0;
    this.plays = []; this.playedIds = new Set(); this.leader = (this.dealer + 1) % 4; this.turn = this.leader;
    this.projByPlayer = [[], [], [], []]; this.projWinTeam = -1; this.projRevealed = false;
    this.balootHolder = -1; this.balootPlayed = 0; this.balootAbnat = [0, 0]; this.akehSuit = null;
    for (const p of this.P) p.hand = [];

    const deck = cryptoShuffle(B.mkDeck());
    const hands = [[], [], [], []];
    for (let k = 0; k < 5; k++) for (let p = 0; p < 4; p++) hands[(this.dealer + 1 + p) % 4].push(deck.pop());
    this.floor = deck.pop();
    for (let i = 0; i < 4; i++) this.P[i].hand = hands[i];

    this.pushState();
    for (let i = 0; i < 4; i++) this.sendHand(i);
    this.pushEvent({ k: 'deal', floor: this.floor });
    this.toast('الموزّع: ' + this.P[this.dealer].name);

    this.lap = 1; this.bidIdx = 0;
    this.order = [0, 1, 2, 3].map(i => (this.dealer + 1 + i) % 4);
    this.later(() => { this.phase = 'bidding'; this.pushState(); this.stepBid(gid); }, 1400);
  }

  /* ---------- المزايدة ---------- */
  stepBid(gid) {
    if (this.destroyed || gid !== this.gid) return;
    if (this.bidIdx >= 4) {
      if (this.lap === 1) { this.lap = 2; this.bidIdx = 0; this.toast('اللفة الثانية'); }
      else { this.toast('ما اشترى أحد — ورق!'); this.dealer = (this.dealer + 1) % 4; this.later(() => this.startRound(), 1200); return; }
    }
    const p = this.order[this.bidIdx];
    const me = this.P[p];

    if (me.isBot) {
      this.awaiting = { idx: p, kind: 'bid' };
      this.pushState();
      this.later(() => {
        if (this.gid !== gid) return;
        this.awaiting = null;
        const d = B.aiBid(me.hand, this.floor, this.lap, p, this.dealer);
        if (d.act === 'kasho') { this.toast(me.name + ' كشّى — توزيع جديد'); this.later(() => this.startRound(), 1400); return; }
        if (d.act === 'buy') { this.doBuy(p, d.mode, d.trump, gid); return; }
        this.bubble(p, this.lap === 1 ? 'بس' : (p === this.dealer ? 'ورق' : 'ولا'));
        this.bidIdx++;
        this.pushState();
        this.later(() => this.stepBid(gid), 600);
      }, BOT_DELAY + crypto.randomInt(400));
    } else {
      const connected = this.isConnected(me.seat);
      this.awaiting = { idx: p, kind: 'bid' };
      this.pushState();
      const ashkalOk = p === this.dealer || p === (this.dealer + 3) % 4;
      this.api.toSeat(me.seat, {
        t: 'gturn', kind: 'bid',
        lap: this.lap, floor: this.floor, ashkalOk,
        canKasho: B.kashoEligible(this.P[p].hand.slice(0, 5)),
        secs: connected ? TURN_MS / 1000 : 3,
      });
      const wait = connected ? TURN_MS : 3000;
      this.awaiting.timer = this.later(() => {
        if (this.gid !== gid || !this.awaiting || this.awaiting.idx !== p) return;
        this.awaiting = null;
        this.bubble(p, this.lap === 1 ? 'بس' : (p === this.dealer ? 'ورق' : 'ولا'));
        this.bidIdx++;
        this.pushState();
        this.later(() => this.stepBid(gid), 400);
      }, wait);
    }
  }

  doBuy(p, mode, trump, gid) {
    if (this.destroyed || gid !== this.gid) return;
    this.phase = 'buying';
    this.mode = mode; this.trump = mode === 'hokom' ? trump : null;
    this.buyer = p;
    const label = mode === 'hokom' ? ('حكم ' + B.SUIT_CH[trump]) : (mode === 'sun' ? 'صن' : 'أشكل');
    this.bubble(p, label + '!');
    this.pushEvent({ k: 'sound', name: 'buy' });
    this.pushState();

    /* توزيع السياق (مبسّط: لا دبل، لا صن-بعد-الحكم، لا قبلك) */
    this.later(() => this.distributeContext(gid), 900);
  }

  distributeContext(gid) {
    if (this.destroyed || gid !== this.gid) return;
    const recv = this.mode === 'ashkal' ? (this.buyer + 2) % 4 : this.buyer;
    this.P[recv].hand.push(this.floor);
    this.P[recv].hand.push(this.deck.pop(), this.deck.pop());
    for (let q = 0; q < 4; q++) {
      if (q === recv) continue;
      this.P[q].hand.push(this.deck.pop(), this.deck.pop(), this.deck.pop());
    }
    for (let i = 0; i < 4; i++) this.sendHand(i);
    this.pushEvent({ k: 'context' });

    /* بلوت */
    if (this.mode === 'hokom') {
      for (let q = 0; q < 4; q++) {
        const h = this.P[q].hand;
        if (h.some(c => c.s === this.trump && c.r === 'K') && h.some(c => c.s === this.trump && c.r === 'Q'))
          this.balootHolder = q;
      }
    }
    /* مشاريع */
    for (let q = 0; q < 4; q++) this.projByPlayer[q] = B.detectProjects(this.P[q].hand, this.mode);
    this.projWinTeam = B.resolveProjects(this.projByPlayer, this.teamOf.bind(this), this.order);

    this.later(() => this.beginPlay(gid), 800);
  }

  beginPlay(gid) {
    if (this.destroyed || gid !== this.gid) return;
    this.phase = 'playing';
    this.plays = []; this.turn = this.leader;
    this.pushState();
    this.stepPlay(gid);
  }

  /* ---------- اللعب ---------- */
  stepPlay(gid) {
    if (this.destroyed || gid !== this.gid) return;
    if (this.trickNo >= 8) return this.endRound(gid);

    const p = this.turn;
    const me = this.P[p];
    const legal = B.legalMoves(me.hand, this.plays, p, (p + 2) % 4, this.mode, this.trump, false);

    if (me.isBot) {
      this.awaiting = { idx: p, kind: 'play' };
      this.pushState();
      this.later(() => {
        if (this.gid !== gid) return;
        this.awaiting = null;
        const pick = B.aiPlay(me.hand, this.plays, this.mode, this.trump, false, this.playedIds, (p + 2) % 4, this.akehSuit);
        if (!pick) { this.turn = (this.turn + 1) % 4; this.pushState(); this.later(() => this.stepPlay(gid), 400); return; }
        this.playCard(p, pick, gid);
      }, BOT_DELAY + crypto.randomInt(400));
    } else {
      const connected = this.isConnected(me.seat);
      this.awaiting = { idx: p, kind: 'play' };
      this.pushState();
      this.api.toSeat(me.seat, {
        t: 'gturn', kind: 'play',
        legal: legal.map(c => c.id),
        secs: connected ? TURN_MS / 1000 : 3,
      });
      const wait = connected ? TURN_MS : 3000;
      this.awaiting.timer = this.later(() => {
        if (this.gid !== gid || !this.awaiting || this.awaiting.idx !== p) return;
        this.awaiting = null;
        if (!legal.length) { this.turn = (this.turn + 1) % 4; this.pushState(); this.later(() => this.stepPlay(gid), 400); return; }
        this.playCard(p, legal[0], gid);
      }, wait);
    }
  }

  playCard(p, c, gid) {
    if (this.destroyed || gid !== this.gid) return;
    const hand = this.P[p].hand;
    const i = hand.findIndex(h => h.id === c.id);
    if (i < 0) return;
    hand.splice(i, 1);
    const leading = this.plays.length === 0;
    this.plays.push({ p, card: c });
    this.playedIds.add(c.id);

    /* أكه */
    if (leading && this.mode === 'hokom') {
      const unseen = B.mkDeck().filter(x => !this.playedIds.has(x.id));
      if (B.isAkeh(c, unseen, this.mode, this.trump)) this.akehSuit = c.s;
      else this.akehSuit = null;
    } else if (leading) this.akehSuit = null;

    /* بلوت */
    if (this.mode === 'hokom' && p === this.balootHolder && c.s === this.trump && (c.r === 'K' || c.r === 'Q')) {
      this.balootPlayed++;
      if (this.balootPlayed === 2) { this.balootAbnat[this.teamOf(p)] = 2; this.bubble(p, 'بلوت'); }
    }
    /* مشاريع */
    if (this.trickNo === 0 && this.projByPlayer[p].length) {
      this.pushEvent({ k: 'proj', idx: p, projects: this.projByPlayer[p].map(pr => pr.name) });
    }

    this.pushEvent({ k: 'play', idx: p, card: c });
    this.pushState();

    if (this.plays.length === 4) {
      this.later(() => this.finishTrick(gid), 800);
    } else {
      this.turn = (this.turn + 1) % 4;
      this.later(() => this.stepPlay(gid), 350);
    }
  }

  finishTrick(gid) {
    if (this.destroyed || gid !== this.gid) return;
    const wi = B.trickWinner(this.plays, this.mode, this.trump);
    const winner = this.plays[wi].p;
    const wt = this.teamOf(winner);
    let pts = 0;
    for (const pl of this.plays) pts += B.cardPts(pl.card, this.mode, this.trump);
    this.trickNo++;
    if (this.trickNo === 8) pts += 10;
    this.teamPts[wt] += pts;
    this.tricks[wt]++;
    this.pushEvent({ k: 'trick', winner, pts, team: wt });
    this.pushState();

    /* كشف المشاريع بعد أول أكلة */
    if (this.trickNo === 1 && !this.projRevealed) {
      this.projRevealed = true;
      if (this.projWinTeam !== -1) {
        for (let p = 0; p < 4; p++) {
          if (this.teamOf(p) === this.projWinTeam && this.projByPlayer[p].length)
            this.pushEvent({ k: 'proj_reveal', idx: p, projects: this.projByPlayer[p] });
        }
      }
    }

    this.plays = [];
    if (this.trickNo >= 8) {
      this.phase = 'done';
      return this.later(() => this.endRound(gid), 700);
    }
    this.leader = winner; this.turn = winner;
    this.later(() => this.stepPlay(gid), 500);
  }

  /* ---------- النهاية ---------- */
  endRound(gid) {
    if (this.destroyed || gid !== this.gid) return;
    this.awaiting = null;
    const projAbnat = [0, 0];
    if (this.projWinTeam !== -1) {
      for (let p = 0; p < 4; p++) if (this.teamOf(p) === this.projWinTeam)
        for (const pr of this.projByPlayer[p]) projAbnat[this.projWinTeam] += pr.abnat;
    }
    const res = B.scoreRound({
      mode: this.mode, buyerTeam: this.teamOf(this.buyer),
      teamPts: this.teamPts, tricks: this.tricks,
      projAbnat, balootAbnat: this.balootAbnat,
      mult: 1, coffee: false,
    });
    this.score[0] += res.abnat[0];
    this.score[1] += res.abnat[1];

    const over = this.score[0] >= 152 || this.score[1] >= 152;
    this.pushEvent({
      k: 'round_end',
      result: res,
      score: this.score.slice(),
      note: over ? 'نهاية الصكة' : 'جولة انتهت',
    });
    this.pushState();

    if (over) {
      const max = Math.max(...this.score);
      const champs = [0, 1].filter(t => this.score[t] === max);
      this.pushEvent({ k: 'game_over', winners: champs, standings: [{ team: 0, score: this.score[0] }, { team: 1, score: this.score[1] }] });
      this.later(() => this.api.onGameOver(), 3000);
    } else {
      this.dealer = (this.dealer + 1) % 4;
      this.later(() => this.startRound(), 2500);
    }
  }

  isConnected(seat) {
    const rp = this.room.players[seat];
    return !!(rp && rp.connected);
  }

  onAction(seat, m) {
    if (this.destroyed) return;
    const idx = this.bySeat(seat);
    if (idx === -1) return;
    const aw = this.awaiting;
    if (!aw || aw.idx !== idx) return;
    if (this.P[idx].isBot) return;

    if (aw.kind === 'bid') {
      clearTimeout(aw.timer); this.timers.delete(aw.timer);
      this.awaiting = null;
      const gid = this.gid;
      if (m.a === 'kasho') { this.toast(this.P[idx].name + ' كشّى'); this.later(() => this.startRound(), 1200); return; }
      if (m.a === 'buy') { this.doBuy(idx, m.mode, m.trump, gid); return; }
      /* pass */
      this.bubble(idx, this.lap === 1 ? 'بس' : (idx === this.dealer ? 'ورق' : 'ولا'));
      this.bidIdx++;
      this.pushState();
      this.later(() => this.stepBid(gid), 400);
      return;
    }

    if (aw.kind === 'play' && m.a === 'play' && m.card) {
      const legal = B.legalMoves(this.P[idx].hand, this.plays, idx, (idx + 2) % 4, this.mode, this.trump, false);
      const card = legal.find(c => c.id === m.card);
      if (!card) return;
      clearTimeout(aw.timer); this.timers.delete(aw.timer);
      this.awaiting = null;
      this.playCard(idx, card, this.gid);
      return;
    }
  }

  resync(seat) {
    const idx = this.bySeat(seat);
    if (idx === -1) return;
    this.api.toSeat(seat, this.gstate());
    this.sendHand(idx);
    const aw = this.awaiting;
    if (aw && aw.idx === idx && !this.P[idx].isBot) {
      if (aw.kind === 'bid') {
        this.api.toSeat(seat, {
          t: 'gturn', kind: 'bid',
          lap: this.lap, floor: this.floor,
          ashkalOk: idx === this.dealer || idx === (this.dealer + 3) % 4,
          canKasho: B.kashoEligible(this.P[idx].hand.slice(0, 5)),
          secs: TURN_MS / 1000,
        });
      } else if (aw.kind === 'play') {
        const legal = B.legalMoves(this.P[idx].hand, this.plays, idx, (idx + 2) % 4, this.mode, this.trump, false);
        this.api.toSeat(seat, { t: 'gturn', kind: 'play', legal: legal.map(c => c.id), secs: TURN_MS / 1000 });
      }
    }
  }
}

module.exports = { BalootGame };
