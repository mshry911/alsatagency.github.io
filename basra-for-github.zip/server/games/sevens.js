/* ============================================================
   محرك سبعة الديمن — نسخة السيرفر (الحكم الوحيد على الأوراق)
   يستخدم المنطق الصافي من sevens_script.js (نفس قوانين الأوفلاين)
   ============================================================ */
const crypto = require('crypto');
const L = require('../../sevens_script.js');

const TURN_MS = 20000;       /* مهلة اللعب */
const BOT_DELAY = 900;       /* تأخير لعب البوت */
const TOTAL_ROUNDS = 6;

function cryptoShuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

class SevensGame {
  constructor(room, api) {
    this.room = room;
    this.api = api;
    this.destroyed = false;
    this.timers = new Set();

    this.P = room.players.filter(p => p).map(p => ({
      seat: p.seat, name: p.name, isBot: p.isBot,
      hand: [], score: 0, finished: false,
    }));
    this.roundNo = 1;
    this.board = L.newBoard();
    this.turn = 0;
    this.phase = 'idle';
    this.awaiting = null;
    this.gid = 0;
    this.finishedOrder = [];   /* من خلّص أولاً */
  }

  later(fn, ms) { const t = setTimeout(() => { this.timers.delete(t); if (!this.destroyed) fn(); }, ms); this.timers.add(t); return t; }
  bySeat(seat) { return this.P.findIndex(p => p.seat === seat); }

  destroy() { this.destroyed = true; for (const t of this.timers) clearTimeout(t); this.timers.clear(); }

  gstate() {
    return {
      t: 'gstate',
      game: 'sevens',
      phase: this.phase, roundNo: this.roundNo,
      board: this.board,
      turn: this.awaiting ? this.awaiting.idx : -1,
      finished: this.finishedOrder,
      players: this.P.map(p => ({
        seat: p.seat, name: p.name, isBot: p.isBot,
        score: p.score, cards: p.hand.length, finished: p.finished,
      })),
    };
  }
  pushState() { this.api.broadcastAll(this.gstate()); }
  pushEvent(ev) { ev.t = 'gevent'; this.api.broadcastAll(ev); }
  sendHand(idx) {
    const p = this.P[idx];
    if (p.isBot || p.finished) return;
    this.api.toSeat(p.seat, { t: 'ghand', hand: p.hand });
  }
  bubble(idx, txt) { this.pushEvent({ k: 'bubble', idx, txt }); }
  toast(txt) { this.pushEvent({ k: 'toast', txt }); }

  start() { this.pushState(); this.startRound(); }

  startRound() {
    const gid = ++this.gid;
    this.phase = 'dealing';
    this.finishedOrder = [];
    this.board = L.newBoard();
    for (const p of this.P) { p.hand = []; p.finished = false; }

    const deck = cryptoShuffle(L.mkDeck());
    const hands = [[], [], [], []];
    deck.forEach((c, i) => hands[i % 4].push(c));
    for (let i = 0; i < 4; i++) this.P[i].hand = hands[i];

    this.turn = L.starterOf(hands);
    this.pushState();
    for (let i = 0; i < 4; i++) this.sendHand(i);
    this.pushEvent({ k: 'deal' });
    this.toast(this.P[this.turn].name + ' معه ٧ الديمن — يبدأ');

    this.later(() => { this.phase = 'playing'; this.pushState(); this.step(gid); }, 1400);
  }

  step(gid) {
    if (this.destroyed || gid !== this.gid) return;
    if (this.finishedOrder.length >= 3) return this.endRound(gid);

    /* تخطَّ من خلّص */
    let guard = 0;
    while (this.P[this.turn].finished && guard++ < 4) this.turn = (this.turn + 1) % 4;

    const p = this.P[this.turn];
    const legal = L.legalMoves(p.hand, this.board);

    if (p.isBot) {
      this.awaiting = { idx: this.turn, kind: 'play' };
      this.pushState();
      this.later(() => {
        if (this.gid !== gid) return;
        this.awaiting = null;
        if (!legal.length) { this.doPass(this.turn, gid); return; }
        const pick = L.aiChoose(p.hand, this.board, () => crypto.randomInt(1 << 30) / (1 << 30));
        this.playCard(this.turn, pick, gid);
      }, BOT_DELAY + crypto.randomInt(500));
    } else {
      const connected = this.isConnected(p.seat);
      this.awaiting = { idx: this.turn, kind: 'play' };
      this.pushState();
      this.api.toSeat(p.seat, {
        t: 'gturn', kind: 'play',
        legal: legal.map(c => c.id),
        canPass: !legal.length,
        secs: connected ? TURN_MS / 1000 : 3,
      });
      const wait = connected ? TURN_MS : 3000;
      this.awaiting.timer = this.later(() => {
        if (this.gid !== gid || !this.awaiting || this.awaiting.idx !== this.turn) return;
        this.awaiting = null;
        if (!legal.length) { this.doPass(this.turn, gid); return; }
        this.playCard(this.turn, legal[0], gid);
      }, wait);
    }
  }

  isConnected(seat) {
    const rp = this.room.players[seat];
    return !!(rp && rp.connected);
  }

  doPass(idx, gid) {
    if (this.destroyed || gid !== this.gid) return;
    this.bubble(idx, 'جلا');
    this.pushEvent({ k: 'sound', name: 'pass' });
    this.turn = (this.turn + 1) % 4;
    this.pushState();
    this.later(() => this.step(gid), 400);
  }

  playCard(idx, card, gid) {
    if (this.destroyed || gid !== this.gid) return;
    const p = this.P[idx];
    const i = p.hand.findIndex(c => c.id === card.id);
    if (i < 0) return;
    p.hand.splice(i, 1);
    this.board = L.place(card, this.board);
    this.pushEvent({ k: 'play', idx, card });
    this.pushEvent({ k: 'sound', name: 'play' });
    this.pushState();

    if (!p.hand.length) {
      p.finished = true;
      this.finishedOrder.push(idx);
      const place = this.finishedOrder.length;
      const PL = ['الأول', 'الثاني', 'الثالث'];
      this.bubble(idx, 'خلّص ' + PL[place - 1] + '! ' + (place === 1 ? '🏆' : '🎉'));
      if (place >= 3) {
        this.turn = (this.turn + 1) % 4;
        return this.later(() => this.endRound(gid), 1100);
      }
      this.turn = (this.turn + 1) % 4;
      return this.later(() => this.step(gid), 900);
    }

    this.turn = (this.turn + 1) % 4;
    this.later(() => this.step(gid), 350);
  }

  endRound(gid) {
    if (this.destroyed || gid !== this.gid) return;
    this.phase = 'done';
    this.awaiting = null;

    /* ترتيب النهاية */
    const order = this.finishedOrder.slice();
    for (let p = 0; p < 4; p++) if (order.indexOf(p) < 0) order.push(p);
    const AWARD = [4, 3, 1, 0];
    for (let i = 0; i < 4; i++) this.P[order[i]].score += AWARD[i];

    const last = this.roundNo >= TOTAL_ROUNDS;
    const winner = order[0];
    this.pushEvent({
      k: 'round_end',
      order, award: AWARD,
      scores: this.P.map(p => p.score),
      note: last ? 'نهاية الصكة' : 'جولة ' + this.roundNo + ' انتهت',
    });
    this.pushState();

    if (last) {
      const max = Math.max(...this.P.map(p => p.score));
      const champs = this.P.map((p, i) => i).filter(i => this.P[i].score === max);
      this.pushEvent({ k: 'game_over', winners: champs, standings: this.P.map((p, i) => ({ idx: i, name: p.name, score: p.score })) });
      this.later(() => this.api.onGameOver(), 3000);
    } else {
      this.later(() => { this.roundNo++; this.startRound(); }, 2500);
    }
  }

  onAction(seat, m) {
    if (this.destroyed) return;
    const idx = this.bySeat(seat);
    if (idx === -1) return;
    const aw = this.awaiting;
    if (!aw || aw.idx !== idx) return;
    if (this.P[idx].isBot) return;

    if (aw.kind === 'play') {
      const p = this.P[idx];
      const legal = L.legalMoves(p.hand, this.board);
      if (m.a === 'pass') {
        if (legal.length) return; /* ما يصير يمر لو عنده حركات */
        clearTimeout(aw.timer); this.timers.delete(aw.timer);
        this.awaiting = null;
        this.doPass(idx, this.gid);
        return;
      }
      if (m.a === 'play' && m.card) {
        const card = legal.find(c => c.id === m.card);
        if (!card) return;
        clearTimeout(aw.timer); this.timers.delete(aw.timer);
        this.awaiting = null;
        this.playCard(idx, card, this.gid);
        return;
      }
    }
  }

  resync(seat) {
    const idx = this.bySeat(seat);
    if (idx === -1) return;
    this.api.toSeat(seat, this.gstate());
    this.sendHand(idx);
    const aw = this.awaiting;
    if (aw && aw.idx === idx && !this.P[idx].isBot) {
      const p = this.P[idx];
      const legal = L.legalMoves(p.hand, this.board);
      this.api.toSeat(seat, {
        t: 'gturn', kind: 'play',
        legal: legal.map(c => c.id),
        canPass: !legal.length,
        secs: TURN_MS / 1000,
      });
    }
  }
}

module.exports = { SevensGame };
