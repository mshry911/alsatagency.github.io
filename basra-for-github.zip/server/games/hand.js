/* ============================================================
   محرك الهاند السعودي — نسخة السيرفر (الحكم الوحيد على الأوراق)
   يستخدم المنطق الصافي من hand_script.js (نفس قوانين الأوفلاين)
   مبسّط: التسقيط على مجموعات الآخرين غير مفعّل في هذه النسخة
   ============================================================ */
const crypto = require('crypto');
const L = require('../../hand_script.js');

const TURN_MS = 25000;       /* مهلة السحب/اللعب */
const BOT_DELAY = 900;       /* تأخير لعب البوت */
const RAISE_START = 51;      /* نصاب النزول الأول */

function cryptoShuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

class HandGame {
  constructor(room, api) {
    this.room = room;
    this.api = api;
    this.destroyed = false;
    this.timers = new Set();

    this.P = room.players.filter(p => p).map(p => ({
      seat: p.seat, name: p.name, isBot: p.isBot,
      hand: [], melded: false, melds: [],
    }));
    this.dealer = crypto.randomInt(4);
    this.scores = [0, 0, 0, 0];
    this.gid = 0;
    this.phase = 'idle';
    this.awaiting = null;
  }

  later(fn, ms) { const t = setTimeout(() => { this.timers.delete(t); if (!this.destroyed) fn(); }, ms); this.timers.add(t); return t; }
  bySeat(seat) { return this.P.findIndex(p => p.seat === seat); }
  destroy() { this.destroyed = true; for (const t of this.timers) clearTimeout(t); this.timers.clear(); }

  gstate() {
    return {
      t: 'gstate',
      game: 'hand',
      phase: this.phase,
      turn: this.awaiting ? this.awaiting.idx : -1,
      step: this.step_,
      fire: this.fire.length ? { s: this.fire[this.fire.length - 1].s, r: this.fire[this.fire.length - 1].r, id: this.fire[this.fire.length - 1].id } : null,
      deck: this.deck ? this.deck.length : 0,
      lastMeldPts: this.lastMeldPts,
      players: this.P.map(p => ({
        seat: p.seat, name: p.name, isBot: p.isBot,
        cards: p.hand.length, melded: p.melded, melds: p.melds.length,
      })),
    };
  }
  pushState() { this.api.broadcastAll(this.gstate()); }
  pushEvent(ev) { ev.t = 'gevent'; this.api.broadcastAll(ev); }
  sendHand(idx) {
    const p = this.P[idx];
    if (p.isBot) return;
    this.api.toSeat(p.seat, { t: 'ghand', hand: p.hand });
  }
  bubble(idx, txt) { this.pushEvent({ k: 'bubble', idx, txt }); }
  toast(txt) { this.pushEvent({ k: 'toast', txt }); }

  start() { this.pushState(); this.startRound(); }

  startRound() {
    const gid = ++this.gid;
    this.phase = 'dealing';
    this.step_ = 'draw';
    this.lastMeldPts = 0;
    for (const p of this.P) { p.hand = []; p.melded = false; p.melds = []; }

    const deck = cryptoShuffle(L.mkDeck());
    const hands = [[], [], [], []];
    for (let i = 0; i < 14; i++) for (let p = 0; p < 4; p++) hands[p].push(deck.pop());
    const starter = (this.dealer + 1) % 4;
    hands[starter].push(deck.pop());
    for (let i = 0; i < 4; i++) this.P[i].hand = hands[i];
    this.deck = deck;
    this.fire = [];
    this.turn = starter;

    this.pushState();
    for (let i = 0; i < 4; i++) this.sendHand(i);
    this.pushEvent({ k: 'deal' });
    this.toast(this.P[starter].name + ' يبدأ — عنده ١٥ ورقة');

    this.later(() => { this.phase = 'playing'; this.pushState(); this.step(gid); }, 1400);
  }

  step(gid) {
    if (this.destroyed || gid !== this.gid) return;
    if (!this.deck.length && this.step_ === 'draw') {
      this.toast('خلصت كومة السحب — الجولة لاغية');
      return this.later(() => this.roundVoid(gid), 1200);
    }
    const p = this.P[this.turn];
    if (p.isBot) {
      this.awaiting = { idx: this.turn, kind: 'bot' };
      this.pushState();
      this.later(() => {
        if (this.gid !== gid) return;
        this.awaiting = null;
        this.aiTurn(this.turn, gid);
      }, BOT_DELAY + crypto.randomInt(400));
    } else {
      const connected = this.isConnected(p.seat);
      this.awaiting = { idx: this.turn, kind: this.step_ };
      this.pushState();
      if (this.step_ === 'draw') {
        this.api.toSeat(p.seat, {
          t: 'gturn', kind: 'draw',
          canDeck: !!this.deck.length,
          canFire: this.fire.length > 0,
          secs: connected ? TURN_MS / 1000 : 3,
        });
      } else {
        const need = this.needPts();
        this.api.toSeat(p.seat, {
          t: 'gturn', kind: 'play',
          need, melded: p.melded,
          secs: connected ? TURN_MS / 1000 : 3,
        });
      }
      const wait = connected ? TURN_MS : 3000;
      this.awaiting.timer = this.later(() => {
        if (this.gid !== gid || !this.awaiting || this.awaiting.idx !== this.turn) return;
        this.awaiting = null;
        if (this.step_ === 'draw') { this.doDraw(this.turn, 'deck', gid); return; }
        /* play timeout: auto-discard lowest value */
        const c = L.aiPickDiscard(p.hand, p.melds);
        this.doDiscard(this.turn, c, gid);
      }, wait);
    }
  }

  isConnected(seat) {
    const rp = this.room.players[seat];
    return !!(rp && rp.connected);
  }

  needPts() {
    return this.lastMeldPts ? this.lastMeldPts + 1 : RAISE_START;
  }

  /* ---------- سحب ---------- */
  doDraw(idx, from, gid) {
    if (this.destroyed || gid !== this.gid) return;
    const p = this.P[idx];
    if (from === 'fire' && this.fire.length) {
      const c = this.fire.pop();
      p.hand.push(c);
      this.pushEvent({ k: 'draw', idx, from: 'fire', card: c });
    } else {
      if (!this.deck.length) { this.toast('خلصت الكومة'); this.later(() => this.roundVoid(gid), 1000); return; }
      const c = this.deck.pop();
      p.hand.push(c);
      this.pushEvent({ k: 'draw', idx, from: 'deck', card: c });
    }
    this.step_ = 'play';
    this.sendHand(idx);
    this.pushState();
    this.later(() => this.step(gid), 350);
  }

  /* ---------- نزول ---------- */
  doMeld(idx, melds, gid) {
    if (this.destroyed || gid !== this.gid) return;
    const p = this.P[idx];
    const pts = L.meldsValue(melds);
    if (!p.melded) {
      const need = this.needPts();
      if (pts < need) { this.toast('نزولك ' + pts + ' — تحتاج ' + need); return false; }
      p.melded = true;
      this.lastMeldPts = pts;
      this.bubble(idx, 'نزلت! ' + pts);
    } else {
      this.bubble(idx, 'مجموعة جديدة');
    }
    for (const m of melds) p.melds.push(m);
    const used = new Set(); melds.forEach(m => m.forEach(c => used.add(c.id)));
    p.hand = p.hand.filter(c => !used.has(c.id));
    this.pushEvent({ k: 'meld', idx, melds, pts });
    this.sendHand(idx);
    this.pushState();
    return true;
  }

  /* ---------- رمي ---------- */
  doDiscard(idx, c, gid) {
    if (this.destroyed || gid !== this.gid) return;
    const p = this.P[idx];
    const i = p.hand.findIndex(x => x.id === c.id);
    if (i < 0) return;
    p.hand.splice(i, 1);
    this.fire.push(c);
    this.pushEvent({ k: 'discard', idx, card: c });
    this.pushState();
    if (!p.hand.length) { this.finishRound(idx, gid); return; }
    this.turn = (this.turn + 1) % 4;
    this.step_ = 'draw';
    this.later(() => this.step(gid), 500);
  }

  /* ---------- ذكاء البوت ---------- */
  aiTurn(idx, gid) {
    if (this.destroyed || gid !== this.gid) return;
    const p = this.P[idx];
    if (this.step_ === 'draw') {
      /* AI: يسحب من النار إذا مفيدة، وإلا من الكومة */
      let took = false;
      const top = this.fire[this.fire.length - 1];
      if (top && p.melded) {
        /* لا تسقيط في هذه النسخة — نسحب من الكومة دائماً */
      }
      if (!took) {
        if (!this.deck.length) { this.toast('خلصت الكومة'); this.later(() => this.roundVoid(gid), 1000); return; }
        p.hand.push(this.deck.pop());
        this.pushEvent({ k: 'draw', idx, from: 'deck' });
      }
      this.step_ = 'play';
      this.sendHand(idx);
      this.pushState();
      this.later(() => this.aiPlay(idx, gid), 500);
    } else {
      this.aiPlay(idx, gid);
    }
  }

  aiPlay(idx, gid) {
    if (this.destroyed || gid !== this.gid) return;
    const p = this.P[idx];
    /* هاند؟ */
    if (!p.melded) {
      const hc = L.canMakeHand(p.hand);
      if (hc) {
        p.melded = true;
        hc.melds.forEach(m => p.melds.push(m));
        p.hand = [hc.discard];
        this.bubble(idx, 'هاند! 🔥');
        this.pushEvent({ k: 'meld', idx, melds: hc.melds, hand: true });
        this.sendHand(idx);
        this.pushState();
        this.later(() => this.doDiscard(idx, hc.discard, gid), 900);
        return;
      }
    }
    /* نزول */
    if (!p.melded) {
      const need = this.needPts();
      const best = L.bestMeldSet(p.hand, need);
      if (best) {
        best.melds.forEach(m => p.melds.push(m));
        const used = new Set(); best.melds.forEach(m => m.forEach(c => used.add(c.id)));
        p.hand = p.hand.filter(c => !used.has(c.id));
        p.melded = true;
        this.lastMeldPts = best.pts;
        this.bubble(idx, 'نزلت! ' + best.pts);
        this.pushEvent({ k: 'meld', idx, melds: best.melds, pts: best.pts });
        this.sendHand(idx);
        this.pushState();
      }
    }
    /* رمي */
    if (!p.hand.length) { this.finishRound(idx, gid); return; }
    const c = L.aiPickDiscard(p.hand, p.melds);
    this.doDiscard(idx, c, gid);
  }

  /* ---------- نهاية الجولة ---------- */
  finishRound(winner, gid) {
    if (this.destroyed || gid !== this.gid) return;
    this.phase = 'done';
    this.awaiting = null;
    const isHand = this.P[winner].melds.length >= 1 && this.P[winner].hand.length === 0;
    const sc = L.scoreRound(this.P, winner, isHand);
    for (let i = 0; i < 4; i++) this.scores[i] += sc[i];
    this.pushEvent({ k: 'round_end', winner, scores: this.scores.slice(), roundScores: sc });
    this.pushState();
    this.dealer = (this.dealer + 1) % 4;
    this.later(() => this.startRound(), 2500);
  }

  roundVoid(gid) {
    if (this.destroyed || gid !== this.gid) return;
    this.phase = 'done';
    this.awaiting = null;
    this.pushEvent({ k: 'round_void' });
    this.pushState();
    this.later(() => this.startRound(), 2000);
  }

  onAction(seat, m) {
    if (this.destroyed) return;
    const idx = this.bySeat(seat);
    if (idx === -1) return;
    const aw = this.awaiting;
    if (!aw || aw.idx !== idx) return;
    if (this.P[idx].isBot) return;

    if (aw.kind === 'draw' && m.a === 'draw') {
      clearTimeout(aw.timer); this.timers.delete(aw.timer);
      this.awaiting = null;
      this.doDraw(idx, m.from || 'deck', this.gid);
      return;
    }

    if (aw.kind === 'play') {
      if (m.a === 'meld' && m.melds) {
        clearTimeout(aw.timer); this.timers.delete(aw.timer);
        this.awaiting = null;
        if (this.doMeld(idx, m.melds, this.gid)) {
          /* بعد النزول ينتظر الرمي */
          this.awaiting = { idx, kind: 'discard' };
          this.pushState();
          this.api.toSeat(seat, { t: 'gturn', kind: 'discard', secs: TURN_MS / 1000 });
          const wait = this.isConnected(seat) ? TURN_MS : 3000;
          this.awaiting.timer = this.later(() => {
            if (!this.awaiting || this.awaiting.idx !== idx) return;
            this.awaiting = null;
            const c = L.aiPickDiscard(this.P[idx].hand, this.P[idx].melds);
            this.doDiscard(idx, c, this.gid);
          }, wait);
        }
        return;
      }
      if (m.a === 'discard' && m.card) {
        clearTimeout(aw.timer); this.timers.delete(aw.timer);
        this.awaiting = null;
        this.doDiscard(idx, { id: m.card }, this.gid);
        return;
      }
    }

    if (aw.kind === 'discard' && m.a === 'discard' && m.card) {
      clearTimeout(aw.timer); this.timers.delete(aw.timer);
      this.awaiting = null;
      this.doDiscard(idx, { id: m.card }, this.gid);
      return;
    }
  }

  resync(seat) {
    const idx = this.bySeat(seat);
    if (idx === -1) return;
    this.api.toSeat(seat, this.gstate());
    this.sendHand(idx);
    const aw = this.awaiting;
    if (aw && aw.idx === idx && !this.P[idx].isBot) {
      const connected = this.isConnected(seat);
      if (this.step_ === 'draw') {
        this.api.toSeat(seat, { t: 'gturn', kind: 'draw', canDeck: !!this.deck.length, canFire: this.fire.length > 0, secs: TURN_MS / 1000 });
      } else {
        const need = this.needPts();
        this.api.toSeat(seat, { t: 'gturn', kind: 'play', need, melded: this.P[idx].melded, secs: TURN_MS / 1000 });
      }
    }
  }
}

module.exports = { HandGame };
