/* ================== الهاند أونلاين — عميل اللعب ================== */
const el=id=>document.getElementById(id);
const SUIT_CH={S:'♠',H:'♥',C:'♣',D:'♦'};
const RANK_AR={'A':'A','2':'2','3':'3','4':'4','5':'5','6':'6','7':'7','8':'8','9':'9','10':'10','J':'J','Q':'Q','K':'K'};
const AR_D=['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
const arNum=n=>String(n).split('').map(ch=>/\d/.test(ch)?AR_D[+ch]:ch).join('');
let muted=true;

function cardEl(c){
  const d=document.createElement('div');
  const red=c.s==='H'||c.s==='D';
  d.className='card '+(red?'red':'blk');
  const img=(typeof CARD_IMG!=='undefined')?CARD_IMG[c.s+c.r]:null;
  if(img){d.classList.add('court'); d.style.backgroundImage='url('+img+')';}
  else d.innerHTML='<div class="tl">'+RANK_AR[c.r]+'<br>'+SUIT_CH[c.s]+'</div><div class="mid">'+SUIT_CH[c.s]+'</div>';
  return d;
}
function bubble(idx,txt,ms){
  const b=el('bub'+idx); if(!b)return;
  b.textContent=txt; b.classList.add('show');
  setTimeout(()=>b.classList.remove('show'),ms||1500);
}
function toast(txt,ms){
  const t=el('toast'); t.textContent=txt; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),ms||2600);
}
function actions(html){el('actions').innerHTML=html||'';}

let G=null, myHand=[], myIdx=-1, P=[], myMelds=[], fire=null, step_='draw';
const NAMES=['أنت','حمد','مشاري','سعيد'];

function renderDeck(deckCount){
  const dp=el('deckPile'); if(!dp)return;
  dp.innerHTML='';
  const n=Math.min(deckCount,5);
  for(let i=0;i<n;i++){
    const c=document.createElement('div');
    c.className='card back pilec';
    c.style.transform='translate('+(i*2)+'px,'+(-i*2)+'px)';
    dp.appendChild(c);
  }
}
function renderFire(){
  const fp=el('firePile'); if(!fp)return;
  fp.innerHTML='';
  if(fire)fp.appendChild(cardEl(fire));
}
function renderMelds(){
  for(let i=0;i<4;i++){
    const box=el('melds'+i); if(!box)continue;
    box.innerHTML='';
    for(const m of (P[i]?P[i].melds:[])){
      const row=document.createElement('div'); row.className='meld-row';
      for(const c of m)row.appendChild(cardEl(c));
      box.appendChild(row);
    }
  }
}
function renderHand(){
  const h=el('hand'); h.innerHTML='';
  myHand.forEach((c,i)=>{
    const w=document.createElement('div'); w.className='fw';
    const d=cardEl(c); w.appendChild(d); h.appendChild(w);
  });
}
function markTurn(p){
  for(let i=0;i<4;i++){const n=el('name'+i); if(n)n.classList.toggle('turn',i===p);}
}

/* ========== ربط السيرفر ========== */
const net=new BasraNet();
if(!net.restoreSession()){location.replace('lobby.html');}
else{
net.on('open',()=>toast('متصل ✓',1200));
net.on('kicked',()=>{net.clearSession(); location.href='lobby.html';});
net.on('error',m=>toast(m.msg||'خطأ'));

net.on('gstate',s=>{
  if(s.game&&s.game!=='hand')return;
  P=s.players||[];
  myIdx=P.findIndex(p=>p.seat===net.seat);
  G=s;
  fire=s.fire||null;
  step_=s.step||'draw';
  markTurn(s.turn);
  renderDeck(s.deck||0);
  renderFire();
  renderMelds();
  for(let i=0;i<4;i++){const n=el('name'+i); if(n&&P[i]){n.textContent=P[i].name; n.classList.toggle('melded',P[i].melded);}}
});

net.on('ghand',m=>{myHand=m.hand||[]; renderHand();});

net.on('gturn',m=>{
  if(m.kind==='draw'){
    let html='<div class="hint">اسحب ورقة</div>';
    if(m.canDeck)html+='<button class="gold" id="bDeck">كومة</button>';
    if(m.canFire)html+='<button id="bFire">نار ('+SUIT_CH[fire.s]+RANK_AR[fire.r]+')</button>';
    actions(html);
    if(el('bDeck'))el('bDeck').onclick=()=>{actions(''); net.send({t:'game',a:'draw',from:'deck'});};
    if(el('bFire'))el('bFire').onclick=()=>{actions(''); net.send({t:'game',a:'draw',from:'fire'});};
  }
  if(m.kind==='play'){
    let html='<div class="hint">تحتاج '+m.need+' نقطة للنزول</div>';
    if(!m.melded)html+='<button class="gold" id="bMeld">نزّل</button>';
    html+='<button class="danger" id="bDiscard">ارمِ</button>';
    actions(html);
    if(el('bMeld'))el('bMeld').onclick=()=>{
      /* نزول: يرسل المجموعات المحددة — مبسّط: يرسل طلب للسيرفر */
      actions(''); net.send({t:'game',a:'meld',melds:[]});
    };
    if(el('bDiscard'))el('bDiscard').onclick=()=>{
      /* رمي: يرسل أول ورقة */
      if(myHand.length){actions(''); net.send({t:'game',a:'discard',card:myHand[0].id});}
    };
  }
});

net.on('gevent',e=>{
  if(e.k==='draw'){renderDeck(G.deck||0); renderFire();}
  if(e.k==='meld'){renderMelds();}
  if(e.k==='discard'){renderFire();}
  if(e.k==='round_end'){
    let html='<div class="resWin">الجولة انتهت</div>';
    html+='<table class="resTbl"><thead><tr><th>اللاعب</th><th>النقاط</th></tr></thead><tbody>';
    for(let i=0;i<4;i++)html+='<tr><td>'+NAMES[i]+'</td><td>'+arNum(G.scores?G.scores[i]:0)+'</td></tr>';
    html+='</tbody></table>';
    el('resBody').innerHTML=html;
    el('resultPanel').classList.add('show');
  }
  if(e.k==='round_void'){toast('الجولة لاغية');}
  if(e.k==='game_over'){toast('نهاية اللعبة!');}
  if(e.k==='bubble')bubble(e.idx,e.txt);
});

el('nextBtn').onclick=()=>{el('resultPanel').classList.remove('show');};
el('muteBtn').onclick=()=>{muted=!muted; el('muteBtn').textContent=muted?'🔇':'🔊';};
net.connect();
}
