/* ============================================================
   عميل باصرة أونلاين — اتصال WebSocket مع رجوع تلقائي
   الاستخدام:
     const net = new BasraNet();
     net.on('room', m => ...);
     net.connect();
     net.send({t:'create', game:'madaqesh', name:'فهد'});
   ============================================================ */
(function (global) {
  'use strict';

  function BasraNet() {
    this.ws = null;
    this.handlers = {};
    this.session = null;     /* جلسة الغرفة الحالية */
    this.roomCode = null;
    this.seat = null;
    this._retry = 0;
    this._closedByUser = false;
    this._queue = [];
  }

  /* تسجيل مستمع لنوع رسالة */
  BasraNet.prototype.on = function (type, fn) {
    (this.handlers[type] = this.handlers[type] || []).push(fn);
    return this;
  };
  BasraNet.prototype._emit = function (type, msg) {
    (this.handlers[type] || []).forEach(fn => { try { fn(msg); } catch (e) { console.error(e); } });
  };

  /* رابط السيرفر — نفس المضيف اللي فتح الصفحة */
  BasraNet.prototype.serverUrl = function () {
    const proto = location.protocol === 'https:' ? 'wss://' : 'ws://';
    return proto + location.host;
  };

  BasraNet.prototype.connect = function () {
    const self = this;
    this._closedByUser = false;
    try { this.ws = new WebSocket(this.serverUrl()); }
    catch (e) { this._scheduleReconnect(); return; }

    this.ws.onopen = function () {
      self._retry = 0;
      self._emit('open');
      /* لو عندنا جلسة سابقة نرجع لها */
      if (self.session && self.roomCode)
        self.send({ t: 'resume', code: self.roomCode, session: self.session });
      /* نرسل اللي تجمع بالطابور وقت الانقطاع */
      const q = self._queue.splice(0);
      q.forEach(o => self.send(o));
    };
    this.ws.onmessage = function (ev) {
      let m;
      try { m = JSON.parse(ev.data); } catch { return; }
      /* نحفظ الجلسة عند الإنشاء/الدخول */
      if ((m.t === 'created' || m.t === 'joined') && m.session) {
        self.session = m.session;
        self.roomCode = m.code;
        self.seat = m.seat;
        try {
          localStorage.setItem('online_session', m.session);
          localStorage.setItem('online_room', m.code);
          localStorage.setItem('online_seat', String(m.seat));
        } catch (e) {}
      }
      if (m.t === 'kicked' || (m.t === 'error' && /انتهت|من جديد/.test(m.msg || '')))
        self.clearSession();
      self._emit(m.t, m);
    };
    this.ws.onclose = function () {
      self._emit('close');
      if (!self._closedByUser) self._scheduleReconnect();
    };
    this.ws.onerror = function () { /* onclose بيتكفل */ };
  };

  BasraNet.prototype._scheduleReconnect = function () {
    const self = this;
    this._retry = Math.min(this._retry + 1, 6);
    const wait = Math.min(1000 * Math.pow(1.6, this._retry), 10000);
    this._emit('reconnecting', { attempt: this._retry, wait });
    setTimeout(() => { if (!self._closedByUser) self.connect(); }, wait);
  };

  BasraNet.prototype.send = function (obj) {
    if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(obj));
    else this._queue.push(obj);
  };

  BasraNet.prototype.clearSession = function () {
    this.session = null; this.roomCode = null; this.seat = null;
    try {
      localStorage.removeItem('online_session');
      localStorage.removeItem('online_room');
      localStorage.removeItem('online_seat');
    } catch (e) {}
  };

  /* استرجاع جلسة محفوظة (مثلاً بعد تحديث الصفحة) */
  BasraNet.prototype.restoreSession = function () {
    try {
      const s = localStorage.getItem('online_session');
      const c = localStorage.getItem('online_room');
      if (s && c) { this.session = s; this.roomCode = c; this.seat = Number(localStorage.getItem('online_seat')); return true; }
    } catch (e) {}
    return false;
  };

  BasraNet.prototype.close = function () {
    this._closedByUser = true;
    if (this.ws) this.ws.close();
  };

  global.BasraNet = BasraNet;
})(window);
