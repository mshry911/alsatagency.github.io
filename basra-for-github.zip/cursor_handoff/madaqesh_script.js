/* ================== منطق صافي (بدون واجهة) ================== */
const SUIT_CH={H:'♥',D:'♦',C:'♣',S:'♠'};
const SUITS=['H','D','C','S'];
/* الفئات مرتبة من الأقوى: كل لاعب إضافي يضيف فئة (عشرات ثم تسعات...) حتى 8 لاعبين = 32 ورقة */
const RANKS=['A','K','Q','J','10','9','8','7'];
const RV={A:8,K:7,Q:6,J:5,'10':4,'9':3,'8':2,'7':1};
const RANK_AR={A:'A',K:'K',Q:'Q',J:'J','10':'10','9':'9','8':'8','7':'7'};
const RANK_NAME={A:'إكك',K:'شياب',Q:'بنات',J:'أولاد','10':'عشرات','9':'تسعات','8':'ثمانيات','7':'سبعات'};

function mkDeck(numRanks){
  const d=[];
  for(const s of SUITS)for(const r of RANKS.slice(0,numRanks||4))d.push({s,r,id:s+r});
  return d;
}
function shuffle(d,rnd){
  rnd=rnd||Math.random;
  for(let i=d.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[d[i],d[j]]=[d[j],d[i]];}
  return d;
}

/* تقييم يد من 4 أوراق.
   ترتيب الفئات (كما اتفقنا): مشروع كامل (5) > زوجين (4) > ثلاث أوراق (3) > زوج (2) > شكل (1) */
const CAT_NAME={5:'مشروع كامل',4:'زوجين',3:'ثلاث أوراق',2:'زوج',1:'شكل'};
function evalHand(cards){
  const counts={};
  cards.forEach(c=>{counts[c.r]=(counts[c.r]||0)+1;});
  const groups=Object.keys(counts).map(r=>({r,n:counts[r],v:RV[r]}))
    .sort((a,b)=>b.n-a.n||b.v-a.v);
  let cat,tb;
  if(groups[0].n===4){cat=5;tb=[groups[0].v];}
  else if(groups[0].n===3){cat=3;tb=[groups[0].v,groups[1].v];}
  else if(groups[0].n===2&&groups[1].n===2){
    const hi=Math.max(groups[0].v,groups[1].v),lo=Math.min(groups[0].v,groups[1].v);
    cat=4;tb=[hi,lo];
  }
  else if(groups[0].n===2){cat=2;tb=[groups[0].v].concat(groups.slice(1).map(g=>g.v).sort((a,b)=>b-a));}
  else{cat=1;tb=groups.map(g=>g.v).sort((a,b)=>b-a);}
  return {cat,tb,name:CAT_NAME[cat]};
}
/* مقارنة يدين: موجب = a أقوى، صفر = تعادل */
function compareHands(a,b){
  const ea=evalHand(a),eb=evalHand(b);
  if(ea.cat!==eb.cat)return ea.cat-eb.cat;
  for(let i=0;i<Math.max(ea.tb.length,eb.tb.length);i++){
    const x=ea.tb[i]||0,y=eb.tb[i]||0;
    if(x!==y)return x-y;
  }
  return 0;
}
/* فائزو المداقشة: مصفوفة مؤشرات (أكثر من واحد عند التعادل) */
function handWinners(entries){ // entries: [{p, hand}]
  let best=[],bestVal=null;
  for(const e of entries){
    if(!bestVal){best=[e.p];bestVal=e.hand;continue;}
    const c=compareHands(e.hand,bestVal);
    if(c>0){best=[e.p];bestVal=e.hand;}
    else if(c===0)best.push(e.p);
  }
  return best;
}
/* قوة اليد 0..1 (لقرارات البوتات) */
function handStrength(cards){
  const e=evalHand(cards);
  switch(e.cat){
    case 5:return .92+e.tb[0]*.02;                    // مشروع كامل
    case 4:return .78+e.tb[0]*.02+e.tb[1]*.005;       // زوجين
    case 3:return .58+e.tb[0]*.025+e.tb[1]*.005;      // ثلاث أوراق
    case 2:return .24+e.tb[0]*.05+e.tb[1]*.01;        // زوج
    default:return .03+e.tb[0]*.03+e.tb[1]*.008;      // شكل
  }
}
/* قرار بوت في السوق.
   in: {bal, stake, high, mustOpen, minOpen}
   out: {act:'open'|'raise'|'call'|'fold'|'allin', amount} — amount = المبلغ الجديد الكلي للمزايدة
   القاعدة: كل المزايدات بمضاعفات 500 (الاستثناء الوحيد: "الكل" بآخر رصيد) */
const r500=v=>Math.max(500,Math.round(v/500)*500);
function aiBid(hand,st,inState){
  const w=handStrength(hand);
  const bluff=Math.random()<.12;
  const eff=bluff?Math.min(1,w+.45):w;
  if(inState.mustOpen){
    if(eff<.18&&!bluff)return{act:'open',amount:Math.min(inState.minOpen,inState.bal)};
    const amt=r500(inState.minOpen+eff*1500*(0.6+Math.random()*0.8));
    return{act:'open',amount:Math.min(amt,r500Floor(inState.bal))};
  }
  const cost=inState.high-st; // كم يلزمه للمجاراة
  if(cost<=0)return{act:'call'};
  // رصيده ما يغطي المجاراة؟ إما الكل بيد قوية أو انسحاب
  if(inState.bal<inState.high){
    return eff>=.55?{act:'allin',amount:inState.bal}:{act:'fold'};
  }
  // مزاج الرفع: قوة عالية = يرفع (بمضاعفات 500)
  if(eff>.72&&Math.random()<.55){
    const raise=r500(500+eff*1000*Math.random());
    const to=Math.min(r500Floor(inState.bal),inState.high+raise);
    if(to>inState.high)return{act:'raise',amount:to};
  }
  // المجاراة: يدفع حسب قوة يده، والبخيل ما يدفع كثير على يد ضعيفة
  const maxPay=eff*(eff>.5?3200:1500);
  if(cost<=maxPay)return{act:'call'};
  return{act:'fold'};
}
function r500Floor(v){return Math.max(0,Math.floor(v/500)*500);}
/* هل يختار البوت الإرضاء أو المداقشة؟ وكم يعرض؟ */
function aiSettle(hand,pot,opps){ // opps: [{p,stake}]
  const w=handStrength(hand);
  if(w>=.85)return{mode:'showdown'};                        // يده مضمونة — داقشهم
  if(w<.2&&Math.random()<.25)return{mode:'showdown'};       // بلوف أحياناً
  // يعرض على كل واحد نسبة من مزايدته حسب ضعف يدي (بمضاعفات 500 مثل كل اللعبة)
  const offers={};
  let total=0;
  for(const o of opps){
    let x=r500(o.stake*(0.45+(1-w)*0.45));
    x=Math.min(x,r500Floor(o.stake)); // ما يزيد عن مزايدته
    offers[o.p]=x; total+=x;
  }
  if(total>=pot)return{mode:'showdown'};                    // الإرضاء أغلى من الساحة؟ داقش أحسن
  return{mode:'deal',offers};
}
/* هل يقبل البوت عرض الإرضاء؟ */
function aiAccept(hand,stake,offer){
  const w=handStrength(hand);
  return offer>=stake*(0.55+w*0.9); // القوي ما يرضى إلا بسخاء، الضعيف يرضى بالقليل
}

/* ================== الواجهة وسير اللعبة ================== */
if(typeof document!=='undefined'){(function(){
const el=id=>document.getElementById(id);
const NAMES=['أنت','حمد','مشاري','سعيد','خالد','فهد','سلطان','عبدالله'];
const AR_D=['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
const arNum=n=>String(n).split('').map(ch=>/\d/.test(ch)?AR_D[+ch]:ch).join('');
const fmt=n=>arNum(n.toLocaleString('en-US')).replace(/,/g,'٬');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const REDUCED=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;

/* --- صوت --- */
let muted=false, actx=null;
function tone(f,d,type,vol){
  if(muted)return;
  try{
    actx=actx||new (window.AudioContext||window.webkitAudioContext)();
    if(actx.state==='suspended')actx.resume().catch(()=>{});
    const o=actx.createOscillator(),g=actx.createGain();
    o.type=type||'triangle'; o.frequency.value=f;
    g.gain.setValueAtTime(vol||.12,actx.currentTime);
    g.gain.exponentialRampToValueAtTime(.001,actx.currentTime+(d||.12));
    o.connect(g).connect(actx.destination);
    o.start(); o.stop(actx.currentTime+(d||.12));
  }catch(e){}
}
const sndDeal=()=>tone(320,.06,'square',.05);
const sndChip=()=>{tone(880,.05,'square',.06);setTimeout(()=>tone(660,.07,'square',.05),60);};
const sndTake=()=>{tone(520,.1);setTimeout(()=>tone(660,.12),90);};
const sndBad =()=>tone(180,.25,'sawtooth',.08);
const sndWin =()=>{[523,659,784,1047].forEach((f,i)=>setTimeout(()=>tone(f,.18),i*130));};
const sndLose=()=>{[392,330,262].forEach((f,i)=>setTimeout(()=>tone(f,.2,'sawtooth',.07),i*160));};
function shake(){
  const s=el('stage');
  if(REDUCED||!s.animate)return;
  s.animate([
    {transform:'translate(0,0)'},{transform:'translate(-7px,4px)'},
    {transform:'translate(6px,-5px)'},{transform:'translate(-5px,3px)'},
    {transform:'translate(3px,-2px)'},{transform:'translate(0,0)'}
  ],{duration:380,easing:'ease-out'});
}

/* --- الأصول (صور الأوراق والخط مأخوذة من ملف بلوت كما هي) --- */
__CARD_IMG_DEF__
function cardEl(c){
  const d=document.createElement('div');
  const red=c.s==='H'||c.s==='D';
  d.className='card '+(red?'red':'blk');
  const img=(typeof CARD_IMG!=='undefined')?CARD_IMG[c.s+c.r]:null;
  if(img){
    d.classList.add('court');
    d.style.backgroundImage='url('+img+')';
  }else{
    d.innerHTML='<div class="tl">'+RANK_AR[c.r]+'<br>'+SUIT_CH[c.s]+'</div><div class="mid">'+SUIT_CH[c.s]+'</div>';
  }
  return d;
}
function bubble(p,txt,ms){
  const b=el('bub'+p);
  b.textContent=txt;
  b.classList.add('show');
  clearTimeout(b._t);
  b._t=setTimeout(()=>b.classList.remove('show'),ms||1500);
}
function toast(txt,ms){
  const t=el('toast');
  t.textContent=txt;
  t.classList.add('show');
  clearTimeout(t._t);
  t._t=setTimeout(()=>t.classList.remove('show'),ms||2600);
}
function floatPts(x,y,txt){
  const f=document.createElement('div');
  f.className='float'; f.textContent=txt;
  f.style.left=x+'px'; f.style.top=y+'px';
  document.body.appendChild(f);
  setTimeout(()=>f.remove(),1200);
}

/* --- مؤقت الدور --- */
let _timer=null;
function stopTimer(){
  if(_timer){clearInterval(_timer);_timer=null;}
  el('humanTimer').style.display='none';
}
function startTimer(onTimeout,secs){
  if(typeof SETTINGS==='undefined'||SETTINGS.timer!==true)return;
  stopTimer();
  secs=secs||15;
  const total=secs*1000;
  let left=total;
  const ht=el('humanTimer');
  ht.style.display='flex';
  const draw=()=>{
    const pct=left/total*360;
    ht.style.background='conic-gradient(var(--sadu-gold) '+pct+'deg, rgba(255,255,255,.14) 0)';
    el('htNum').textContent=arNum(Math.ceil(left/1000));
  };
  draw();
  _timer=setInterval(()=>{
    left-=100;
    if(left<=0){stopTimer();onTimeout&&onTimeout();return;}
    if(left<=3000&&left%1000<100)tone(760,.06,'square',.05);
    draw();
  },100);
}

/* --- حالة اللعبة --- */
const START_BAL=5000, MIN_OPEN=500;
let SETTINGS={sound:true,timer:false,players:4};
try{Object.assign(SETTINGS,JSON.parse(localStorage.getItem('madaqesh_settings')||'{}'));}catch(e){}
SETTINGS.players=Math.max(2,Math.min(8,SETTINGS.players||4));
function saveSettings(){try{localStorage.setItem('madaqesh_settings',JSON.stringify(SETTINGS));}catch(e){}}
muted=!SETTINGS.sound;

let P=[];      // اللاعبون: {name,bal,rebuy,out,hand,stake,folded,allIn}
let G=null;    // حالة الجولة: {n, opener, high, top, pot, phase, id}
let roundNo=1;

function freshPlayers(n){
  return NAMES.slice(0,n).map(nm=>({name:nm,bal:START_BAL,rebuy:true,out:false,hand:[],stake:0,folded:false,allIn:false}));
}
function saveGame(){
  try{localStorage.setItem('madaqesh_save',JSON.stringify({
    n:G?G.n:P.length,
    players:P.map(p=>({bal:p.bal,rebuy:p.rebuy,out:p.out})),
    opener:G?G.opener:0, roundNo
  }));}catch(e){}
}
function loadGame(){
  try{
    const sv=JSON.parse(localStorage.getItem('madaqesh_save'));
    const n=sv&&sv.n;
    if(!sv||!n||n<2||n>8||!sv.players||sv.players.length!==n)return false;
    P=NAMES.slice(0,n).map((nm,i)=>({name:nm,bal:sv.players[i].bal,rebuy:sv.players[i].rebuy,out:sv.players[i].out,hand:[],stake:0,folded:false,allIn:false}));
    G={n,opener:sv.opener||0,high:0,top:-1,pot:0,phase:'idle'};
    roundNo=sv.roundNo||1;
    return true;
  }catch(e){return false;}
}
function clearGame(){try{localStorage.removeItem('madaqesh_save');}catch(e){}}
function newGame(n){
  n=n||SETTINGS.players||4;
  P=freshPlayers(n);
  G={n,opener:Math.floor(Math.random()*n),high:0,top:-1,pot:0,phase:'idle'};
  roundNo=1;
  clearGame();
}
const alive=()=>P.map((p,i)=>i).filter(i=>!P[i].out);
const nextAlive=from=>{let i=from;do{i=(i+1)%P.length;}while(P[i].out);return i;};

/* --- المقاعد الديناميكية (من 2 إلى 8 لاعبين) --- */
/* مواقع مقاعد الخصوم حول الطاولة [x%, y%] حسب عددهم */
const SEAT_POS={
  1:[[50,4]],
  2:[[88,28],[12,28]],
  3:[[92,45],[50,4],[8,45]],
  4:[[92,40],[68,2],[32,2],[8,40]],
  5:[[93,50],[76,4],[24,4],[7,50],[50,0]],
  6:[[93,55],[82,8],[58,0],[42,0],[18,8],[7,55]],
  7:[[93,58],[85,12],[68,0],[50,0],[32,0],[15,12],[7,58]],
};
function buildSeats(){
  const n=P.length;
  // امسح المقاعد الديناميكية القديمة
  document.querySelectorAll('.seat.dyn').forEach(s=>s.remove());
  const stage=el('stage');
  el('stage').classList.toggle('crowded',n>5);
  const pos=SEAT_POS[n-1]||SEAT_POS[3];
  for(let i=1;i<n;i++){
    const [x,y]=pos[i-1];
    const seat=document.createElement('div');
    seat.className='seat dyn'+(y<40?' flip':'');
    seat.id='seat'+i;
    seat.style.left=x+'%'; seat.style.top=y+'%';
    seat.style.transform='translate(-50%,-50%)';
    seat.innerHTML='<div class="fan" id="fan'+i+'"></div>'
      +'<div class="reveal" id="rev'+i+'"></div>'
      +'<div class="seatname" id="name'+i+'">'+P[i].name+'</div>'
      +'<div class="seatbal" id="bal'+i+'"></div>'
      +'<div class="bubble" id="bub'+i+'"></div>';
    stage.appendChild(seat);
  }
}

/* --- رسم --- */
function renderBalances(){
  for(let i=0;i<P.length;i++){
    const b=el('bal'+i);
    b.textContent=P[i].out?'طالع':fmt(P[i].bal)+(P[i].rebuy?'':' ⚠️');
    b.classList.toggle('broke',!P[i].out&&P[i].bal<=1000);
    el('name'+i).classList.toggle('out',P[i].out);
  }
  el('myBal').textContent=fmt(P[0].bal);
}
function renderFans(){
  for(let p=1;p<P.length;p++){
    const f=el('fan'+p); if(!f)continue;
    f.innerHTML='';
    if(P[p].out)continue;
    const n=P[p].hand.length||4;
    const mid=(n-1)/2;
    for(let i=0;i<n;i++){
      const c=document.createElement('div');
      c.className='card back fc';
      c.style.transform='rotate('+((i-mid)*12)+'deg)';
      if(P[p].folded)c.style.opacity='.35';
      f.appendChild(c);
    }
  }
}
function renderHand(animate){
  const h=el('hand'); h.innerHTML='';
  const sorted=P[0].hand.slice().sort((a,b)=>RV[b.r]-RV[a.r]||SUITS.indexOf(a.s)-SUITS.indexOf(b.s));
  sorted.forEach((c,i)=>{
    const w=document.createElement('div');
    w.className='fw';
    const d=cardEl(c);
    if(animate){d.classList.add('dealt'); d.style.animationDelay=(i*90)+'ms'; if(!muted)setTimeout(sndDeal,i*90);}
    if(P[0].folded)d.style.opacity='.4';
    w.appendChild(d);
    h.appendChild(w);
  });
  // تلميح بقوة اليد تحت أوراقك
  if(P[0].hand.length&&!P[0].folded){
    const t=document.createElement('div');
    t.className='hint';
    t.style.position='absolute'; t.style.bottom='-4px'; t.style.width='100%';
    t.textContent='يدك: '+evalHand(P[0].hand).name;
    h.appendChild(t);
  }
}
function markTurn(p){
  for(let i=0;i<P.length;i++)el('name'+i).classList.toggle('turn',i===p);
  if(p!==0)stopTimer();
}
function setPot(sub){
  el('potAmt').textContent=fmt(G.pot);
  el('potSub').textContent=sub||'';
}
function actions(html){el('actions').innerHTML=html;}

/* ================== الجولة ================== */
async function startRound(){
  stopTimer();
  const al=alive();
  if(al.length<=1){gameOver();return;}
  if(P[0].out){ // أنت طالع — وضع المشاهدة
    toast('أنت طالع من اللعبة — تشوف الباقي يكملون');
  }
  // تدوير الفاتح
  if(roundNo>1)G.opener=nextAlive(G.opener);
  while(P[G.opener].out)G.opener=nextAlive(G.opener);
  G.high=0; G.top=-1; G.pot=0; G.phase='dealing';
  G.id=Math.random(); // حارس: لو بدأت لعبة جديدة بنص جولة، الجولة القديمة توقف نفسها
  for(const p of P){p.hand=[];p.stake=0;p.folded=false;p.allIn=false;}
  actions('');
  buildSeats();
  for(let i=0;i<P.length;i++){
    el('rev'+i).innerHTML='';el('rev'+i).dataset.tag='';
    const t=el('htag'+i); if(t)t.remove();
  }
  const deck=shuffle(mkDeck(G.n)); // عدد الفئات = عدد اللاعبين
  for(let k=0;k<4;k++)for(const i of al)P[i].hand.push(deck.pop());
  el('roundLbl').textContent='جولة '+arNum(roundNo);
  renderBalances(); renderFans(); renderHand(true); setPot('');
  toast('يفتح السوق: '+NAMES[G.opener]);
  await sleep(1400);
  G.phase='market';
  runMarket();
}

/* دور واحد بالسوق */
async function runMarket(){
  const gid=G.id;
  let p=G.opener;
  let firstTurn=true;
  let guard=0;
  for(;;){
    if(G.id!==gid)return; // انقطعت الجولة (لعبة جديدة)
    if(++guard>400)break; // حماية قصوى من أي تعليق
    const active=alive().filter(i=>!P[i].folded);
    if(active.length<=1)break;
    // شرط الإغلاق: كل الباقين إما مجاريين أعلى مزايدة أو راحوا بالكل (وما هو أول دور)
    if(!firstTurn&&G.high>0&&active.every(i=>P[i].stake===G.high||P[i].allIn))break;
    if(P[p].folded||P[p].out||P[p].allIn){p=nextAlive(p);continue;}
    markTurn(p);
    const mustOpen=firstTurn&&p===G.opener&&G.high===0;
    if(p===0&&!P[0].out){
      await humanBid(mustOpen);
    }else{
      await sleep(850);
      if(G.id!==gid)return;
      aiBidTurn(p,mustOpen);
    }
    firstTurn=false;
    // انتهى السوق ببقاء لاعب واحد؟
    const act2=alive().filter(i=>!P[i].folded);
    if(act2.length<=1)break;
    p=nextAlive(p);
  }
  if(G.id!==gid)return;
  markTurn(-1);
  settleMarket();
}

function humanBid(mustOpen){
  return new Promise(res=>{
    const me=P[0];
    // حدود العدّاد: بمضاعفات 500
    const stepMin=mustOpen?MIN_OPEN:G.high+500;
    const maxBid=r500Floor(me.bal);
    const canStep=maxBid>=stepMin&&me.bal>=stepMin;
    let val=Math.min(stepMin,me.bal);
    const canCall=!mustOpen&&me.bal>=G.high;
    const draw=()=>{
      let html='<div class="hint">'+(mustOpen?'أنت فاتح السوق — أقل مزايدة <b>'+fmt(MIN_OPEN)+'</b> (بمضاعفات ٥٠٠)':'أعلى مزايدة <b>'+fmt(G.high)+'</b> — مزايدتك الحالية '+fmt(me.stake)+' — اكتب رقمك (بمضاعفات ٥٠٠)')+'</div>';
      if(canStep){
        html+='<div class="offerRow"><button id="oMin">−</button><div class="val">'+fmt(val)+'</div><button id="oPlus">+</button></div>';
        html+='<button class="gold" id="bBid">'+(mustOpen?'افتح بـ':'زايد ')+fmt(val)+'</button>';
      }
      if(canCall)html+='<button id="bCall">ماشي — '+fmt(G.high)+'</button>';
      html+='<button class="danger" id="bAll">الكل — '+fmt(me.bal)+'</button>';
      if(!mustOpen)html+='<button class="ghost" id="bFold">انسحاب</button>';
      actions(html);
      if(canStep){
        el('oMin').onclick=()=>{val=Math.max(stepMin,val-500);draw();};
        el('oPlus').onclick=()=>{val=Math.min(maxBid,val+500);draw();};
        el('bBid').onclick=()=>done(()=>placeBid(0,val,mustOpen));
      }
      if(el('bCall')&&canCall)el('bCall').onclick=()=>done(()=>callBid(0));
      el('bAll').onclick=()=>done(()=>allIn(0));
      if(el('bFold'))el('bFold').onclick=()=>done(()=>foldBid(0));
    };
    const done=fn=>{stopTimer();actions('');fn();res();};
    draw();
    startTimer(()=>done(()=>{
      if(canCall)callBid(0);else foldBid(0);
    }));
  });
}

function placeBid(p,amount,opening){
  amount=Math.min(amount,P[p].bal);
  if(!opening&&amount<=G.high)return; // حماية: لازم أعلى
  P[p].stake=amount;
  G.high=amount; G.top=p;
  if(amount>=P[p].bal)P[p].allIn=true; // زايد بكل رصيده
  sndChip();
  bubble(p,(opening?'أفتح بـ':'أزايد ')+fmt(amount)+'!');
  setPot('أعلى مزايدة: '+fmt(G.high)+' — '+NAMES[p]);
}
/* "الكل": مزايدة بكامل الرصيد — مفتوحة حتى لو أقل من أعلى مزايدة */
function allIn(p){
  P[p].stake=P[p].bal; P[p].allIn=true;
  if(P[p].bal>G.high){G.high=P[p].bal; G.top=p;}
  sndChip(); shake();
  bubble(p,'الكل! '+fmt(P[p].bal)+' 🔥');
  setPot('أعلى مزايدة: '+fmt(G.high)+' — '+NAMES[G.top]);
}
function callBid(p){
  P[p].stake=Math.min(G.high,P[p].bal);
  sndChip();
  bubble(p,'ماشي — '+fmt(G.high));
}
function foldBid(p){
  P[p].folded=true; P[p].stake=0; // الانسحاب مجاني — ما عليه شي
  sndBad();
  bubble(p,'انسحب');
  if(p===0)renderHand(false); else renderFans();
}

function aiBidTurn(p,mustOpen){
  const d=aiBid(P[p].hand,P[p].stake,{bal:P[p].bal,high:G.high,mustOpen,minOpen:MIN_OPEN});
  if(d.act==='open')placeBid(p,d.amount,true);
  else if(d.act==='raise')placeBid(p,d.amount);
  else if(d.act==='allin')allIn(p);
  else if(d.act==='call')callBid(p);
  else foldBid(p);
}

/* ================== الحسم: تفاهم أو مداقشة ================== */
async function settleMarket(){
  const gid=G.id;
  const survivors=alive().filter(i=>!P[i].folded);
  if(survivors.length===0){endRoundCleanup();return;}
  if(survivors.length===1){
    // الكل انسحب — الباقي لحاله ياخذ قيمة مزايدته ربحاً من البنك (ومزايدته ترجع له أصلاً)
    const s=survivors[0];
    const gain=P[s].stake;
    P[s].bal+=gain;
    bubble(s,'الساحة لي! 😎');
    toast('الكل انسحب — '+NAMES[s]+' ياخذ '+fmt(gain)+' قيمة مزايدته');
    const r=el('seat'+s).getBoundingClientRect();
    floatPts(r.left+r.width/2,r.top,'+'+fmt(gain));
    renderBalances(); sndTake();
    await sleep(1400);
    if(G.id!==gid)return;
    endRoundCleanup();
    return;
  }
  // تحصيل المزايدات في الساحة
  G.pot=0;
  for(const i of survivors){P[i].bal-=P[i].stake;G.pot+=P[i].stake;}
  renderBalances(); setPot('بين '+survivors.map(i=>NAMES[i]).join(' و'));
  sndChip(); shake();
  await sleep(900);
  if(G.id!==gid)return;
  // صاحب أعلى مزايدة يختار: تفاهم أو مداقشة
  const top=G.top;
  G.phase='settle';
  if(top===0&&!P[0].out)await humanSettle(survivors);
  else await aiSettleTurn(top,survivors);
}

async function aiSettleTurn(top,survivors){
  const gid=G.id;
  const opps=survivors.filter(i=>i!==top).map(i=>({p:i,stake:P[i].stake}));
  const d=aiSettle(P[top].hand,G.pot,opps);
  if(d.mode==='deal'){
    bubble(top,'أرضاكم 🤝');
    toast(NAMES[top]+' يعرض إرضاء على الباقين');
    await sleep(1000);
    if(G.id!==gid)return;
    await runOffers(top,survivors,d.offers);
  }else{
    bubble(top,'داقشهم! ⚔️');
    await sleep(900);
    if(G.id!==gid)return;
    await showdown(survivors);
  }
}

function humanSettle(survivors){
  return new Promise(res=>{
    const opps=survivors.filter(i=>i!==0);
    const maxOffer=Math.floor(G.pot/opps.length);
    let offer=Math.min(r500(G.high*0.5),maxOffer); // الافتراضي: نص أعلى مزايدة مقرّب لـ500
    const draw=()=>{
      const keep=G.pot-offer*opps.length;
      actions(
        '<div class="hint">الساحة <b>'+fmt(G.pot)+'</b> — تعطي كل واحد مبلغاً وياخذون هم قرارهم، وإلا داقشهم والأقوى ياخذ الكل</div>'
        +'<div class="offerRow"><button id="oMin">−</button><div class="val">'+fmt(offer)+'</div><button id="oPlus">+</button></div>'
        +'<div class="hint">لو كلهم وافقوا: لكل واحد '+fmt(offer)+' وأنت تاخذ الباقي <b>'+fmt(keep)+'</b></div>'
        +'<button class="gold" id="bDeal">اعرض الإرضاء 🤝</button>'
        +'<button class="danger" id="bFight">داقشهم ⚔️</button>'
      );
      el('oMin').onclick=()=>{offer=Math.max(0,offer-500);draw();};
      el('oPlus').onclick=()=>{offer=Math.min(r500Floor(maxOffer),offer+500);draw();};
      el('bDeal').onclick=()=>{stopTimer();actions('');const offers={};opps.forEach(i=>offers[i]=offer);res(runOffers(0,survivors,offers));};
      el('bFight').onclick=()=>{stopTimer();actions('');bubble(0,'داقشهم! ⚔️');res(showdown(survivors));};
    };
    draw();
    startTimer(()=>{actions('');bubble(0,'داقشهم! ⚔️');res(showdown(survivors));});
  });
}

/* عرض الإرضاء على كل منافس بالترتيب */
async function runOffers(top,survivors,offers){
  const gid=G.id;
  const opps=survivors.filter(i=>i!==top);
  const fighters=[top];
  for(const i of opps){
    const offer=offers[i]||0;
    let accept;
    if(i===0&&!P[0].out){
      accept=await new Promise(res2=>{
        actions('<div class="hint">'+NAMES[top]+' يعرض عليك <b>'+fmt(offer)+'</b> إرضاء وتنسحب بسلام — وإلا داقشه (مزايدتك بالساحة: '+fmt(P[0].stake)+')</div>'
          +'<button class="gold" id="bYes">وافق — خذ '+fmt(offer)+'</button>'
          +'<button class="danger" id="bNo">داقشه ⚔️</button>');
        el('bYes').onclick=()=>{stopTimer();actions('');res2(true);};
        el('bNo').onclick=()=>{stopTimer();actions('');res2(false);};
        startTimer(()=>{actions('');res2(offer>=P[0].stake);});
      });
      if(G.id!==gid)return;
    }else{
      accept=aiAccept(P[i].hand,P[i].stake,offer);
      await sleep(800);
      if(G.id!==gid)return;
    }
    if(accept){
      P[i].bal+=offer; G.pot-=offer;
      bubble(i,'وافق 🤝'); sndTake();
      toast(NAMES[i]+' أخذ '+fmt(offer)+' وانسحب بسلام');
      const r=el('seat'+i).getBoundingClientRect();
      floatPts(r.left+r.width/2,r.top,'+'+fmt(offer));
      setPot('');
      renderBalances();
      await sleep(900);
    }else{
      bubble(i,'داقشك! ⚔️'); sndBad();
      fighters.push(i);
      await sleep(900);
    }
    if(G.id!==gid)return;
  }
  if(fighters.length===1){
    // الكل وافق — صاحب العرض ياخذ الباقي
    P[top].bal+=G.pot;
    toast(NAMES[top]+' ياخذ الباقي: '+fmt(G.pot));
    const r=el('seat'+top).getBoundingClientRect();
    floatPts(r.left+r.width/2,r.top,'+'+fmt(G.pot));
    G.pot=0; setPot(''); renderBalances(); sndTake();
    await sleep(1100);
    endRoundCleanup({type:'deal',top});
    return;
  }
  // فيه من رفض — مداقشة بين صاحب العرض والرافضين على باقي الساحة
  toast('مداقشة على '+fmt(G.pot)+'!');
  await sleep(700);
  await showdown(fighters);
}

/* كشف الأوراق */
async function showdown(fighters){
  const gid=G.id;
  G.phase='showdown';
  shake();
  for(const i of fighters){
    const rv=el('rev'+i);
    rv.innerHTML='';
    P[i].hand.forEach(c=>rv.appendChild(cardEl(c)));
    const tag=document.createElement('div');
    tag.className='handtag'; tag.id='htag'+i;
    tag.textContent=evalHand(P[i].hand).name;
    el('seat'+i).insertBefore(tag,el('name'+i));
  }
  if(fighters.includes(0))renderHand(false);
  sndBad();
  await sleep(1600);
  if(G.id!==gid)return;
  const winners=handWinners(fighters.map(i=>({p:i,hand:P[i].hand})));
  const share=Math.floor(G.pot/winners.length);
  let extra=G.pot-share*winners.length;
  for(const w of winners){
    const gain=share+(extra-->0?1:0);
    P[w].bal+=gain;
    const t=el('htag'+w); if(t)t.classList.add('win');
    const r=el('seat'+w).getBoundingClientRect();
    floatPts(r.left+r.width/2,r.top-10,'+'+fmt(gain));
  }
  const names=winners.map(w=>NAMES[w]).join(' و');
  if(winners.length>1)toast('تعادل! '+names+' يتقاسمون الساحة');
  else{bubble(winners[0],'أكلتها! 😎');}
  G.pot=0; setPot(''); renderBalances();
  (winners.includes(0)?sndWin:sndLose)();
  await sleep(1800);
  if(G.id!==gid)return;
  endRoundCleanup({type:'showdown',fighters,winners});
}

/* نهاية الجولة: الإفلاس والملخص */
function endRoundCleanup(info){
  G.phase='done';
  const events=[];
  for(let i=0;i<P.length;i++){
    if(P[i].out)continue;
    if(P[i].bal<=0){
      if(P[i].rebuy){
        P[i].rebuy=false; P[i].bal=START_BAL;
        events.push(NAMES[i]+' أفلس — البنك أعطاه '+fmt(START_BAL)+' أخيرة (فرصة واحدة بس)');
        if(i===0)toast('البنك أعطاك '+fmt(START_BAL)+' أخيرة — فرصتك الأخيرة! ⚠️',3500);
      }else{
        P[i].out=true;
        events.push(NAMES[i]+' خسر كل شي — طالع من اللعبة 💀');
      }
    }
  }
  for(let i=0;i<P.length;i++){const t=el('htag'+i);if(t)t.remove();}
  renderBalances(); renderFans(); renderHand(false);
  saveGame();
  const al=alive();
  if(al.length<=1){gameOver();return;}
  // لوحة ملخص الجولة
  let html='';
  if(info&&info.type==='showdown'){
    html+='<div class="resNote">⚔️ مداقشة — الفائز: '+info.winners.map(w=>NAMES[w]).join(' و')+'</div>';
    for(const i of info.fighters){
      const e=evalHand(P[i].hand);
      html+='<div class="line" style="display:flex;justify-content:space-between;align-items:center;gap:8px">'
        +'<b>'+NAMES[i]+'</b><span style="font-size:13px">'+e.name+'</span></div>';
      html+='<div class="resCards">'+P[i].hand.map(c=>'<div class="card '+(c.s==='H'||c.s==='D'?'red':'blk')+'"><div class="tl">'+RANK_AR[c.r]+'<br>'+SUIT_CH[c.s]+'</div><div class="mid">'+SUIT_CH[c.s]+'</div></div>').join('')+'</div>';
    }
  }else if(info&&info.type==='deal'){
    html+='<div class="resNote">🤝 تم التفاهم — '+NAMES[info.top]+' أخذ الباقي</div>';
  }else{
    html+='<div class="resNote">الكل انسحب — الباقي لحاله أخذ قيمة مزايدته</div>';
  }
  html+='<div class="sep"></div><table class="resTbl"><thead><tr><th>اللاعب</th><th>الرصيد</th></tr></thead><tbody>';
  for(let i=0;i<P.length;i++){
    html+='<tr><td>'+NAMES[i]+(P[i].out?' 💀':'')+'</td><td class="'+(P[i].bal>=START_BAL?'gain':'loss')+'">'+(P[i].out?'طالع':fmt(P[i].bal))+'</td></tr>';
  }
  html+='</tbody></table>';
  if(events.length)html+='<div class="line" style="font-size:14px;color:#7a4a10">'+events.join('<br>')+'</div>';
  el('rrBody').innerHTML=html;
  el('rrNext').textContent='الجولة التالية';
  el('roundPanel').classList.add('show');
}
el('rrNext').onclick=()=>{
  el('roundPanel').classList.remove('show');
  roundNo++;
  saveGame();
  startRound();
};

function gameOver(){
  G.phase='over';
  clearGame();
  const al=alive();
  const winner=al.length?al[0]:P.reduce((b,p,i)=>p.bal>P[b].bal?i:b,0);
  const humanWon=winner===0;
  let html='<div class="big">'+(humanWon?'🏆':'😔')+'</div>'
    +'<div class="resWin">'+(humanWon?'أنت آخر واحد واقف — كسبت المداقشة!':'الفائز: '+NAMES[winner]+' بـ '+fmt(P[winner].bal))+'</div>'
    +'<div class="sep"></div><table class="resTbl"><thead><tr><th>اللاعب</th><th>الرصيد النهائي</th></tr></thead><tbody>';
  for(let i=0;i<P.length;i++)html+='<tr><td>'+NAMES[i]+'</td><td>'+(P[i].out?'طالع 💀':fmt(P[i].bal))+'</td></tr>';
  html+='</tbody></table>';
  el('ovBody').innerHTML=html;
  el('overPanel').classList.add('show');
  (humanWon?sndWin:sndLose)();
}
el('ovNew').onclick=()=>{
  el('overPanel').classList.remove('show');
  newGame();
  el('roundLbl').textContent='جولة ١';
  startRound();
};

/* ===== الإعدادات والقائمة ===== */
function syncUI(){
  el('muteBtn').textContent=muted?'🔇':'🔊';
  el('setSound').textContent=muted?'مطفي 🔇':'شغال 🔊';
  el('setTimer').textContent=SETTINGS.timer===true?'شغال ⏱':'مطفي';
}
el('muteBtn').onclick=()=>{muted=!muted;SETTINGS.sound=!muted;saveSettings();syncUI();};
el('setSound').onclick=()=>{muted=!muted;SETTINGS.sound=!muted;saveSettings();syncUI();};
el('setTimer').onclick=()=>{SETTINGS.timer=SETTINGS.timer===true?false:true;if(SETTINGS.timer!==true)stopTimer();saveSettings();syncUI();};
/* مختار عدد اللاعبين (٢-٨) */
function drawPlayersRow(){
  el('pVal').textContent=arNum(SETTINGS.players);
  el('pSub').textContent='أنت + '+arNum(SETTINGS.players-1)+' بوت — من ٢ إلى ٨';
}
el('pMin').onclick=()=>{SETTINGS.players=Math.max(2,SETTINGS.players-1);saveSettings();drawPlayersRow();};
el('pPlus').onclick=()=>{SETTINGS.players=Math.min(8,SETTINGS.players+1);saveSettings();drawPlayersRow();};
el('setClose').onclick=()=>el('setPanel').classList.remove('show');
el('menuSettings').onclick=()=>{syncUI();el('setPanel').classList.add('show');};
el('menuBtn').onclick=()=>{
  el('menuResume').style.display=G&&G.phase!=='over'?'':'none';
  el('menu').classList.add('show');
};
el('menuNew').onclick=()=>{
  el('menu').classList.remove('show');
  el('roundPanel').classList.remove('show');
  el('overPanel').classList.remove('show');
  stopTimer(); actions('');
  newGame();
  startRound();
};

/* إقلاع */
syncUI();
drawPlayersRow();
const hasSave=(()=>{try{return !!JSON.parse(localStorage.getItem('madaqesh_save'));}catch(e){return false;}})();
el('menuResume').style.display=hasSave?'':'none';
el('menu').classList.add('show');
el('menuResume').onclick=()=>{
  el('menu').classList.remove('show');
  // لو فيه جولة شغالة حالياً — بس نرجع لها، ما نعيد شي
  if(G&&['dealing','market','settle','showdown'].includes(G.phase))return;
  el('roundPanel').classList.remove('show');
  el('overPanel').classList.remove('show');
  stopTimer(); actions('');
  if(!loadGame())newGame();
  startRound();
};
})();
}else if(typeof module!=='undefined'){
  module.exports={mkDeck,shuffle,evalHand,compareHands,handWinners,handStrength,aiBid,aiSettle,aiAccept,CAT_NAME};
}
