/* ============================================================
   محرك مداقش — نسخة السيرفر (الحكم الوحيد على الأوراق)
   يستخدم المنطق الصافي من madaqesh_script.js (نفس قوانين الأوفلاين)
   ============================================================ */
const crypto = require('crypto');
const core = require('../../madaqesh_script.js');
const { mkDeck, evalHand, handWinners, aiBid, aiSettle, aiAccept } = core;

const START_BAL = 5000, MIN_OPEN = 500;
const TURN_MS = 30000;       /* مهلة المزايدة */
const SETTLE_MS = 30000;     /* مهلة قرار التفاهم/المداقشة */
const OFFER_MS = 20000;      /* مهلة الرد على عرض الإرضاء */
const NEXT_MS = 45000;       /* لو ما أحد ضغط الجولة التالية */
const BOT_DELAY = 1100;      /* تأخير لعب البوت عشان الإيقاع */
const r500Floor = v => Math.max(0, Math.floor(v / 500) * 500);

/* خلط بعشوائية تشفيرية — العدالة تبدأ من هنا */
function cryptoShuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

class MadaqeshGame {
  /**
   * room: غرفة السيرفر — api: {toSeat(seat,obj), broadcastAll(obj), onGameOver()}
   */
  constructor(room, api) {
    this.room = room;
    this.api = api;
    this.destroyed = false;
    this.timers = new Set();

    /* اللاعبون = المقاعد المعبّأة وقت البدء (بشر + بوتات) */
    this.P = room.players.filter(p => p).map(p => ({
      seat: p.seat, name: p.name, isBot: p.isBot,
      bal: START_BAL, rebuy: true, out: false,
      hand: [], stake: 0, folded: false, allIn: false,
    }));
    this.roundNo = 1;
    this.opener = crypto.randomInt(this.P.length);
    this.high = 0; this.top = -1; this.pot = 0;
    this.phase = 'idle';
    this.awaiting = null;    /* {idx, kind, timer} */
    this.gid = 0;            /* حارس الجولة */
  }

  /* ---------- أدوات ---------- */
  later(fn, ms) { const t = setTimeout(() => { this.timers.delete(t); if (!this.destroyed) fn(); }, ms); this.timers.add(t); return t; }
  alive() { return this.P.map((p, i) => i).filter(i => !this.P[i].out); }
  nextAlive(from) { let i = from; do { i = (i + 1) % this.P.length; } while (this.P[i].out); return i; }
  bySeat(seat) { return this.P.findIndex(p => p.seat === seat); }

  destroy() { this.destroyed = true; for (const t of this.timers) clearTimeout(t); this.timers.clear(); }

  /* ---------- البث ---------- */
  gstate() {
    return {
      t: 'gstate',
      game: 'madaqesh',
      phase: this.phase, roundNo: this.roundNo,
      pot: this.pot, high: this.high, top: this.top,
      turn: this.awaiting ? this.awaiting.idx : -1,
      players: this.P.map(p => ({
        seat: p.seat, name: p.name, isBot: p.isBot,
        bal: p.bal, rebuy: p.rebuy, out: p.out,
        stake: p.stake, folded: p.folded, allIn: p.allIn,
        cards: p.out ? 0 : p.hand.length,
      })),
    };
  }
  pushState() { this.api.broadcastAll(this.gstate()); }
  pushEvent(ev) { ev.t = 'gevent'; this.api.broadcastAll(ev); }
  sendHand(idx) {
    const p = this.P[idx];
    if (p.isBot || p.out) return;
    this.api.toSeat(p.seat, { t: 'ghand', hand: p.hand, eval: p.hand.length ? evalHand(p.hand).name : '' });
  }
  bubble(idx, txt) { this.pushEvent({ k: 'bubble', idx, txt }); }
  toast(txt) { this.pushEvent({ k: 'toast', txt }); }

  /* ---------- إقلاع ---------- */
  start() { this.pushState(); this.startRound(); }

  startRound() {
    const gid = ++this.gid;
    if (this.alive().length <= 1) return this.gameOver();
    if (this.roundNo > 1) this.opener = this.nextAlive(this.opener);
    while (this.P[this.opener].out) this.opener = this.nextAlive(this.opener);

    this.high = 0; this.top = -1; this.pot = 0; this.phase = 'dealing';
    for (const p of this.P) { p.hand = []; p.stake = 0; p.folded = false; p.allIn = false; }

    const deck = cryptoShuffle(mkDeck(this.P.length));
    const al = this.alive();
    for (let k = 0; k < 4; k++) for (const i of al) this.P[i].hand.push(deck.pop());

    this.pushState();
    for (const i of al) this.sendHand(i);
    this.pushEvent({ k: 'deal' });
    this.toast('يفتح السوق: ' + this.P[this.opener].name);

    this.later(() => { this.phase = 'market'; this.pushState(); this.marketLoop(gid, this.opener, true); }, 1800);
  }

  /* ---------- السوق ---------- */
  marketLoop(gid, idx, firstTurn) {
    if (this.destroyed || gid !== this.gid) return;
    const active = this.alive().filter(i => !this.P[i].folded);
    if (active.length <= 1) return this.settleMarket(gid);
    if (!firstTurn && this.high > 0 && active.every(i => this.P[i].stake === this.high || this.P[i].allIn))
      return this.settleMarket(gid);

    let p = idx;
    while (this.P[p].folded || this.P[p].out || this.P[p].allIn) p = this.nextAlive(p);

    const mustOpen = firstTurn && p === this.opener && this.high === 0;
    const me = this.P[p];

    if (me.isBot) {
      this.awaiting = { idx: p, kind: 'bid' };
      this.pushState();
      this.later(() => {
        if (this.gid !== gid) return;
        this.awaiting = null;
        const d = aiBid(me.hand, me.stake, { bal: me.bal, high: this.high, mustOpen, minOpen: MIN_OPEN });
        this.applyBid(p, d);
        this.marketLoop(gid, this.nextAlive(p), false);
      }, BOT_DELAY + crypto.randomInt(700));
    } else {
      const connected = this.isConnected(me.seat);
      this.awaiting = { idx: p, kind: 'bid' };
      this.pushState();
      this.api.toSeat(me.seat, {
        t: 'gturn', kind: 'bid', mustOpen,
        high: this.high, bal: me.bal, stake: me.stake,
        minOpen: MIN_OPEN, maxBid: r500Floor(me.bal),
        canCall: !mustOpen && me.bal >= this.high,
        secs: TURN_MS / 1000,
      });
      /* المنقطع ما نستناه طويل */
      const wait = connected ? TURN_MS : 3000;
      this.awaiting.timer = this.later(() => {
        if (this.gid !== gid || !this.awaiting || this.awaiting.idx !== p) return;
        this.awaiting = null;
        const canCall = !mustOpen && me.bal >= this.high;
        this.applyBid(p, canCall ? { act: 'call' } : { act: 'fold' });
        this.marketLoop(gid, this.nextAlive(p), false);
      }, wait);
    }
  }

  isConnected(seat) {
    const rp = this.room.players[seat];
    return !!(rp && rp.connected);
  }

  applyBid(p, d) {
    const me = this.P[p];
    const mustOpen = this.high === 0;
    switch (d.act) {
      case 'open':
      case 'raise': {
        let amount = Math.min(Number(d.amount) || 0, me.bal);
        const minAllowed = mustOpen ? MIN_OPEN : this.high + 500;
        if (amount < minAllowed || (!mustOpen && amount <= this.high)) return false;
        amount = Math.round(amount / 500) * 500;
        me.stake = amount; this.high = amount; this.top = p;
        if (amount >= me.bal) me.allIn = true;
        this.bubble(p, (mustOpen ? 'أفتح بـ' : 'أزايد ') + amount + '!');
        this.pushEvent({ k: 'sound', name: 'chip' });
        break;
      }
      case 'allin': {
        me.stake = me.bal; me.allIn = true;
        if (me.bal > this.high) { this.high = me.bal; this.top = p; }
        this.bubble(p, 'الكل! ' + me.bal + ' 🔥');
        this.pushEvent({ k: 'sound', name: 'chip' });
        this.pushEvent({ k: 'shake' });
        break;
      }
      case 'call': {
        if (mustOpen) return false;
        me.stake = Math.min(this.high, me.bal);
        this.bubble(p, 'ماشي — ' + this.high);
        this.pushEvent({ k: 'sound', name: 'chip' });
        break;
      }
      case 'fold': {
        me.folded = true; me.stake = 0;
        this.bubble(p, 'انسحب');
        this.pushEvent({ k: 'sound', name: 'bad' });
        break;
      }
      default: return false;
    }
    this.pushState();
    return true;
  }

  /* ---------- الحسم ---------- */
  settleMarket(gid) {
    if (this.destroyed || gid !== this.gid) return;
    this.awaiting = null;
    const survivors = this.alive().filter(i => !this.P[i].folded);

    if (survivors.length === 0) return this.endRound(gid, { type: 'none' });

    if (survivors.length === 1) {
      const s = survivors[0];
      const gain = this.P[s].stake;
      this.P[s].bal += gain;
      this.bubble(s, 'الساحة لي! 😎');
      this.toast('الكل انسحب — ' + this.P[s].name + ' ياخذ ' + gain + ' قيمة مزايدته');
      this.pushEvent({ k: 'float', idx: s, txt: '+' + gain });
      this.pushEvent({ k: 'sound', name: 'take' });
      this.pushState();
      return this.later(() => this.endRound(gid, { type: 'alone', idx: s, gain }), 1600);
    }

    /* تحصيل المزايدات */
    this.pot = 0;
    for (const i of survivors) { this.P[i].bal -= this.P[i].stake; this.pot += this.P[i].stake; }
    this.phase = 'settle';
    this.pushState();
    this.pushEvent({ k: 'sound', name: 'chip' }, { k: 'shake' });
    this.pushEvent({ k: 'shake' });
    this.toast('الساحة: ' + this.pot + ' بين ' + survivors.map(i => this.P[i].name).join(' و'));

    const top = this.top;
    const topP = this.P[top];
    this.later(() => {
      if (this.gid !== gid) return;
      if (topP.isBot) {
        const opps = survivors.filter(i => i !== top).map(i => ({ p: i, stake: this.P[i].stake }));
        const d = aiSettle(topP.hand, this.pot, opps);
        if (d.mode === 'deal') {
          /* البوت يعرض على الكل بنفس منطق الأوفلاين — نوحّد العرض لكل واحد */
          const per = r500Floor(Math.min(...opps.map(o => d.offers[o.p])));
          this.bubble(top, 'أرضاكم 🤝');
          this.later(() => this.runOffers(gid, top, survivors, per), 1100);
        } else {
          this.bubble(top, 'داقشهم! ⚔️');
          this.later(() => this.showdown(gid, survivors), 1000);
        }
      } else {
        const opps = survivors.filter(i => i !== top);
        const maxOffer = r500Floor(Math.floor(this.pot / opps.length));
        this.awaiting = { idx: top, kind: 'settle' };
        this.pushState();
        this.api.toSeat(topP.seat, {
          t: 'gturn', kind: 'settle',
          pot: this.pot, opps: opps.length, maxOffer,
          high: this.high, secs: SETTLE_MS / 1000,
        });
        const wait = this.isConnected(topP.seat) ? SETTLE_MS : 3000;
        this.awaiting.timer = this.later(() => {
          if (this.gid !== gid || !this.awaiting || this.awaiting.idx !== top) return;
          this.awaiting = null;
          this.bubble(top, 'داقشهم! ⚔️');
          this.showdown(gid, survivors);
        }, wait);
      }
    }, 1000);
  }

  runOffers(gid, top, survivors, offerPer) {
    if (this.destroyed || gid !== this.gid) return;
    const opps = survivors.filter(i => i !== top);
    this.pushEvent({ k: 'toast', txt: this.P[top].name + ' يعرض إرضاء ' + offerPer + ' على كل واحد' });
    this.phase = 'offers';
    this.pushState();

    const fighters = [top];
    let oi = 0;
    const next = () => {
      if (this.destroyed || gid !== this.gid) return;
      if (oi >= opps.length) {
        if (fighters.length === 1) {
          /* الكل وافق */
          this.P[top].bal += this.pot;
          this.pushEvent({ k: 'float', idx: top, txt: '+' + this.pot });
          this.toast(this.P[top].name + ' ياخذ الباقي: ' + this.pot);
          this.pushEvent({ k: 'sound', name: 'take' });
          this.pot = 0; this.pushState();
          return this.later(() => this.endRound(gid, { type: 'deal', top }), 1300);
        }
        this.toast('مداقشة على ' + this.pot + '!');
        return this.later(() => this.showdown(gid, fighters), 800);
      }
      const i = opps[oi++];
      const p = this.P[i];
      if (p.isBot) {
        const accept = aiAccept(p.hand, p.stake, offerPer);
        this.later(() => { this.resolveOffer(gid, i, top, offerPer, accept, fighters, next); }, BOT_DELAY);
      } else {
        this.awaiting = {
          idx: i, kind: 'offer', offer: offerPer, from: top,
          resume: (accept) => this.resolveOffer(gid, i, top, offerPer, accept, fighters, next),
        };
        this.pushState();
        this.api.toSeat(p.seat, {
          t: 'gturn', kind: 'offer',
          offer: offerPer, fromName: this.P[top].name, stake: p.stake,
          secs: OFFER_MS / 1000,
        });
        const wait = this.isConnected(p.seat) ? OFFER_MS : 3000;
        this.awaiting.timer = this.later(() => {
          if (this.gid !== gid || !this.awaiting || this.awaiting.idx !== i) return;
          this.awaiting = null;
          this.resolveOffer(gid, i, top, offerPer, offerPer >= p.stake, fighters, next);
        }, wait);
      }
    };
    next();
  }

  resolveOffer(gid, i, top, offerPer, accept, fighters, next) {
    if (this.destroyed || gid !== this.gid) return;
    const p = this.P[i];
    if (accept) {
      p.bal += offerPer; this.pot -= offerPer;
      this.bubble(i, 'وافق 🤝');
      this.pushEvent({ k: 'float', idx: i, txt: '+' + offerPer });
      this.pushEvent({ k: 'sound', name: 'take' });
      this.toast(p.name + ' أخذ ' + offerPer + ' وانسحب بسلام');
    } else {
      this.bubble(i, 'داقشك! ⚔️');
      this.pushEvent({ k: 'sound', name: 'bad' });
      fighters.push(i);
    }
    this.pushState();
    this.later(next, 1000);
  }

  /* ---------- كشف الأوراق ---------- */
  showdown(gid, fighters) {
    if (this.destroyed || gid !== this.gid) return;
    this.phase = 'showdown';
    this.awaiting = null;
    const reveal = fighters.map(i => ({ idx: i, hand: this.P[i].hand, eval: evalHand(this.P[i].hand).name }));
    this.pushEvent({ k: 'reveal', fighters: reveal });
    this.pushEvent({ k: 'sound', name: 'bad' });
    this.pushState();

    this.later(() => {
      if (this.gid !== gid) return;
      const winners = handWinners(fighters.map(i => ({ p: i, hand: this.P[i].hand })));
      const share = Math.floor(this.pot / winners.length);
      let extra = this.pot - share * winners.length;
      for (const w of winners) {
        const gain = share + (extra-- > 0 ? 1 : 0);
        this.P[w].bal += gain;
        this.pushEvent({ k: 'float', idx: w, txt: '+' + gain });
      }
      if (winners.length > 1) this.toast('تعادل! ' + winners.map(w => this.P[w].name).join(' و') + ' يتقاسمون الساحة');
      else this.bubble(winners[0], 'أكلتها! 😎');
      this.pushEvent({ k: 'sound', name: 'win' });
      this.pot = 0;
      this.pushState();
      this.later(() => this.endRound(gid, { type: 'showdown', fighters: reveal, winners }), 2200);
    }, 1800);
  }

  /* ---------- نهاية الجولة ---------- */
  endRound(gid, info) {
    if (this.destroyed || gid !== this.gid) return;
    this.phase = 'done';
    const events = [];
    for (const p of this.P) {
      if (p.out) continue;
      if (p.bal <= 0) {
        if (p.rebuy) { p.rebuy = false; p.bal = START_BAL; events.push(p.name + ' أفلس — البنك أعطاه ' + START_BAL + ' أخيرة (فرصة واحدة بس)'); }
        else { p.out = true; events.push(p.name + ' خسر كل شي — طالع من اللعبة 💀'); }
      }
    }
    this.pushState();

    if (this.alive().length <= 1) return this.gameOver();

    /* ملخص الجولة — الكل يشوفه وأي واحد يقدر يبدأ التالية */
    this.pushEvent({
      k: 'round_end',
      note: info.type === 'showdown'
        ? '⚔️ مداقشة — الفائز: ' + info.winners.map(w => this.P[w].name).join(' و')
        : info.type === 'deal' ? '🤝 تم التفاهم — ' + this.P[info.top].name + ' أخذ الباقي'
        : info.type === 'alone' ? 'الكل انسحب — ' + this.P[info.idx].name + ' أخذ قيمة مزايدته'
        : 'انتهت الجولة',
      fighters: info.fighters || null,
      events,
    });

    /* التالية تلقائياً إذا ما أحد ضغط */
    this.nextTimer = this.later(() => this.nextRound(), NEXT_MS);
  }

  nextRound() {
    if (this.destroyed || this.phase !== 'done') return;
    clearTimeout(this.nextTimer);
    this.roundNo++;
    this.startRound();
  }

  gameOver() {
    this.phase = 'over';
    const al = this.alive();
    const winner = al.length ? al[0] : this.P.reduce((b, p, i) => p.bal > this.P[b].bal ? i : b, 0);
    this.pushEvent({
      k: 'game_over',
      winner,
      standings: this.P.map((p, i) => ({ idx: i, name: p.name, bal: p.bal, out: p.out })),
    });
    this.pushState();
    this.later(() => this.api.onGameOver(), 3000);
  }

  /* ---------- مدخلات اللاعبين ---------- */
  /** seat = مقعد الغرفة — يرجع true لو قُبل الفعل */
  onAction(seat, m) {
    if (this.destroyed) return;
    const idx = this.bySeat(seat);
    if (idx === -1) return;

    if (m.a === 'next') { this.nextRound(); return; }

    const aw = this.awaiting;
    if (!aw || aw.idx !== idx) return;               /* مو دورك */
    if (this.P[idx].isBot) return;

    if (aw.kind === 'bid' && ['open', 'raise', 'call', 'fold', 'allin'].includes(m.a)) {
      const d = { act: m.a, amount: m.amount };
      /* تحقق مبدئي قبل الإلغاء */
      const me = this.P[idx];
      if (m.a === 'open' || m.a === 'raise') {
        let amount = Math.min(Number(m.amount) || 0, me.bal);
        const minAllowed = this.high === 0 ? MIN_OPEN : this.high + 500;
        if (amount < minAllowed) return;
      }
      if (m.a === 'call' && this.high === 0) return;
      clearTimeout(aw.timer); this.timers.delete(aw.timer);
      this.awaiting = null;
      const gid = this.gid;
      if (this.applyBid(idx, d)) this.marketLoop(gid, this.nextAlive(idx), false);
      return;
    }

    if (aw.kind === 'settle' && (m.a === 'settle_deal' || m.a === 'settle_fight')) {
      clearTimeout(aw.timer); this.timers.delete(aw.timer);
      this.awaiting = null;
      const gid = this.gid;
      const survivors = this.alive().filter(i => !this.P[i].folded);
      if (m.a === 'settle_fight') {
        this.bubble(idx, 'داقشهم! ⚔️');
        return this.showdown(gid, survivors);
      }
      const opps = survivors.filter(i => i !== idx);
      const maxOffer = r500Floor(Math.floor(this.pot / opps.length));
      let offer = Math.round((Number(m.offer) || 0) / 500) * 500;
      offer = Math.max(0, Math.min(offer, maxOffer));
      this.bubble(idx, 'أرضاكم 🤝');
      return this.runOffers(gid, idx, survivors, offer);
    }

    if (aw.kind === 'offer' && m.a === 'offer_answer') {
      clearTimeout(aw.timer); this.timers.delete(aw.timer);
      this.awaiting = null;
      aw.resume(!!m.accept);
      return;
    }
  }

  /* ---------- إعادة مزامنة لاعب رجع ---------- */
  resync(seat) {
    const idx = this.bySeat(seat);
    if (idx === -1) return;
    this.api.toSeat(seat, this.gstate());
    this.sendHand(idx);
    /* لو هو اللي عليه الدور — أعد إرسال رسالة الدور */
    const aw = this.awaiting;
    if (aw && aw.idx === idx && !this.P[idx].isBot) {
      const me = this.P[idx];
      if (aw.kind === 'bid') {
        this.api.toSeat(seat, {
          t: 'gturn', kind: 'bid', mustOpen: this.high === 0,
          high: this.high, bal: me.bal, stake: me.stake,
          minOpen: MIN_OPEN, maxBid: r500Floor(me.bal),
          canCall: this.high > 0 && me.bal >= this.high,
          secs: TURN_MS / 1000,
        });
      } else if (aw.kind === 'offer') {
        this.api.toSeat(seat, { t: 'gturn', kind: 'offer', offer: aw.offer, fromName: this.P[aw.from].name, stake: me.stake, secs: OFFER_MS / 1000 });
      } else if (aw.kind === 'settle') {
        const survivors = this.alive().filter(i => !this.P[i].folded);
        this.api.toSeat(seat, {
          t: 'gturn', kind: 'settle', pot: this.pot,
          opps: survivors.filter(i => i !== idx).length,
          maxOffer: r500Floor(Math.floor(this.pot / Math.max(1, survivors.length - 1))),
          high: this.high, secs: SETTLE_MS / 1000,
        });
      }
    }
  }
}

module.exports = { MadaqeshGame };
