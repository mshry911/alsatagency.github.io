/* اختبار محرك مداقش أونلاين — جولتان كاملتان بلاعبين بشر + بوت */
const { spawn } = require('child_process');
const path = require('path');
const WebSocket = require('ws');

const PORT = 3198;
const URL = 'ws://127.0.0.1:' + PORT;
let passed = 0, failed = 0;

function ok(cond, label) {
  if (cond) { passed++; console.log('  ✅', label); }
  else { failed++; console.log('  ❌', label); }
}

function client(name) {
  const c = { name, ws: null, inbox: [], session: null, seat: null, code: null, hands: [] };
  c.connect = () => new Promise(res => {
    c.ws = new WebSocket(URL);
    c.ws.on('open', res);
    c.ws.on('message', d => {
      const m = JSON.parse(d.toString());
      c.inbox.push(m);
      if ((m.t === 'created' || m.t === 'joined') && m.session) { c.session = m.session; c.code = m.code; c.seat = m.seat; }
      if (m.t === 'ghand') c.hands.push(m.hand);
      if (m.t === 'gturn') c.answer(m);
    });
  });
  /* رد تلقائي على أي دور يجيني */
  c.answer = m => {
    if (m.kind === 'bid') {
      if (m.mustOpen) c.send({ t: 'game', a: 'open', amount: m.minOpen });
      else if (m.canCall) c.send({ t: 'game', a: 'call' });
      else c.send({ t: 'game', a: 'fold' });
    } else if (m.kind === 'settle') {
      c.send({ t: 'game', a: 'settle_fight' });        /* دايماً مداقشة — نختبر كشف الأوراق */
    } else if (m.kind === 'offer') {
      c.send({ t: 'game', a: 'offer_answer', accept: m.offer >= m.stake });
    }
  };
  c.send = o => c.ws.send(JSON.stringify(o));
  c.waitFor = (pred, ms = 30000) => new Promise((res, rej) => {
    const t0 = Date.now();
    const iv = setInterval(() => {
      const m = c.inbox.find(pred);
      if (m) { clearInterval(iv); res(m); }
      else if (Date.now() - t0 > ms) { clearInterval(iv); rej(new Error(c.name + ': timeout')); }
    }, 25);
  });
  return c;
}

async function main() {
  const A = client('أحمد'), B = client('بدر');
  await Promise.all([A.connect(), B.connect()]);

  console.log('١. تجهيز الغرفة (٢ بشر + بوت):');
  A.send({ t: 'create', game: 'madaqesh', name: 'أحمد' });
  const created = await A.waitFor(m => m.t === 'created');
  B.send({ t: 'join', code: created.code, name: 'بدر' });
  await B.waitFor(m => m.t === 'joined');
  A.send({ t: 'add_bot' });
  await A.waitFor(m => m.t === 'room' && m.players.filter(p => p && p.isBot).length === 1);
  B.send({ t: 'ready', ready: true });
  await new Promise(r => setTimeout(r, 150));
  A.send({ t: 'start' });
  await A.waitFor(m => m.t === 'started' && m.file === 'madaqesh_online.html');
  ok(true, 'البدء وصل ومعه ملف اللعبة الصح');

  console.log('٢. توزيع الأوراق (خصوصية + صحة):');
  await A.waitFor(m => m.t === 'ghand');
  await B.waitFor(m => m.t === 'ghand');
  const hA = A.hands[0], hB = B.hands[0];
  ok(hA.length === 4 && hB.length === 4, 'كل لاعب له ٤ أوراق');
  ok(new Set(hA.map(c => c.id)).size === 4, 'أوراق أحمد بدون تكرار');
  ok(!hA.some(c => hB.some(x => x.id === c.id)), 'أوراق أحمد وبدر مختلفة تماماً');
  const st = await A.waitFor(m => m.t === 'gstate' && m.phase === 'market');
  ok(st.players.length === 3, 'الساحة فيها ٣ لاعبين');
  ok(st.players.every(p => p.bal === 5000), 'الكل يبدأ برصيد ٥٠٠٠');
  ok(st.players.every(p => p.cards === 4), 'السيرفر يعد ٤ أوراق لكل واحد (بدون كشفها)');

  console.log('٣. الجولة الأولى حتى النهاية:');
  const re1 = await A.waitFor(m => m.t === 'gevent' && m.k === 'round_end', 60000);
  ok(true, 'وصل إشعار نهاية الجولة: ' + re1.note);
  const done1 = await A.waitFor(m => m.t === 'gstate' && m.phase === 'done');
  const bals1 = done1.players.map(p => p.bal);
  ok(bals1.every(b => Number.isFinite(b) && b >= 0), 'الأرصدة كلها أرقام سليمة: ' + bals1.join(' / '));
  ok(bals1.some(b => b !== 5000), 'في فعلاً فلوس تحركت (مو الكل ٥٠٠٠)');
  const re1B = B.inbox.find(m => m.t === 'gevent' && m.k === 'round_end');
  ok(re1B && re1B.note === re1.note, 'بدر شاف نفس نتيجة الجولة');

  console.log('٤. الجولة الثانية (زر الجولة التالية):');
  A.send({ t: 'game', a: 'next' });
  const st2 = await A.waitFor(m => m.t === 'gstate' && m.roundNo === 2);
  ok(true, 'الجولة الثانية بدأت');
  await A.waitFor(m => m.t === 'ghand' && false, 1).catch(() => {}); /* تجاهل */
  ok(A.hands.length >= 2 && B.hands.length >= 2, 'وصلت أوراق جديدة للجولة الثانية');
  if (A.hands.length >= 2) {
    const h2 = A.hands[1];
    ok(h2.length === 4 && new Set(h2.map(c => c.id)).size === 4, 'أوراق الجولة الثانية سليمة');
  }
  const re2 = await A.waitFor(m => m.t === 'gevent' && m.k === 'round_end' && m !== re1, 60000);
  ok(true, 'الجولة الثانية كملت: ' + re2.note);
  const done2 = await A.waitFor(m => m.t === 'gstate' && m.phase === 'done' && m.roundNo === 2);
  ok(done2.players.every(p => Number.isFinite(p.bal) && p.bal >= 0), 'الأرصدة بعد جولتين سليمة: ' + done2.players.map(p => p.bal).join(' / '));

  [A, B].forEach(c => { try { c.ws.close(); } catch (e) {} });
}

const srv = spawn(process.execPath, [path.join(__dirname, 'server.js')], {
  env: { ...process.env, PORT: String(PORT) },
  stdio: ['ignore', 'pipe', 'pipe'],
});
srv.stderr.on('data', d => process.stderr.write(d));

const waitUp = setInterval(() => {
  try {
    const ws = new WebSocket(URL);
    ws.on('open', () => { ws.close(); clearInterval(waitUp); run(); });
    ws.on('error', () => {});
  } catch (e) {}
}, 100);

async function run() {
  try { await main(); }
  catch (e) { failed++; console.log('  ❌ خطأ غير متوقع:', e.message); }
  console.log('\nالنتيجة: ' + passed + ' ناجح / ' + failed + ' فاشل');
  srv.kill();
  process.exit(failed ? 1 : 0);
}
setTimeout(() => { console.log('انتهت مهلة الاختبار'); srv.kill(); process.exit(1); }, 150000);
