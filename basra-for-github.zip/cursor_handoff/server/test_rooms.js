/* اختبار نظام الغرف — يشغّل السيرفر ويحاكي ٣ لاعبين */
const { spawn } = require('child_process');
const path = require('path');
const WebSocket = require('ws');

const PORT = 3199;
const URL = 'ws://127.0.0.1:' + PORT;
let passed = 0, failed = 0;

function ok(cond, label) {
  if (cond) { passed++; console.log('  ✅', label); }
  else { failed++; console.log('  ❌', label); }
}

/* عميل وهمي */
function client(name) {
  const c = { name, ws: null, inbox: [], session: null, seat: null, code: null };
  c.connect = () => new Promise(res => {
    c.ws = new WebSocket(URL);
    c.ws.on('open', res);
    c.ws.on('message', d => {
      const m = JSON.parse(d.toString());
      c.inbox.push(m);
      if ((m.t === 'created' || m.t === 'joined') && m.session) { c.session = m.session; c.code = m.code; c.seat = m.seat; }
    });
  });
  c.send = o => c.ws.send(JSON.stringify(o));
  c.last = t => [...c.inbox].reverse().find(m => m.t === t);
  c.waitFor = (pred, ms = 3000) => new Promise((res, rej) => {
    const t0 = Date.now();
    const iv = setInterval(() => {
      const m = c.inbox.find(pred);
      if (m) { clearInterval(iv); res(m); }
      else if (Date.now() - t0 > ms) { clearInterval(iv); rej(new Error(c.name + ': timeout')); }
    }, 25);
  });
  return c;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function main() {
  const A = client('أحمد'), B = client('بدر'), C = client('سالم');
  await Promise.all([A.connect(), B.connect(), C.connect()]);

  console.log('١. إنشاء غرفة مداقش:');
  A.send({ t: 'create', game: 'madaqesh', name: 'أحمد' });
  const created = await A.waitFor(m => m.t === 'created');
  ok(/^\d{4}$/.test(created.code), 'رقم غرفة من ٤ خانات: ' + created.code);
  const roomMsg = await A.waitFor(m => m.t === 'room');
  ok(roomMsg.players[0] && roomMsg.players[0].name === 'أحمد', 'أحمد بالمقعد ٠');
  ok(roomMsg.hostSeat === 0, 'أحمد هو الهوست');

  console.log('٢. دخول خاطئ ثم صحيح:');
  B.send({ t: 'join', code: '0000', name: 'بدر' });
  const err1 = await B.waitFor(m => m.t === 'error');
  ok(/ما فيه غرفة/.test(err1.msg), 'رفض رقم غلط: ' + err1.msg);
  B.send({ t: 'join', code: created.code, name: 'بدر' });
  await B.waitFor(m => m.t === 'joined');
  ok(B.seat === 1, 'بدر أخذ المقعد ١');
  C.send({ t: 'join', code: created.code, name: 'سالم' });
  await C.waitFor(m => m.t === 'joined');
  ok(C.seat === 2, 'سالم أخذ المقعد ٢');

  console.log('٣. الجاهزية:');
  B.send({ t: 'ready', ready: true });
  await A.waitFor(m => m.t === 'room' && m.players[1] && m.players[1].ready === true);
  ok(true, 'بدر صار جاهز ووصل للكل');

  console.log('٤. البوتات:');
  A.send({ t: 'add_bot' });
  const withBot = await A.waitFor(m => m.t === 'room' && m.players.filter(p => p && p.isBot).length === 1);
  ok(withBot.players[3].isBot === true, 'بوت أخذ المقعد ٣: ' + withBot.players[3].name);

  console.log('٥. البداية قبل جاهزية الكل:');
  A.send({ t: 'start' });
  const err2 = await A.waitFor(m => m.t === 'error' && /جاهز/.test(m.msg));
  ok(true, 'رفض البدء: ' + err2.msg);

  console.log('٦. البداية الصحيحة:');
  C.send({ t: 'ready', ready: true });
  await sleep(150);
  A.send({ t: 'start' });
  await A.waitFor(m => m.t === 'started');
  await B.waitFor(m => m.t === 'started');
  await C.waitFor(m => m.t === 'started');
  ok(true, 'البدء وصل للاعبين الثلاثة');

  console.log('٧. الانقطاع والرجوع بالجلسة:');
  const B2 = client('بدر-راجع');
  B.ws.close();
  await A.waitFor(m => m.t === 'room' && m.players[1] && m.players[1].connected === false);
  ok(true, 'السيرفر حس بانقطاع بدر');
  await B2.connect();
  B2.send({ t: 'resume', code: B.code, session: B.session });
  await B2.waitFor(m => m.t === 'joined');
  await A.waitFor(m => m.t === 'room' && m.players[1] && m.players[1].connected === true);
  ok(B2.seat === 1, 'بدر رجع لنفس مقعده خلال المهلة');

  console.log('٨. خروج الهوست ونقله:');
  A.send({ t: 'leave' });
  const migrated = await B2.waitFor(m => m.t === 'room' && m.hostSeat !== 0);
  ok(migrated.players[0] === null, 'مقعد أحمد صار فاضي');
  ok(migrated.players[migrated.hostSeat] && !migrated.players[migrated.hostSeat].isBot, 'الهوست انتقل لبشري: مقعد ' + migrated.hostSeat);

  console.log('٩. طرد لاعب (غرفة لوبي جديدة بهوست جديد):');
  B2.send({ t: 'create', game: 'sevens', name: 'بدر' });
  const created2 = await B2.waitFor(m => m.t === 'created' && m.code !== created.code);
  C.send({ t: 'join', code: created2.code, name: 'سالم' });
  await C.waitFor(m => m.t === 'joined' && m.code === created2.code);
  B2.send({ t: 'kick', seat: 1 });
  await C.waitFor(m => m.t === 'kicked');
  ok(true, 'سالم انطرد من اللوبي ووصله إشعار');

  [A, B, B2, C].forEach(c => { try { c.ws.close(); } catch (e) {} });
}

const srv = spawn(process.execPath, [path.join(__dirname, 'server.js')], {
  env: { ...process.env, PORT: String(PORT) },
  stdio: ['ignore', 'pipe', 'pipe'],
});
srv.stderr.on('data', d => process.stderr.write(d));

/* نستنى السيرفر يجهز ثم نشغّل الاختبار */
const waitUp = setInterval(async () => {
  try {
    const ws = new WebSocket(URL);
    ws.on('open', () => { ws.close(); clearInterval(waitUp); run(); });
    ws.on('error', () => {});
  } catch (e) {}
}, 100);

async function run() {
  try { await main(); }
  catch (e) { failed++; console.log('  ❌ خطأ غير متوقع:', e.message); }
  console.log('\nالنتيجة: ' + passed + ' ناجح / ' + failed + ' فاشل');
  srv.kill();
  process.exit(failed ? 1 : 0);
}
setTimeout(() => { console.log('انتهت مهلة الاختبار'); srv.kill(); process.exit(1); }, 30000);
